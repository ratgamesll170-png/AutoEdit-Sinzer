package com.sinzer.autoedit

import com.sinzer.autoedit.ai.*
import com.sinzer.autoedit.audio.BeatMap
import com.sinzer.autoedit.audio.BeatTracker
import com.sinzer.autoedit.catalog.*
import com.sinzer.autoedit.model.*
import org.junit.Assert.*
import org.junit.Test
import java.util.Random
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.sin

/** Pure-JVM tests. Run with:  ./gradlew testDebugUnitTest */
class CoreTest {

    // ---------- requirement counts ----------
    @Test fun catalogsMeetTargets() {
        assertTrue("effects", FxCatalog.all.size > 100)
        assertTrue("transitions", TransitionCatalog.all.size >= 50)
        assertTrue("colour presets", ColorPresets.all.size > 50)
        assertTrue("text animations", TextAnims.all.size >= 100)
        assertTrue("fonts", FontCatalog.all.size >= 100)
        assertEquals("auto edit styles", 20, AutoStyles.all.size)
        assertEquals(FxCatalog.all.size, FxCatalog.all.map { it.id }.toSet().size)
        assertEquals(TransitionCatalog.all.size, TransitionCatalog.all.map { it.id }.toSet().size)
        assertEquals(TextAnims.all.size, TextAnims.all.map { it.id }.toSet().size)
    }

    @Test fun everyStyleReferencesExistingPresets() {
        for (s in AutoStyles.all) {
            s.fx.forEach { assertNotNull("${s.id}: ${it.presetId}", FxCatalog.get(it.presetId)) }
            s.transitions.forEach { assertNotNull("${s.id}: $it", TransitionCatalog.get(it)) }
            s.color?.let { assertNotNull("${s.id}: $it", ColorPresets.get(it)) }
        }
    }

    // ---------- beat tracking on a synthetic 120 BPM click track ----------
    private fun clickTrack(bpm: Double, seconds: Int, phase: Double): FloatArray {
        val sr = BeatTracker.SR; val x = FloatArray(sr * seconds); val per = 60.0 / bpm
        var t = phase
        while (t < seconds - 0.2) {
            val s = (t * sr).toInt()
            for (i in 0 until (0.12 * sr).toInt()) { val tt = i.toDouble() / sr; x[s + i] += (sin(2 * PI * 1800 * tt) * exp(-tt * 80)).toFloat() }
            t += per
        }
        return x
    }

    @Test fun beatTrackerFindsTempoAndPhase() {
        for (bpm in listOf(100.0, 120.0, 128.0)) {
            val x = clickTrack(bpm, 25, 0.23)
            val ex = BeatTracker.Extractor(); ex.push(x, x.size)
            val r = ex.finish()
            assertEquals("bpm @$bpm", bpm, r.bpm.toDouble(), 2.0)
            val per = 60000.0 / bpm
            val errs = r.beatsMs.map { b -> val k = Math.round((b - 230) / per); abs(b - (230 + k * per)) }
            assertTrue("most beats within 25 ms @$bpm", errs.count { it < 25 } >= errs.size * 0.95)
        }
    }

    // ---------- timeline editing ----------
    private fun proj(): Project {
        val a = MediaAsset("a1", "content://a1", MediaType.VIDEO, "a", 10_000, 1920, 1080, 30f, true)
        var p = Project(assets = listOf(a))
        p = Ops.appendToMain(p, a); p = Ops.appendToMain(p, a.copy(id = "a2")); return p
    }

    @Test fun mainTrackStaysContiguousAfterEdits() {
        var p = proj()
        val c1 = p.clips.minByOrNull { it.startMs }!!
        p = Ops.split(p, Sel(ItemKind.CLIP, c1.id), 4000)!!
        assertEquals(3, p.clips.size)
        p = Ops.trim(p, Sel(ItemKind.CLIP, p.clips.minByOrNull { it.startMs }!!.id), 1, -1000)
        var t = 0L
        for (c in p.clips.sortedBy { it.startMs }) { assertEquals(t, c.startMs); t += clipDurMs(c) }
        p = Ops.delete(p, Sel(ItemKind.CLIP, p.clips.minByOrNull { it.startMs }!!.id))
        assertEquals(0L, p.clips.minOf { it.startMs })
    }

    @Test fun speedChangesDuration() {
        val c = Clip(assetId = "x", trackId = "V1", startMs = 0, inMs = 0, outMs = 4000, speed = 2f)
        assertEquals(2000L, clipDurMs(c))
        val ramp = c.copy(speed = 1f, speedCurve = listOf(SpeedPoint(0f, 0.5f), SpeedPoint(1f, 2f)))
        assertTrue(clipDurMs(ramp) in 3000L..6000L)
        assertEquals(1000L, sourceAtLocal(c, 500))
    }

    @Test fun keyframesInterpolate() {
        val k = listOf(Keyframe(0, 0f), Keyframe(1000, 10f))
        assertEquals(5f, evalKf(k, 500, 0f), 0.01f)
        assertEquals(10f, evalKf(k, 2000, 0f), 0.01f)
    }

    // ---------- planner ----------
    @Test fun plannerCutsOnBeatsAndRespectsStyleBounds() {
        val asset = MediaAsset("v", "content://v", MediaType.VIDEO, "v", 60_000, 1920, 1080, 30f, true)
        val scenes = SceneInfo(60_000, listOf(10_000, 20_000, 35_000, 50_000), FloatArray(241) { 0.3f + 0.7f * ((it % 9) / 9f) })
        val beats = LongArray(200) { 300L + it * 500L }
        val bm = BeatMap(beats, FloatArray(beats.size) { if (it % 4 == 0) 1f else 0.6f }, 120f)
        for (style in AutoStyles.all) {
            val plan = AutoEditPlanner.plan(listOf(SourceInput(asset, scenes, null)), bm, "m", 100_000, style, 20_000, 3)
            assertTrue(style.id, plan.cuts.isNotEmpty())
            for (c in plan.cuts) { assertTrue(style.id, c.outMs > c.inMs); assertTrue(style.id, c.inMs >= 0 && c.outMs <= asset.durationMs) }
            assertTrue(style.id, plan.totalMs <= 20_000 + style.maxCutMs)
        }
    }

    @Test fun plannerWorksWithoutMusic() {
        val asset = MediaAsset("v", "content://v", MediaType.VIDEO, "v", 30_000, 1280, 720, 30f, false)
        val plan = AutoEditPlanner.plan(listOf(SourceInput(asset, null, null)), null, null, 0, AutoStyles.get("highlight"), 15_000, 1)
        assertTrue(plan.cuts.size >= 2); assertNull(plan.musicAssetId)
    }
}
