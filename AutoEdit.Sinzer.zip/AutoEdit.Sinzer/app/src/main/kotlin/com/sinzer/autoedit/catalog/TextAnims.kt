package com.sinzer.autoedit.catalog

import com.sinzer.autoedit.model.TextAnimRef
import kotlin.math.*

enum class TKind { FADE, POP, BOUNCE, SLIDE, SLIDE_OS, ZOOM, SPIN, FLIP, ELASTIC, WAVE, SHAKE, GLITCH, FLICKER, TYPEWRITER, REVEAL, RGB,
    KARAOKE, FLIP3DY, FLIP3DX, BEAT, SWING, RAINBOW, FLOAT, TRACK, STAMP, STRETCH, CASCADE, BLINK, JELLO }
enum class Gran { WHOLE, CHAR, WORD }

/** [loop] presets repeat for the whole time the text is visible; the others play once when entering or leaving. */
data class TextAnim(val id: String, val nameTh: String, val kind: TKind, val gran: Gran, val v: Int, val loop: Boolean)

/** Per-glyph (cluster / word) transform produced by an animation. Distances are in px; rotation in degrees. */
class GlyphState {
    var dx = 0f; var dy = 0f; var sx = 1f; var sy = 1f; var rot = 0f; var alpha = 1f
    var rgb = 0f            // RGB-split offset in px (0 = none)
    var hue = -1            // >=0: use rainbow colour variant
    var hl = 0f             // karaoke highlight 0..1
    fun reset() { dx = 0f; dy = 0f; sx = 1f; sy = 1f; rot = 0f; alpha = 1f; rgb = 0f; hue = -1; hl = 0f }
}

class AnimCtx(val u: Float, val tMs: Long, val itemDurMs: Long, val pulse: (Long) -> Float, val karaoke: Float)

object TextAnims {
    private val list = ArrayList<TextAnim>()
    private val grans3 = listOf(Gran.WHOLE to "ทั้งข้อความ", Gran.CHAR to "ทีละตัวอักษร", Gran.WORD to "ทีละคำ")
    private val dirs = listOf("ซ้าย", "ขวา", "บน", "ล่าง")

    private fun add(k: TKind, g: Gran, v: Int, name: String, loop: Boolean = false) {
        list.add(TextAnim("ta_${k.name.lowercase()}_${g.name.lowercase()}_$v", name, k, g, v, loop))
    }
    private fun each3(k: TKind, base: String, v: Int = 0) = grans3.forEach { (g, n) -> add(k, g, v, "$base $n") }
    private fun gn(g: Gran) = grans3.first { it.first == g }.second

    init {
        each3(TKind.FADE, "เฟดเข้า"); each3(TKind.POP, "ป๊อปอัพ")
        each3(TKind.BOUNCE, "เด้งตกลงมา", 0); each3(TKind.BOUNCE, "เด้งขึ้น", 1)
        for (d in 0..3) each3(TKind.SLIDE, "สไลด์จาก${dirs[d]}", d)
        for (d in 0..3) add(TKind.SLIDE_OS, Gran.WHOLE, d, "สไลด์เด้งจาก${dirs[d]}")
        each3(TKind.ZOOM, "ซูมเข้า", 0); each3(TKind.ZOOM, "ซูมออก", 1)
        each3(TKind.SPIN, "หมุนตามเข็ม", 0); each3(TKind.SPIN, "หมุนทวนเข็ม", 1)
        each3(TKind.FLIP, "พลิกขึ้น"); each3(TKind.ELASTIC, "ยางยืด")
        for (g in listOf(Gran.CHAR, Gran.WORD)) { add(TKind.WAVE, g, 0, "คลื่นช้า ${gn(g)}", true); add(TKind.WAVE, g, 1, "คลื่นเร็ว ${gn(g)}", true) }
        for (g in listOf(Gran.WHOLE, Gran.CHAR)) {
            add(TKind.SHAKE, g, 0, "สั่นเบา ${gn(g)}", true); add(TKind.SHAKE, g, 1, "สั่นแรง ${gn(g)}", true)
            add(TKind.GLITCH, g, 0, "กลิตช์เบา ${gn(g)}", true); add(TKind.GLITCH, g, 1, "กลิตช์แรง ${gn(g)}", true)
            add(TKind.FLICKER, g, 0, "นีออนกะพริบ ${gn(g)}", true)
            add(TKind.BEAT, g, 0, "เต้นตามบีตเบา ${gn(g)}", true); add(TKind.BEAT, g, 1, "เต้นตามบีตแรง ${gn(g)}", true)
            add(TKind.SWING, g, 0, "แกว่ง ${gn(g)}", true); add(TKind.RAINBOW, g, 0, "สายรุ้ง ${gn(g)}", true)
            add(TKind.FLOAT, g, 0, "ลอยขึ้นลง ${gn(g)}", true); add(TKind.BLINK, g, 0, "กะพริบ ${gn(g)}", true)
            add(TKind.STAMP, g, 0, "ประทับตรา ${gn(g)}"); add(TKind.STAMP, g, 1, "ประทับตราหมุน ${gn(g)}")
            add(TKind.JELLO, g, 0, "เจลลี่ ${gn(g)}")
        }
        for (g in listOf(Gran.CHAR, Gran.WORD)) {
            add(TKind.TYPEWRITER, g, 0, "พิมพ์ดีด ${gn(g)}"); add(TKind.TYPEWRITER, g, 1, "พิมพ์ดีดป๊อป ${gn(g)}")
            add(TKind.CASCADE, g, 0, "น้ำตกตัวอักษร ${gn(g)}")
        }
        for (d in 0..3) add(TKind.REVEAL, Gran.WHOLE, d, "เปิดเผยจาก${dirs[d]}")
        add(TKind.RGB, Gran.WHOLE, 0, "แยกสีเข้า"); add(TKind.RGB, Gran.WHOLE, 1, "แยกสีสั่นวน", true)
        add(TKind.KARAOKE, Gran.WORD, 0, "คาราโอเกะเติมสี"); add(TKind.KARAOKE, Gran.WORD, 1, "คาราโอเกะเด้ง"); add(TKind.KARAOKE, Gran.WORD, 2, "คาราโอเกะป๊อป")
        each3(TKind.FLIP3DY, "พลิก 3D แกนตั้ง"); each3(TKind.FLIP3DX, "พลิก 3D แกนนอน")
        add(TKind.TRACK, Gran.CHAR, 0, "ขยายระยะตัวอักษร"); add(TKind.TRACK, Gran.CHAR, 1, "รวมตัวอักษร")
        add(TKind.STRETCH, Gran.WHOLE, 0, "ยืดจากซ้าย"); add(TKind.STRETCH, Gran.WHOLE, 1, "ยืดจากขวา")
        add(TKind.STRETCH, Gran.WORD, 0, "ยืดจากซ้าย ทีละคำ"); add(TKind.STRETCH, Gran.WORD, 1, "ยืดจากขวา ทีละคำ")
    }

    val all: List<TextAnim> get() = list
    private val byId by lazy { list.associateBy { it.id } }
    fun get(id: String) = byId[id]

    private fun clamp01(x: Float) = x.coerceIn(0f, 1f)
    private fun outCubic(t: Float) = 1f - (1f - t).pow(3)
    private fun outBack(t: Float): Float { val c1 = 1.70158f; val c3 = c1 + 1f; return 1f + c3 * (t - 1f).pow(3) + c1 * (t - 1f).pow(2) }
    private fun outElastic(t: Float): Float = if (t <= 0f) 0f else if (t >= 1f) 1f else (2.0.pow(-10.0 * t) * sin((t * 10.0 - 0.75) * (2.0 * PI / 3.0)) + 1.0).toFloat()
    private fun outBounce(x: Float): Float {
        val n1 = 7.5625f; val d1 = 2.75f; var t = x
        return when {
            t < 1f / d1 -> n1 * t * t
            t < 2f / d1 -> { t -= 1.5f / d1; n1 * t * t + .75f }
            t < 2.5f / d1 -> { t -= 2.25f / d1; n1 * t * t + .9375f }
            else -> { t -= 2.625f / d1; n1 * t * t + .984375f }
        }
    }
    private fun hash(n: Float): Float { val s = sin(n * 127.1f) * 43758.547f; return s - floor(s) }

    /**
     * Evaluates one animation for glyph unit [i] of [n]. [px]/[py] = normalised position of the unit in the block (0..1).
     * Transforms are accumulated onto [g] so several animations can be stacked.
     */
    fun apply(ref: TextAnimRef, a: TextAnim, i: Int, n: Int, px: Float, py: Float, c: AnimCtx, g: GlyphState) {
        val k = ref.strength; val spd = ref.speed.coerceAtLeast(0.1f)
        val dur = (ref.durMs / spd).coerceAtLeast(50f)
        val pr0 = if (a.loop) 1f else when (ref.phase) {
            1 -> clamp01((c.itemDurMs - c.tMs) / dur)
            else -> clamp01(c.tMs / dur)
        }
        val spread = if (a.gran == Gran.WHOLE || a.loop) 0f else if (a.kind == TKind.CASCADE) 0.85f else 0.7f
        val frac = if (n <= 1) 0f else i.toFloat() / (n - 1)
        val pr = if (spread == 0f) pr0 else clamp01((pr0 - frac * spread) / (1f - spread))
        val t = c.tMs.toFloat() * spd
        val u = c.u
        when (a.kind) {
            TKind.FADE -> g.alpha *= pr
            TKind.POP -> { val e = outBack(pr); g.sx *= e; g.sy *= e; g.alpha *= clamp01(pr * 3f) }
            TKind.BOUNCE -> { val e = outBounce(pr); g.dy += (1f - e) * u * 2.2f * k * (if (a.v == 0) -1f else 1f); g.alpha *= clamp01(pr * 4f) }
            TKind.SLIDE -> { val e = outCubic(pr); val d = (1f - e) * u * 3f * k
                when (a.v) { 0 -> g.dx -= d; 1 -> g.dx += d; 2 -> g.dy -= d; else -> g.dy += d }; g.alpha *= e }
            TKind.SLIDE_OS -> { val e = outBack(pr); val d = (1f - e) * u * 3f * k
                when (a.v) { 0 -> g.dx -= d; 1 -> g.dx += d; 2 -> g.dy -= d; else -> g.dy += d }; g.alpha *= clamp01(pr * 3f) }
            TKind.ZOOM -> { val e = outCubic(pr); val s = if (a.v == 0) e else 1f + (1f - e) * 2.5f * k; g.sx *= max(s, 0.001f); g.sy *= max(s, 0.001f); g.alpha *= e }
            TKind.SPIN -> { val e = outCubic(pr); g.rot += (1f - e) * 360f * k * (if (a.v == 0) -1f else 1f); g.sx *= max(e, .001f); g.sy *= max(e, .001f); g.alpha *= clamp01(pr * 2f) }
            TKind.FLIP -> { val e = outBack(pr); g.sy *= max(e, .001f); g.alpha *= clamp01(pr * 3f) }
            TKind.ELASTIC -> { val e = outElastic(pr); g.sx *= max(e, .001f); g.sy *= max(e, .001f); g.alpha *= clamp01(pr * 4f) }
            TKind.WAVE -> g.dy += sin(t * (if (a.v == 0) 0.005f else 0.011f) + i * 0.7f) * u * 0.35f * k
            TKind.SHAKE -> { val s = floor(t / 42f) + i * 7.3f; val amp = u * (if (a.v == 0) 0.04f else 0.12f) * k
                g.dx += (hash(s) - .5f) * 2f * amp; g.dy += (hash(s + 31f) - .5f) * 2f * amp }
            TKind.GLITCH -> { val s = floor(t / 90f) + i * 3.1f; val on = hash(s) > (if (a.v == 0) 0.78f else 0.55f)
                if (on) { g.dx += (hash(s + 9f) - .5f) * u * (if (a.v == 0) 0.5f else 1.1f) * k; g.rgb += u * 0.09f * k; g.alpha *= if (hash(s + 4f) > .8f) .4f else 1f } }
            TKind.FLICKER -> g.alpha *= if (hash(floor(t / 70f) + i * 5.7f) > 0.22f) 1f else 0.15f
            TKind.TYPEWRITER -> { val th = if (a.gran == Gran.WHOLE) 0f else (i + 1f) / n
                val vis = if (ref.phase == 1) pr0 >= th else pr0 >= th - 1e-4f
                if (!vis) g.alpha = 0f else if (a.v == 1) { val local = clamp01((pr0 - (th - 1f / n)) * n); val e = outBack(local); g.sx *= max(e, .01f); g.sy *= max(e, .01f) } }
            TKind.REVEAL -> { val pos = when (a.v) { 0 -> px; 1 -> 1f - px; 2 -> py; else -> 1f - py }
                val edge = (pr0 * 1.2f - pos).coerceIn(0f, 0.2f) / 0.2f; g.alpha *= edge }
            TKind.RGB -> g.rgb += if (a.loop) (0.5f + 0.5f * sin(t * 0.012f)) * u * 0.1f * k else (1f - pr) * u * 0.25f * k
            TKind.KARAOKE -> { g.hl = c.karaoke
                val act = if (c.karaoke > 0f && c.karaoke < 1f) 1f else 0f
                when (a.v) { 1 -> g.dy -= act * u * 0.18f * k; 2 -> { g.sx *= 1f + act * 0.18f * k; g.sy *= 1f + act * 0.18f * k } } }
            TKind.FLIP3DY -> { val e = outCubic(pr); g.sx *= max(abs(cos((1f - e) * PI.toFloat() / 2f)), .001f); g.alpha *= clamp01(pr * 3f) }
            TKind.FLIP3DX -> { val e = outCubic(pr); g.sy *= max(abs(cos((1f - e) * PI.toFloat() / 2f)), .001f); g.alpha *= clamp01(pr * 3f) }
            TKind.BEAT -> { val p = c.pulse(c.tMs - (if (a.gran == Gran.CHAR) i * 25L else 0L)); val s = 1f + p * (if (a.v == 0) 0.12f else 0.3f) * k; g.sx *= s; g.sy *= s }
            TKind.SWING -> g.rot += sin(t * 0.004f + i * 0.5f) * 12f * k
            TKind.RAINBOW -> g.hue = ((t / 110f).toInt() + i).mod(6)
            TKind.FLOAT -> g.dy += sin(t * 0.002f + i * 0.4f) * u * 0.14f * k
            TKind.TRACK -> { val e = outCubic(pr); val centre = i - (n - 1) / 2f
                g.dx += if (a.v == 0) centre * u * 0.9f * (1f - e) * k else -centre * u * 0.5f * (1f - e) * k; g.alpha *= e }
            TKind.STAMP -> { val e = outCubic(pr); val s = 1f + (1f - e) * 2.5f * k; g.sx *= s; g.sy *= s; g.alpha *= clamp01(pr * 2.5f); if (a.v == 1) g.rot += (1f - e) * -14f * k }
            TKind.STRETCH -> { val e = outCubic(pr); g.sx *= 1f + (1f - e) * 1.6f * k; g.dx += (1f - e) * u * (if (a.v == 0) -1.5f else 1.5f) * k; g.alpha *= e }
            TKind.CASCADE -> { val e = outBack(pr); g.dy += (1f - e) * u * 1.1f * k; g.alpha *= clamp01(pr * 3f) }
            TKind.BLINK -> { val idx = floor(t / 340f).toInt() + (if (a.gran == Gran.CHAR) i else 0); g.alpha *= if (idx % 2 == 0) 1f else 0.15f }
            TKind.JELLO -> { val w = sin(pr * 16f) * (1f - pr) * 0.45f * k; g.sx *= 1f + w; g.sy *= 1f - w; g.alpha *= clamp01(pr * 4f) }
        }
    }
}
