package com.sinzer.autoedit.render

import androidx.media3.common.C
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.BaseAudioProcessor
import androidx.media3.common.audio.SpeedProvider
import androidx.media3.common.util.UnstableApi
import com.sinzer.autoedit.audio.BeatMap
import com.sinzer.autoedit.catalog.FxPreset
import com.sinzer.autoedit.catalog.TransPreset
import com.sinzer.autoedit.model.*
import java.nio.ByteBuffer
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * NOTE (time base): the effects below interpret the frame timestamp handed to the shader as *timeline time* of the project.
 * That is how Media3 reports timestamps for effects placed on items of a sequence (item offset is added) and for
 * composition-level effects. This must be verified on a real device (see README, "ข้อสมมติที่ต้องทดสอบ").
 */
class PresetFxDriver(
    private val p: FxPreset, private val inst: FxInstance, private val startMs: Long, private val endMs: Long,
    private val beat: BeatMap?, private val intensityKf: List<Keyframe>?, private val ownerStartMs: Long,
) : FxDriver {
    override fun frame(tUs: Long): FxFrame {
        val t = tUs / 1000
        if (!inst.enabled || t < startMs || t > endMs) return FxFrame(0f, emptyMap())
        var k = inst.intensity
        if (!intensityKf.isNullOrEmpty()) k *= evalKf(intensityKf, t - ownerStartMs, 1f)
        if (p.beat || inst.beatSync) k *= beat?.pulse(t) ?: 1f
        return FxFrame(k, p.params)
    }
}

class TransitionDriver(private val tp: TransPreset, private val cutMs: Long, private val durMs: Long, private val outHalf: Boolean,
                       private val intensity: Float, dir: Int) : FxDriver {
    private val sign = (if (outHalf) 1f else -1f) * (if (dir == 1) -1f else 1f)
    private val empty = FxFrame(1f, emptyMap())
    override fun frame(tUs: Long): FxFrame {
        val t = tUs / 1000
        val p = if (outHalf) {
            if (t < cutMs - durMs || t > cutMs + 20) return empty
            ((t - (cutMs - durMs)).toFloat() / durMs).coerceIn(0f, 1f)
        } else {
            if (t < cutMs - 20 || t > cutMs + durMs) return empty
            1f - ((t - cutMs).toFloat() / durMs).coerceIn(0f, 1f)
        }
        return FxFrame(1f, tp.f((p * intensity).coerceIn(0f, 1.5f), sign))
    }
}

/** Clip position/scale/rotation/opacity (static values + keyframes). */
class TransformDriver(private val c: Clip) : FxDriver {
    override fun frame(tUs: Long): FxFrame {
        val l = tUs / 1000 - c.startMs
        val k = c.keyframes
        return FxFrame(1f, mapOf(
            "tx" to k.value(Prop.X, l, c.tx), "ty" to k.value(Prop.Y, l, c.ty), "scl" to k.value(Prop.SCALE, l, c.scale),
            "trot" to k.value(Prop.ROT, l, c.rot), "opac" to k.value(Prop.OPACITY, l, c.opacity)))
    }
    companion object { val KEYS = setOf("tx", "ty", "scl", "trot", "opac") }
}

/** Colour adjustments (static or keyframed with props "col:<name>"). */
class GradeDriver(private val c: Clip, private val adj: ColorAdj) : FxDriver {
    override fun frame(tUs: Long): FxFrame {
        val l = tUs / 1000 - c.startMs; val k = c.keyframes
        fun v(name: String, base: Float) = k.value("col:$name", l, base)
        return FxFrame(1f, mapOf(
            "exposure" to v("exposure", adj.exposure), "bright" to v("brightness", adj.brightness), "contrast" to v("contrast", adj.contrast),
            "sat" to v("saturation", adj.saturation), "temp" to v("temperature", adj.temperature), "tint" to v("tint", adj.tint),
            "hi" to v("highlights", adj.highlights), "sh" to v("shadows", adj.shadows), "wh" to v("whites", adj.whites), "bl" to v("blacks", adj.blacks),
            "hue" to v("hue", adj.hue), "fade" to v("fade", adj.fade), "vig" to v("vignette", adj.vignette), "grain" to v("grain", adj.grain),
            "sharpen" to v("sharpen", adj.sharpen)))
    }
    companion object {
        fun keysFor(c: Clip, a: ColorAdj): Set<String> {
            val all = mapOf("exposure" to a.exposure, "bright" to a.brightness, "contrast" to a.contrast, "sat" to a.saturation, "temp" to a.temperature,
                "tint" to a.tint, "hi" to a.highlights, "sh" to a.shadows, "wh" to a.whites, "bl" to a.blacks, "hue" to a.hue, "fade" to a.fade,
                "vig" to a.vignette, "grain" to a.grain, "sharpen" to a.sharpen)
            val kfCols = c.keyframes.filter { it.prop.startsWith("col:") }.map { it.prop.removePrefix("col:") }
            val nameToKey = mapOf("exposure" to "exposure", "brightness" to "bright", "contrast" to "contrast", "saturation" to "sat", "temperature" to "temp",
                "tint" to "tint", "highlights" to "hi", "shadows" to "sh", "whites" to "wh", "blacks" to "bl", "hue" to "hue", "fade" to "fade",
                "vignette" to "vig", "grain" to "grain", "sharpen" to "sharpen")
            return all.filter { it.value != 0f }.keys + kfCols.mapNotNull { nameToKey[it] }
        }
    }
}

// ------------------------------------------------------------------ audio

/** Piecewise-constant speed derived from a clip's speed curve; timeUs is relative to the clip's in-point. */
@UnstableApi
class ClipSpeedProvider(private val clip: Clip) : SpeedProvider {
    private val segs = if (clip.speedCurve.isEmpty()) 1 else 16
    private val srcUs = (clip.outMs - clip.inMs) * 1000L
    private val segUs = max(1L, srcUs / segs)
    override fun getSpeed(timeUs: Long): Float {
        if (segs == 1) return clip.speed.coerceIn(0.05f, 100f)
        val i = (timeUs / segUs).toInt().coerceIn(0, segs - 1)
        return speedAt(clip, (i + 0.5f) / segs).coerceIn(0.05f, 100f)
    }
    override fun getNextSpeedChangeTimeUs(timeUs: Long): Long {
        if (segs == 1) return C.TIME_UNSET
        val i = (timeUs / segUs).toInt()
        return if (i + 1 >= segs) C.TIME_UNSET else (i + 1) * segUs
    }
}

/** Ducking: intervals (timeline ms) during which speech is present; music gain follows with a 250 ms ramp. */
class DuckEnvelope(private val starts: LongArray, private val ends: LongArray, private val level: Float) {
    fun gainAt(t: Long): Float {
        if (starts.isEmpty()) return 1f
        var lo = 0; var hi = starts.size - 1; var idx = -1
        while (lo <= hi) { val m = (lo + hi) ushr 1; if (starts[m] <= t) { idx = m; lo = m + 1 } else hi = m - 1 }
        var d = Long.MAX_VALUE
        if (idx >= 0) { d = if (t <= ends[idx]) 0 else t - ends[idx] }
        if (idx + 1 < starts.size) d = min(d, starts[idx + 1] - t)
        val f = if (d >= 250) 0f else 1f - d / 250f
        return 1f - (1f - level) * f
    }
    companion object {
        fun of(intervals: List<LongRange>, level: Float): DuckEnvelope {
            val m = ArrayList<LongRange>()
            for (r in intervals.sortedBy { it.first }) {
                if (m.isNotEmpty() && r.first <= m.last().last + 200) m[m.size - 1] = m.last().first..max(m.last().last, r.last) else m.add(r)
            }
            return DuckEnvelope(LongArray(m.size) { m[it].first }, LongArray(m.size) { m[it].last }, level)
        }
    }
}

/** Volume x fade-in x fade-out x volume keyframes x ducking, as a function of time since the clip start (ms). */
class ClipGain(private val c: Clip, private val duck: DuckEnvelope?, private val trackMuted: Boolean) {
    private val dur = clipDurMs(c)
    val isUnity = !trackMuted && !c.muted && c.volume == 1f && c.fadeInMs == 0L && c.fadeOutMs == 0L && duck == null &&
        c.keyframes.none { it.prop == Prop.VOLUME }
    fun at(localMs: Long): Float {
        if (trackMuted || c.muted) return 0f
        var g = c.keyframes.value(Prop.VOLUME, localMs, 1f) * c.volume
        if (c.fadeInMs > 0) g *= min(1f, localMs.toFloat() / c.fadeInMs)
        if (c.fadeOutMs > 0) g *= min(1f, max(0L, dur - localMs).toFloat() / c.fadeOutMs)
        if (duck != null) g *= duck.gainAt(c.startMs + localMs)
        return g.coerceIn(0f, 4f)
    }
}

/**
 * 16-bit PCM gain envelope. Time is counted from the first sample the processor sees after a flush, so fades/ducking/volume
 * keyframes are exact in Export; in Preview they can be shifted after the user seeks inside a clip.
 */
@UnstableApi
class GainProcessor(private val gain: ClipGain) : BaseAudioProcessor() {
    private var rate = 44100
    private var channels = 2
    private var frames = 0L

    override fun onConfigure(inputAudioFormat: AudioProcessor.AudioFormat): AudioProcessor.AudioFormat {
        if (inputAudioFormat.encoding != C.ENCODING_PCM_16BIT) throw AudioProcessor.UnhandledAudioFormatException(inputAudioFormat)
        rate = inputAudioFormat.sampleRate; channels = inputAudioFormat.channelCount
        return inputAudioFormat
    }

    override fun queueInput(inputBuffer: ByteBuffer) {
        val size = inputBuffer.remaining()
        val out = replaceOutputBuffer(size)
        val block = max(1, rate / 100)          // gain re-evaluated every 10 ms
        var g = gain.at(frames * 1000 / rate)
        var inBlock = 0
        while (inputBuffer.remaining() >= 2 * channels) {
            if (inBlock == 0) g = gain.at(frames * 1000 / rate)
            for (ch in 0 until channels) {
                val s = inputBuffer.short.toInt()
                out.putShort((s * g).toInt().coerceIn(-32768, 32767).toShort())
            }
            frames++; inBlock = (inBlock + 1) % block
        }
        out.flip()
    }

    override fun onFlush() { frames = 0 }
}
