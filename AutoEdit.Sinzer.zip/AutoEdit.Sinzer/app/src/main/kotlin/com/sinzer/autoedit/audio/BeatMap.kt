package com.sinzer.autoedit.audio

import com.sinzer.autoedit.model.BeatEdit
import kotlin.math.abs
import kotlin.math.exp

/** Beats in a single time base (ms) plus per-beat strength 0..1. */
class BeatMap(val beatsMs: LongArray, val strength: FloatArray, val bpm: Float) {
    val isEmpty get() = beatsMs.isEmpty()

    /** Index of the last beat <= t, or -1. */
    fun lastIndex(tMs: Long): Int {
        var lo = 0; var hi = beatsMs.size - 1; var r = -1
        while (lo <= hi) { val m = (lo + hi) ushr 1; if (beatsMs[m] <= tMs) { r = m; lo = m + 1 } else hi = m - 1 }
        return r
    }

    /** 1.0 exactly on a beat, decaying afterwards; scaled by the beat strength (loud hit = stronger pulse). */
    fun pulse(tMs: Long, decayMs: Float? = null): Float {
        if (beatsMs.isEmpty()) return 1f
        val i = lastIndex(tMs)
        if (i < 0) return 0f
        val interval = if (i + 1 < beatsMs.size) (beatsMs[i + 1] - beatsMs[i]).toFloat() else 500f
        val d = decayMs ?: (interval * 0.35f).coerceIn(80f, 260f)
        val k = 0.55f + 0.45f * strength.getOrElse(i) { 1f }
        return exp(-(tMs - beatsMs[i]) / d) * k
    }

    fun nearest(tMs: Long): Long {
        if (beatsMs.isEmpty()) return tMs
        val i = lastIndex(tMs)
        val a = beatsMs.getOrNull(i); val b = beatsMs.getOrNull(i + 1)
        return when { a == null -> b!!; b == null -> a; abs(tMs - a) <= abs(b - tMs) -> a; else -> b }
    }

    fun shifted(deltaMs: Long) = BeatMap(LongArray(beatsMs.size) { beatsMs[it] + deltaMs }, strength, bpm)

    /** Every [n]-th beat starting at index [phase]; n=0.5 gives half-beats (midpoints). */
    fun grouped(n: Float, phase: Int): LongArray {
        if (beatsMs.isEmpty()) return LongArray(0)
        if (n < 1f) {
            val out = ArrayList<Long>()
            for (i in beatsMs.indices) { out.add(beatsMs[i]); if (i + 1 < beatsMs.size) out.add((beatsMs[i] + beatsMs[i + 1]) / 2) }
            return out.toLongArray()
        }
        val step = n.toInt()
        return beatsMs.filterIndexed { i, _ -> i >= phase && (i - phase) % step == 0 }.toLongArray()
    }

    companion object {
        val EMPTY = BeatMap(LongArray(0), FloatArray(0), 0f)

        /** Applies the user's manual corrections (move all, delete, add, double/half tempo) to the detected beats. */
        fun build(a: AudioAnalysis, e: BeatEdit?): BeatMap {
            var t = a.beatsMs.toMutableList(); var s = a.beatStrength.toMutableList()
            if (e == null) return BeatMap(t.toLongArray(), s.toFloatArray(), a.bpm)
            run { // remove
                val keep = t.indices.filter { i -> e.removed.none { r -> abs(r - t[i]) <= 60 } }
                t = keep.map { t[it] }.toMutableList(); s = keep.map { s[it] }.toMutableList()
            }
            e.added.forEach { t.add(it); s.add(0.8f) }
            val order = t.indices.sortedBy { t[it] }
            t = order.map { t[it] }.toMutableList(); s = order.map { s[it] }.toMutableList()
            var bpm = a.bpm
            if (e.doubleTempo) {
                val nt = ArrayList<Long>(); val ns = ArrayList<Float>()
                for (i in t.indices) { nt.add(t[i]); ns.add(s[i]); if (i + 1 < t.size) { nt.add((t[i] + t[i + 1]) / 2); ns.add(s[i] * 0.6f) } }
                t = nt; s = ns; bpm *= 2f
            } else if (e.halfTempo) {
                val idx = t.indices.filter { it % 2 == 0 }
                t = idx.map { t[it] }.toMutableList(); s = idx.map { s[it] }.toMutableList(); bpm /= 2f
            }
            return BeatMap(LongArray(t.size) { t[it] + e.shiftMs }, s.toFloatArray(), bpm)
        }
    }
}
