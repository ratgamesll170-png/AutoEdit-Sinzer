package com.sinzer.autoedit.media

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaCodecList
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.OpenableColumns
import android.util.LruCache
import com.sinzer.autoedit.model.MediaAsset
import com.sinzer.autoedit.model.MediaType
import com.sinzer.autoedit.model.newId
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

class UnsupportedMediaException(msg: String) : Exception(msg)

object MediaProbe {
    val PICK_TYPES = arrayOf("video/*", "audio/*", "image/*")

    fun persist(ctx: Context, uri: Uri) {
        runCatching { ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
    }

    fun displayName(ctx: Context, uri: Uri): String = runCatching {
        ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0) else null
        }
    }.getOrNull() ?: (uri.lastPathSegment ?: "media")

    private fun size(ctx: Context, uri: Uri): Long = runCatching {
        ctx.contentResolver.query(uri, arrayOf(OpenableColumns.SIZE), null, null, null)?.use { c -> if (c.moveToFirst()) c.getLong(0) else 0L }
    }.getOrNull() ?: 0L

    fun exists(ctx: Context, uri: String): Boolean = runCatching {
        ctx.contentResolver.openFileDescriptor(Uri.parse(uri), "r")?.use { true } ?: false
    }.getOrDefault(false)

    /** Reads metadata and checks that this device can decode the file. Throws [UnsupportedMediaException] with a Thai message. */
    suspend fun probe(ctx: Context, uri: Uri): MediaAsset = withContext(Dispatchers.IO) {
        persist(ctx, uri)
        val name = displayName(ctx, uri)
        val mime = ctx.contentResolver.getType(uri) ?: when (name.substringAfterLast('.', "").lowercase()) {
            "mp4", "mov", "mkv", "webm", "3gp" -> "video/*"; "mp3", "wav", "aac", "m4a", "ogg", "flac" -> "audio/*"
            "jpg", "jpeg", "png", "webp" -> "image/*"; else -> ""
        }
        val sz = size(ctx, uri)
        try {
            when {
                mime.startsWith("image/") -> {
                    val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                    ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
                    if (o.outWidth <= 0) throw UnsupportedMediaException("ไม่สามารถอ่านรูปภาพ “$name” ได้ (ไฟล์อาจเสียหาย)")
                    MediaAsset(newId(), uri.toString(), MediaType.IMAGE, name, 0, o.outWidth, o.outHeight, sizeBytes = sz)
                }
                mime.startsWith("audio/") -> {
                    val r = MediaMetadataRetriever()
                    try {
                        r.setDataSource(ctx, uri)
                        val d = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
                        if (d <= 0) throw UnsupportedMediaException("อ่านความยาวไฟล์เสียง “$name” ไม่ได้")
                        MediaAsset(newId(), uri.toString(), MediaType.AUDIO, name, d, hasAudio = true, sizeBytes = sz)
                    } finally { runCatching { r.release() } }
                }
                mime.startsWith("video/") -> probeVideo(ctx, uri, name, sz)
                else -> throw UnsupportedMediaException("ไม่รองรับไฟล์ชนิดนี้: “$name” (รองรับ วิดีโอ เสียง และรูปภาพ)")
            }
        } catch (e: UnsupportedMediaException) { throw e
        } catch (e: Exception) { throw UnsupportedMediaException("เปิดไฟล์ “$name” ไม่ได้: ไฟล์เสียหายหรือไม่ได้รับสิทธิ์เข้าถึง") }
    }

    private fun probeVideo(ctx: Context, uri: Uri, name: String, sz: Long): MediaAsset {
        val r = MediaMetadataRetriever()
        val ex = MediaExtractor()
        try {
            r.setDataSource(ctx, uri)
            ex.setDataSource(ctx, uri, null)
            var w = 0; var h = 0; var fps = 30f; var vFmt: MediaFormat? = null; var audio = false
            for (i in 0 until ex.trackCount) {
                val f = ex.getTrackFormat(i); val m = f.getString(MediaFormat.KEY_MIME) ?: continue
                if (m.startsWith("video/") && vFmt == null) {
                    vFmt = f; w = f.getInteger(MediaFormat.KEY_WIDTH); h = f.getInteger(MediaFormat.KEY_HEIGHT)
                    if (f.containsKey(MediaFormat.KEY_FRAME_RATE)) fps = runCatching { f.getInteger(MediaFormat.KEY_FRAME_RATE).toFloat() }.getOrDefault(30f)
                }
                if (m.startsWith("audio/")) audio = true
            }
            if (vFmt == null) throw UnsupportedMediaException("ไม่พบภาพวิดีโอในไฟล์ “$name”")
            val list = MediaCodecList(MediaCodecList.REGULAR_CODECS)
            if (list.findDecoderForFormat(vFmt) == null)
                throw UnsupportedMediaException("เครื่องนี้ถอดรหัสวิดีโอ “$name” ไม่ได้ (${vFmt.getString(MediaFormat.KEY_MIME)}) ลองแปลงไฟล์เป็น H.264 ก่อน")
            val rot = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
            if (rot == 90 || rot == 270) { val t = w; w = h; h = t }
            val d = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            if (d <= 0) throw UnsupportedMediaException("อ่านความยาววิดีโอ “$name” ไม่ได้")
            return MediaAsset(newId(), uri.toString(), MediaType.VIDEO, name, d, w, h, fps.coerceIn(1f, 240f), audio, sz)
        } finally { runCatching { r.release() }; runCatching { ex.release() } }
    }
}

object Thumbs {
    private val cache = object : LruCache<String, Bitmap>(40 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap) = value.byteCount
    }
    private val sem = Semaphore(2)

    fun peek(a: MediaAsset, atMs: Long, h: Int): Bitmap? = cache.get(key(a, atMs, h))
    private fun key(a: MediaAsset, atMs: Long, h: Int) = "${a.id}@${atMs / 500 * 500}@$h"

    suspend fun load(ctx: Context, a: MediaAsset, atMs: Long, h: Int): Bitmap? {
        val k = key(a, atMs, h)
        cache.get(k)?.let { return it }
        return sem.withPermit {
            withContext(Dispatchers.IO) {
                cache.get(k) ?: runCatching {
                    val bmp: Bitmap? = when (a.type) {
                        MediaType.VIDEO -> {
                            val r = MediaMetadataRetriever()
                            try {
                                r.setDataSource(ctx, Uri.parse(a.uri))
                                val w = if (a.height > 0) (h * a.width.toFloat() / a.height).toInt().coerceAtLeast(16) else h
                                r.getScaledFrameAtTime((atMs / 500 * 500) * 1000, MediaMetadataRetriever.OPTION_CLOSEST_SYNC, w, h)
                            } finally { runCatching { r.release() } }
                        }
                        MediaType.IMAGE -> decodeImage(ctx, Uri.parse(a.uri), h)
                        else -> null
                    }
                    bmp?.also { cache.put(k, it) }
                }.getOrNull()
            }
        }
    }

    fun decodeImage(ctx: Context, uri: Uri, targetH: Int): Bitmap? {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
        if (o.outHeight <= 0) return null
        var s = 1
        while (o.outHeight / (s * 2) >= targetH) s *= 2
        val o2 = BitmapFactory.Options().apply { inSampleSize = s }
        return ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o2) }
    }
}

object FrameGrab {
    /** Saves the exact frame at [atMs] as a PNG (used for Freeze Frame). */
    suspend fun savePng(ctx: Context, a: MediaAsset, atMs: Long): File? = withContext(Dispatchers.IO) {
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(ctx, Uri.parse(a.uri))
            val bmp = r.getFrameAtTime(atMs * 1000, MediaMetadataRetriever.OPTION_CLOSEST) ?: return@withContext null
            val f = File(File(ctx.filesDir, "freeze").apply { mkdirs() }, "f_${newId()}.png")
            FileOutputStream(f).use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
            f
        } catch (e: Exception) { null } finally { runCatching { r.release() } }
    }
}
