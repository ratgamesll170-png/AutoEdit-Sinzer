package com.sinzer.autoedit.model

import kotlin.math.abs

enum class ItemKind { CLIP, TEXT, STICKER, FX }
data class Sel(val kind: ItemKind, val id: String)
data class Span(val trackId: String, val start: Long, val end: Long, val sel: Sel)

const val MIN_ITEM_MS = 100L
const val IMAGE_DEFAULT_MS = 3000L

/** Pure functions that edit a [Project]. Original media files are never touched. */
object Ops {

    fun spans(p: Project): List<Span> = buildList {
        p.clips.forEach { add(Span(it.trackId, it.startMs, it.endMs(), Sel(ItemKind.CLIP, it.id))) }
        p.texts.forEach { add(Span(it.trackId, it.startMs, it.startMs + it.durMs, Sel(ItemKind.TEXT, it.id))) }
        p.stickers.forEach { add(Span(it.trackId, it.startMs, it.startMs + it.durMs, Sel(ItemKind.STICKER, it.id))) }
        p.fxItems.forEach { add(Span(it.trackId, it.startMs, it.startMs + it.durMs, Sel(ItemKind.FX, it.id))) }
    }

    fun span(p: Project, s: Sel): Span? = spans(p).firstOrNull { it.sel == s }

    /** Main track is magnetic: clips are always contiguous, in order. */
    fun relayoutMain(p: Project): Project {
        val main = p.mainTrackId
        var t = 0L
        val ordered = p.clips.filter { it.trackId == main }.sortedBy { it.startMs }
        val moved = ordered.associate { c -> val n = c.copy(startMs = t); t += clipDurMs(c); c.id to n }
        return p.copy(clips = p.clips.map { moved[it.id] ?: it })
    }

    fun mediaToClip(a: MediaAsset, trackId: String, start: Long, audioOnly: Boolean = false): Clip {
        val dur = if (a.type == MediaType.IMAGE) IMAGE_DEFAULT_MS else a.durationMs
        return Clip(assetId = a.id, trackId = trackId, startMs = start, inMs = 0, outMs = dur, audioOnly = audioOnly)
    }

    fun addAssets(p: Project, list: List<MediaAsset>): Project =
        p.copy(assets = p.assets + list.filter { n -> p.assets.none { it.id == n.id } })

    fun appendToMain(p: Project, a: MediaAsset): Project {
        if (a.type == MediaType.AUDIO) return addAudio(p, a, firstAudioTrack(p), 0L)
        val end = p.clips.filter { it.trackId == p.mainTrackId }.maxOfOrNull { it.endMs() } ?: 0L
        val c = mediaToClip(a, p.mainTrackId, end)
        return relayoutMain(addAssets(p, listOf(a)).copy(clips = p.clips + c))
    }

    fun firstAudioTrack(p: Project) = p.tracks.first { it.kind == TrackKind.AUDIO }.id

    fun addAudio(p: Project, a: MediaAsset, trackId: String, start: Long, audioOnly: Boolean = a.type == MediaType.VIDEO): Project {
        val c = mediaToClip(a, trackId, start, audioOnly)
        return resolveOverlap(addAssets(p, listOf(a)).copy(clips = p.clips + c), Sel(ItemKind.CLIP, c.id))
    }

    fun updateClip(p: Project, id: String, f: (Clip) -> Clip): Project =
        relayoutMain(p.copy(clips = p.clips.map { if (it.id == id) f(it) else it }))

    fun updateText(p: Project, id: String, f: (TextItem) -> TextItem) = p.copy(texts = p.texts.map { if (it.id == id) f(it) else it })
    fun updateSticker(p: Project, id: String, f: (StickerItem) -> StickerItem) = p.copy(stickers = p.stickers.map { if (it.id == id) f(it) else it })
    fun updateFxItem(p: Project, id: String, f: (FxItem) -> FxItem) = p.copy(fxItems = p.fxItems.map { if (it.id == id) f(it) else it })

    // ---- split ----
    fun split(p: Project, sel: Sel, atMs: Long): Project? {
        when (sel.kind) {
            ItemKind.CLIP -> {
                val c = p.clips.firstOrNull { it.id == sel.id } ?: return null
                val d = clipDurMs(c)
                val local = atMs - c.startMs
                if (local < MIN_ITEM_MS || local > d - MIN_ITEM_MS) return null
                val cut = sourceAtLocal(c, local)
                val fa = (cut - c.inMs).toFloat() / (c.outMs - c.inMs).coerceAtLeast(1)
                val left = c.copy(outMs = cut, transition = null, fadeOutMs = 0, speedCurve = subCurve(c, 0f, fa),
                    keyframes = c.keyframes.map { k -> k.copy(keys = k.keys.filter { it.tMs <= local }) })
                val right = c.copy(id = newId(), startMs = c.startMs + local, inMs = cut, fadeInMs = 0, speedCurve = subCurve(c, fa, 1f),
                    keyframes = c.keyframes.map { k -> k.copy(keys = k.keys.map { it.copy(tMs = (it.tMs - local).coerceAtLeast(0)) }) })
                val clips = p.clips.flatMap { if (it.id == c.id) listOf(left, right) else listOf(it) }
                return relayoutMain(p.copy(clips = clips))
            }
            ItemKind.TEXT -> {
                val t = p.texts.firstOrNull { it.id == sel.id } ?: return null
                val local = atMs - t.startMs
                if (local < MIN_ITEM_MS || local > t.durMs - MIN_ITEM_MS) return null
                val a = t.copy(durMs = local)
                val b = t.copy(id = newId(), startMs = atMs, durMs = t.durMs - local)
                return p.copy(texts = p.texts.flatMap { if (it.id == t.id) listOf(a, b) else listOf(it) })
            }
            ItemKind.STICKER -> {
                val t = p.stickers.firstOrNull { it.id == sel.id } ?: return null
                val local = atMs - t.startMs
                if (local < MIN_ITEM_MS || local > t.durMs - MIN_ITEM_MS) return null
                return p.copy(stickers = p.stickers.flatMap {
                    if (it.id == t.id) listOf(t.copy(durMs = local), t.copy(id = newId(), startMs = atMs, durMs = t.durMs - local)) else listOf(it) })
            }
            ItemKind.FX -> {
                val t = p.fxItems.firstOrNull { it.id == sel.id } ?: return null
                val local = atMs - t.startMs
                if (local < MIN_ITEM_MS || local > t.durMs - MIN_ITEM_MS) return null
                return p.copy(fxItems = p.fxItems.flatMap {
                    if (it.id == t.id) listOf(t.copy(durMs = local), t.copy(id = newId(), startMs = atMs, durMs = t.durMs - local, fx = t.fx.copy(id = newId()))) else listOf(it) })
            }
        }
    }

    /** Re-sample a speed curve for the sub range [a,b] (fractions of source range) back onto 0..1. */
    private fun subCurve(c: Clip, a: Float, b: Float): List<SpeedPoint> {
        if (c.speedCurve.isEmpty() || (a == 0f && b == 1f)) return c.speedCurve
        val n = 8
        return (0..n).map { i -> val f = i / n.toFloat(); SpeedPoint(f, speedAt(c, a + (b - a) * f)) }
    }

    // ---- delete / duplicate ----
    fun delete(p: Project, sel: Sel): Project = when (sel.kind) {
        ItemKind.CLIP -> relayoutMain(p.copy(clips = p.clips.filterNot { it.id == sel.id }))
        ItemKind.TEXT -> p.copy(texts = p.texts.filterNot { it.id == sel.id })
        ItemKind.STICKER -> p.copy(stickers = p.stickers.filterNot { it.id == sel.id })
        ItemKind.FX -> p.copy(fxItems = p.fxItems.filterNot { it.id == sel.id })
    }

    fun duplicate(p: Project, sel: Sel): Project {
        val sp = span(p, sel) ?: return p
        val at = sp.end
        return when (sel.kind) {
            ItemKind.CLIP -> {
                val c = p.clips.first { it.id == sel.id }
                val n = c.copy(id = newId(), startMs = at, fx = c.fx.map { it.copy(id = newId()) })
                val q = p.copy(clips = p.clips + n)
                if (c.trackId == p.mainTrackId) relayoutMain(q.copy(clips = q.clips.map { if (it.id == n.id) n.copy(startMs = at - 1) else it }))
                else resolveOverlap(q, Sel(ItemKind.CLIP, n.id))
            }
            ItemKind.TEXT -> { val t = p.texts.first { it.id == sel.id }; val n = t.copy(id = newId(), startMs = at); resolveOverlap(p.copy(texts = p.texts + n), Sel(ItemKind.TEXT, n.id)) }
            ItemKind.STICKER -> { val t = p.stickers.first { it.id == sel.id }; val n = t.copy(id = newId(), startMs = at); resolveOverlap(p.copy(stickers = p.stickers + n), Sel(ItemKind.STICKER, n.id)) }
            ItemKind.FX -> { val t = p.fxItems.first { it.id == sel.id }; val n = t.copy(id = newId(), startMs = at, fx = t.fx.copy(id = newId())); resolveOverlap(p.copy(fxItems = p.fxItems + n), Sel(ItemKind.FX, n.id)) }
        }
    }

    // ---- move ----
    fun reorderMain(p: Project, clipId: String, toCenterMs: Long): Project {
        val main = p.clips.filter { it.trackId == p.mainTrackId }.sortedBy { it.startMs }
        val moving = main.firstOrNull { it.id == clipId } ?: return p
        val others = main.filter { it.id != clipId }
        val idx = others.count { it.startMs + clipDurMs(it) / 2 < toCenterMs }
        val order = others.toMutableList().apply { add(idx, moving) }
        var t = 0L
        val starts = order.associate { c -> val s = t; t += clipDurMs(c); c.id to s }
        return p.copy(clips = p.clips.map { c -> starts[c.id]?.let { c.copy(startMs = it) } ?: c })
    }

    fun move(p: Project, sel: Sel, newStart: Long, newTrack: String? = null): Project {
        val st = newStart.coerceAtLeast(0)
        val q = when (sel.kind) {
            ItemKind.CLIP -> {
                val c = p.clips.firstOrNull { it.id == sel.id } ?: return p
                if (c.trackId == p.mainTrackId && (newTrack == null || newTrack == c.trackId))
                    return reorderMain(p, c.id, st + clipDurMs(c) / 2)
                p.copy(clips = p.clips.map { if (it.id == c.id) it.copy(startMs = st, trackId = newTrack ?: it.trackId) else it })
            }
            ItemKind.TEXT -> p.copy(texts = p.texts.map { if (it.id == sel.id) it.copy(startMs = st, trackId = newTrack ?: it.trackId) else it })
            ItemKind.STICKER -> p.copy(stickers = p.stickers.map { if (it.id == sel.id) it.copy(startMs = st, trackId = newTrack ?: it.trackId) else it })
            ItemKind.FX -> p.copy(fxItems = p.fxItems.map { if (it.id == sel.id) it.copy(startMs = st, trackId = newTrack ?: it.trackId) else it })
        }
        return resolveOverlap(q, sel)
    }

    /** Items on the same non-main track must not overlap; push the moved item after what it hits. */
    fun resolveOverlap(p: Project, sel: Sel): Project {
        val me = span(p, sel) ?: return p
        if (me.trackId == p.mainTrackId) return p
        var start = me.start
        val len = me.end - me.start
        val others = spans(p).filter { it.trackId == me.trackId && it.sel != sel }.sortedBy { it.start }
        var changed = true
        var guard = 0
        while (changed && guard++ < 200) {
            changed = false
            for (o in others) if (start < o.end && start + len > o.start) { start = o.end; changed = true }
        }
        return if (start == me.start) p else move0(p, sel, start)
    }

    private fun move0(p: Project, sel: Sel, st: Long) = when (sel.kind) {
        ItemKind.CLIP -> p.copy(clips = p.clips.map { if (it.id == sel.id) it.copy(startMs = st) else it })
        ItemKind.TEXT -> p.copy(texts = p.texts.map { if (it.id == sel.id) it.copy(startMs = st) else it })
        ItemKind.STICKER -> p.copy(stickers = p.stickers.map { if (it.id == sel.id) it.copy(startMs = st) else it })
        ItemKind.FX -> p.copy(fxItems = p.fxItems.map { if (it.id == sel.id) it.copy(startMs = st) else it })
    }

    // ---- trim ----
    /** side 0 = start handle, 1 = end handle. deltaMs is timeline ms (positive = to the right). */
    fun trim(p: Project, sel: Sel, side: Int, deltaMs: Long): Project {
        when (sel.kind) {
            ItemKind.CLIP -> {
                val c = p.clips.firstOrNull { it.id == sel.id } ?: return p
                val a = p.asset(c.assetId)
                val maxOut = if (a == null || a.type == MediaType.IMAGE) Long.MAX_VALUE else a.durationMs
                val dur = clipDurMs(c)
                if (side == 0) {
                    val d = deltaMs.coerceIn(-c.startMs.coerceAtLeast(0).let { if (c.trackId == p.mainTrackId) Long.MAX_VALUE else it }, dur - MIN_ITEM_MS)
                    val newIn = if (d >= 0) sourceAtLocal(c, d) else (c.inMs + (d * c.speed).toLong())
                    val clampedIn = newIn.coerceIn(0, c.outMs - MIN_ITEM_MS)
                    val fa = (clampedIn - c.inMs).toFloat() / (c.outMs - c.inMs).coerceAtLeast(1)
                    val actualD = if (clampedIn == newIn) d else ((clampedIn - c.inMs) / c.speed).toLong()
                    val n = c.copy(inMs = clampedIn, startMs = if (c.trackId == p.mainTrackId) c.startMs else c.startMs + actualD,
                        speedCurve = if (fa >= 0) subCurve(c, fa.coerceAtLeast(0f), 1f) else c.speedCurve)
                    return relayoutMain(resolveOverlap(p.copy(clips = p.clips.map { if (it.id == c.id) n else it }), sel))
                } else {
                    val newDur = (dur + deltaMs).coerceAtLeast(MIN_ITEM_MS)
                    val newOut = if (newDur <= dur) sourceAtLocal(c, newDur) else (c.outMs + ((newDur - dur) * c.speed).toLong())
                    val out = newOut.coerceIn(c.inMs + MIN_ITEM_MS, maxOut)
                    val fb = (out - c.inMs).toFloat() / (c.outMs - c.inMs).coerceAtLeast(1)
                    val n = c.copy(outMs = out, speedCurve = if (fb <= 1f) subCurve(c, 0f, fb) else c.speedCurve)
                    return relayoutMain(resolveOverlap(p.copy(clips = p.clips.map { if (it.id == c.id) n else it }), sel))
                }
            }
            else -> {
                val sp = span(p, sel) ?: return p
                val (ns, nd) = if (side == 0) {
                    val s2 = (sp.start + deltaMs).coerceIn(0, sp.end - MIN_ITEM_MS); s2 to (sp.end - s2)
                } else sp.start to (sp.end - sp.start + deltaMs).coerceAtLeast(MIN_ITEM_MS)
                return resolveOverlap(when (sel.kind) {
                    ItemKind.TEXT -> p.copy(texts = p.texts.map { if (it.id == sel.id) it.copy(startMs = ns, durMs = nd) else it })
                    ItemKind.STICKER -> p.copy(stickers = p.stickers.map { if (it.id == sel.id) it.copy(startMs = ns, durMs = nd) else it })
                    else -> p.copy(fxItems = p.fxItems.map { if (it.id == sel.id) it.copy(startMs = ns, durMs = nd) else it })
                }, sel)
            }
        }
    }

    // ---- tracks ----
    fun addTrack(p: Project, kind: TrackKind): Project {
        val n = p.tracks.count { it.kind == kind } + 1
        val id = "${kind.name.take(1)}${kind.name.length}_${newId().take(4)}"
        val name = when (kind) {
            TrackKind.AUDIO -> "เสียง $n"; TrackKind.TEXT -> "ข้อความ $n"; TrackKind.OVERLAY -> "โอเวอร์เลย์ $n"
            TrackKind.STICKER -> "สติ๊กเกอร์ $n"; TrackKind.EFFECT -> "เอฟเฟกต์ $n"; TrackKind.VIDEO -> "วิดีโอ $n"
        }
        return p.copy(tracks = p.tracks + Track(id, kind, name))
    }

    fun updateTrack(p: Project, id: String, f: (Track) -> Track) = p.copy(tracks = p.tracks.map { if (it.id == id) f(it) else it })

    // ---- snapping ----
    fun snap(p: Project, t: Long, playhead: Long, beats: LongArray, thresholdMs: Long, exclude: Sel?): Long {
        var best = t; var bd = thresholdMs + 1
        fun consider(v: Long) { val d = abs(v - t); if (d < bd) { bd = d; best = v } }
        consider(0); consider(playhead)
        spans(p).filter { it.sel != exclude }.forEach { consider(it.start); consider(it.end) }
        if (p.snap) beats.forEach { consider(it) }
        return if (bd <= thresholdMs) best else t
    }

    fun snapAll(p: Project, start: Long, len: Long, playhead: Long, beats: LongArray, th: Long, ex: Sel?): Long {
        val s = snap(p, start, playhead, beats, th, ex)
        if (s != start) return s
        val e = snap(p, start + len, playhead, beats, th, ex)
        return if (e != start + len) e - len else start
    }

    // ---- keyframes ----
    fun setKeyframe(keys: List<KfTrack>, prop: String, tMs: Long, v: Float): List<KfTrack> {
        val cur = keys.firstOrNull { it.prop == prop }?.keys ?: emptyList()
        val upd = (cur.filter { abs(it.tMs - tMs) > 30 } + Keyframe(tMs.coerceAtLeast(0), v)).sortedBy { it.tMs }
        return if (keys.any { it.prop == prop }) keys.map { if (it.prop == prop) it.copy(keys = upd) else it } else keys + KfTrack(prop, upd)
    }

    fun removeKeyframe(keys: List<KfTrack>, prop: String, tMs: Long): List<KfTrack> =
        keys.map { if (it.prop == prop) it.copy(keys = it.keys.filter { k -> k.tMs != tMs }) else it }.filter { it.keys.isNotEmpty() }
}
