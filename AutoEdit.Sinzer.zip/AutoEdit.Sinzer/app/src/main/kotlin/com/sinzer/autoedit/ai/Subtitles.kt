package com.sinzer.autoedit.ai

import android.content.Context
import android.net.Uri
import com.sinzer.autoedit.audio.AudioDecoder
import com.sinzer.autoedit.audio.BeatTracker
import com.sinzer.autoedit.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.*
import java.io.ByteArrayOutputStream
import java.io.DataOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import kotlin.math.min

class SubLine(val startMs: Long, val endMs: Long, val text: String, val words: List<WordTiming>)

object Srt {
    private fun ts(ms: Long): String = String.format(Locale.US, "%02d:%02d:%02d,%03d", ms / 3600000, ms / 60000 % 60, ms / 1000 % 60, ms % 1000)
    fun format(lines: List<SubLine>): String = lines.sortedBy { it.startMs }.mapIndexed { i, l ->
        "${i + 1}\n${ts(l.startMs)} --> ${ts(l.endMs)}\n${l.text}\n"
    }.joinToString("\n")

    fun parse(text: String): List<SubLine> {
        val out = ArrayList<SubLine>()
        val re = Regex("(\\d+):(\\d+):(\\d+)[,.](\\d+)\\s*-->\\s*(\\d+):(\\d+):(\\d+)[,.](\\d+)")
        val blocks = text.replace("\r", "").split(Regex("\n\\s*\n"))
        for (b in blocks) {
            val ls = b.trim().lines()
            val idx = ls.indexOfFirst { re.containsMatchIn(it) }
            if (idx < 0) continue
            val m = re.find(ls[idx])!!.groupValues.drop(1).map { it.toLong() }
            val s = m[0] * 3600000 + m[1] * 60000 + m[2] * 1000 + m[3]
            val e = m[4] * 3600000 + m[5] * 60000 + m[6] * 1000 + m[7]
            val t = ls.drop(idx + 1).joinToString("\n").trim()
            if (t.isNotEmpty() && e > s) out.add(SubLine(s, e, t, emptyList()))
        }
        return out
    }
}

/**
 * Speech-to-text through the OpenAI Whisper HTTP API (an EXTERNAL, PAID service; the user supplies their own API key in Settings).
 * Nothing is uploaded unless the user explicitly presses "Create subtitles". Audio is uploaded as 16 kHz mono WAV in chunks of <= 10 min.
 */
object WhisperClient {
    const val PRICE_NOTE = "ใช้บริการ OpenAI Whisper ค่าบริการประมาณ 0.006 ดอลลาร์สหรัฐต่อนาทีของเสียง (ตรวจสอบราคาล่าสุดกับผู้ให้บริการ) ไฟล์เสียงจะถูกอัปโหลดไปยังเซิร์ฟเวอร์ของ OpenAI"

    /** Decodes [assetUri]'s audio, cuts [fromMs, toMs] and returns timed lines relative to [fromMs]. */
    suspend fun transcribe(ctx: Context, assetUri: String, fromMs: Long, toMs: Long, language: String?, apiKey: String,
                           onProgress: (Float) -> Unit): List<SubLine> {
        val pcm = decode16k(ctx, assetUri, fromMs, toMs) ?: return emptyList()
        val chunkSamples = 16000 * 600
        val lines = ArrayList<SubLine>()
        var off = 0; var idx = 0; val total = (pcm.size + chunkSamples - 1) / chunkSamples
        while (off < pcm.size) {
            val end = min(pcm.size, off + chunkSamples)
            val wav = wav(pcm, off, end)
            val base = off * 1000L / 16000
            lines += post(wav, language, apiKey).map { SubLine(it.startMs + base, it.endMs + base, it.text, it.words.map { w -> WordTiming(w.text, w.startMs + base, w.endMs + base) }) }
            off = end; idx++; onProgress(idx / total.toFloat())
        }
        return lines
    }

    private suspend fun decode16k(ctx: Context, uri: String, fromMs: Long, toMs: Long): ShortArray? {
        val all = ArrayList<Short>(1 shl 20)
        var pos = 0.0; val ratio = BeatTracker.SR / 16000.0; var sIdx = 0L
        val startS = fromMs * BeatTracker.SR / 1000; val endS = toMs * BeatTracker.SR / 1000
        var prev = 0f; var have = false
        val ok = AudioDecoder.decode(ctx, Uri.parse(uri), { buf, n ->
            for (i in 0 until n) {
                val gi = sIdx + i
                if (gi < startS || gi >= endS) continue
                // linear-interpolated resample 22050 -> 16000
                val cur = buf[i]
                if (!have) { prev = cur; have = true; continue }
                while (pos < 1.0) { val v = prev + (cur - prev) * pos.toFloat(); all.add((v * 32767f).toInt().coerceIn(-32768, 32767).toShort()); pos += ratio }
                pos -= 1.0; prev = cur
            }
            sIdx += n
        }, {})
        return if (ok && all.isNotEmpty()) all.toShortArray() else null
    }

    private fun wav(pcm: ShortArray, from: Int, to: Int): ByteArray {
        val n = to - from; val bos = ByteArrayOutputStream(44 + n * 2); val d = DataOutputStream(bos)
        fun le32(v: Int) { d.write(v and 255); d.write(v shr 8 and 255); d.write(v shr 16 and 255); d.write(v shr 24 and 255) }
        fun le16(v: Int) { d.write(v and 255); d.write(v shr 8 and 255) }
        d.writeBytes("RIFF"); le32(36 + n * 2); d.writeBytes("WAVEfmt "); le32(16); le16(1); le16(1); le32(16000); le32(32000); le16(2); le16(16)
        d.writeBytes("data"); le32(n * 2)
        for (i in from until to) le16(pcm[i].toInt())
        return bos.toByteArray()
    }

    private suspend fun post(wav: ByteArray, language: String?, key: String): List<SubLine> = withContext(Dispatchers.IO) {
        val boundary = "----FlashCut${System.nanoTime()}"
        val con = URL("https://api.openai.com/v1/audio/transcriptions").openConnection() as HttpURLConnection
        con.requestMethod = "POST"; con.doOutput = true; con.connectTimeout = 20000; con.readTimeout = 180000
        con.setRequestProperty("Authorization", "Bearer $key")
        con.setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
        DataOutputStream(con.outputStream).use { o ->
            fun field(name: String, v: String) { o.writeBytes("--$boundary\r\nContent-Disposition: form-data; name=\"$name\"\r\n\r\n$v\r\n") }
            field("model", "whisper-1"); field("response_format", "verbose_json")
            field("timestamp_granularities[]", "word"); field("timestamp_granularities[]", "segment")
            if (!language.isNullOrBlank()) field("language", language)
            o.writeBytes("--$boundary\r\nContent-Disposition: form-data; name=\"file\"; filename=\"audio.wav\"\r\nContent-Type: audio/wav\r\n\r\n")
            o.write(wav); o.writeBytes("\r\n--$boundary--\r\n")
        }
        val code = con.responseCode
        val body = (if (code in 200..299) con.inputStream else con.errorStream)?.bufferedReader()?.readText() ?: ""
        if (code !in 200..299) {
            val msg = runCatching { Json.parseToJsonElement(body).jsonObject["error"]?.jsonObject?.get("message")?.jsonPrimitive?.content }.getOrNull()
            throw IllegalStateException(when (code) { 401 -> "API Key ไม่ถูกต้อง"; 429 -> "เกินโควต้าหรือเรียกถี่เกินไป"; else -> "บริการคำบรรยายผิดพลาด ($code) ${msg ?: ""}" })
        }
        val root = Json.parseToJsonElement(body).jsonObject
        val words = root["words"]?.jsonArray?.map {
            val o = it.jsonObject
            WordTiming(o["word"]!!.jsonPrimitive.content.trim(), (o["start"]!!.jsonPrimitive.double * 1000).toLong(), (o["end"]!!.jsonPrimitive.double * 1000).toLong())
        } ?: emptyList()
        root["segments"]?.jsonArray?.mapNotNull {
            val o = it.jsonObject
            val s = (o["start"]!!.jsonPrimitive.double * 1000).toLong(); val e = (o["end"]!!.jsonPrimitive.double * 1000).toLong()
            val t = o["text"]!!.jsonPrimitive.content.trim()
            if (t.isEmpty()) null else SubLine(s, e, t, words.filter { w -> w.startMs >= s - 20 && w.endMs <= e + 20 })
        } ?: emptyList()
    }
}
