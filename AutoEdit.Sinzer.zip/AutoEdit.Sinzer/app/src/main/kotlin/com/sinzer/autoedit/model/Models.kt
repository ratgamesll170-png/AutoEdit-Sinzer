package com.sinzer.autoedit.model

import kotlinx.serialization.Serializable
import java.util.UUID

fun newId(): String = UUID.randomUUID().toString().take(12)

@Serializable enum class MediaType { VIDEO, AUDIO, IMAGE }
@Serializable enum class TrackKind { VIDEO, OVERLAY, AUDIO, TEXT, STICKER, EFFECT }
@Serializable enum class Ease { LINEAR, IN, OUT, IN_OUT, HOLD }
@Serializable enum class Aspect(val label: String, val w: Int, val h: Int) {
    R9_16("9:16", 9, 16), R16_9("16:9", 16, 9), R1_1("1:1", 1, 1), R4_5("4:5", 4, 5)
}

object Prop {
    const val X = "x"; const val Y = "y"; const val SCALE = "scale"; const val ROT = "rot"
    const val OPACITY = "opacity"; const val VOLUME = "volume"
    val all = listOf(X, Y, SCALE, ROT, OPACITY, VOLUME)
    fun labelTh(p: String) = when (p) {
        X -> "ตำแหน่งแนวนอน"; Y -> "ตำแหน่งแนวตั้ง"; SCALE -> "ขนาด"; ROT -> "การหมุน"
        OPACITY -> "ความโปร่งใส"; VOLUME -> "ระดับเสียง"; else -> p
    }
    fun range(p: String): ClosedFloatingPointRange<Float> = when (p) {
        X, Y -> -1f..1f; SCALE -> 0.1f..4f; ROT -> -360f..360f; OPACITY -> 0f..1f; VOLUME -> 0f..2f
        else -> 0f..1f
    }
    fun default(p: String) = when (p) { SCALE, OPACITY, VOLUME -> 1f; else -> 0f }
}

@Serializable
data class MediaAsset(
    val id: String, val uri: String, val type: MediaType, val name: String,
    val durationMs: Long, val width: Int = 0, val height: Int = 0, val fps: Float = 30f,
    val hasAudio: Boolean = false, val sizeBytes: Long = 0,
)

@Serializable data class Keyframe(val tMs: Long, val v: Float, val ease: Ease = Ease.LINEAR)
@Serializable data class KfTrack(val prop: String, val keys: List<Keyframe>)

@Serializable
data class FxInstance(
    val id: String = newId(), val presetId: String, val intensity: Float = 1f,
    val enabled: Boolean = true, val beatSync: Boolean = false,
    val startMs: Long = 0, val durMs: Long = -1,   // relative to the owner start; -1 = whole owner
)

@Serializable
data class ColorAdj(
    val exposure: Float = 0f, val brightness: Float = 0f, val contrast: Float = 0f, val saturation: Float = 0f,
    val temperature: Float = 0f, val tint: Float = 0f, val highlights: Float = 0f, val shadows: Float = 0f,
    val whites: Float = 0f, val blacks: Float = 0f, val hue: Float = 0f, val fade: Float = 0f,
    val vignette: Float = 0f, val grain: Float = 0f, val sharpen: Float = 0f,
) {
    fun isNeutral() = this == ColorAdj()
}

@Serializable data class SpeedPoint(val pos: Float, val speed: Float)
@Serializable data class TransitionRef(val presetId: String, val durMs: Long = 400, val intensity: Float = 1f, val dir: Int = 0)

@Serializable
data class Clip(
    val id: String = newId(), val assetId: String, val trackId: String,
    val startMs: Long, val inMs: Long, val outMs: Long,
    val speed: Float = 1f, val speedCurve: List<SpeedPoint> = emptyList(),
    val volume: Float = 1f, val muted: Boolean = false, val fadeInMs: Long = 0, val fadeOutMs: Long = 0,
    val fit: Boolean = false,
    val tx: Float = 0f, val ty: Float = 0f, val scale: Float = 1f, val rot: Float = 0f, val opacity: Float = 1f,
    val fx: List<FxInstance> = emptyList(), val color: ColorAdj = ColorAdj(), val colorPreset: String? = null,
    val transition: TransitionRef? = null,
    val keyframes: List<KfTrack> = emptyList(),
    val audioOnly: Boolean = false,   // video asset used only for its sound (extracted audio)
)

@Serializable data class TextAnimRef(
    val presetId: String, val phase: Int = 0,   // 0 = in, 1 = out, 2 = loop
    val durMs: Long = 600, val speed: Float = 1f, val strength: Float = 1f,
)
@Serializable data class WordTiming(val text: String, val startMs: Long, val endMs: Long)

@Serializable
data class TextItem(
    val id: String = newId(), val trackId: String, val text: String,
    val startMs: Long, val durMs: Long,
    val fontId: String = "sys:sans", val size: Float = 64f, val color: Int = 0xFFFFFFFF.toInt(),
    val bold: Boolean = true, val italic: Boolean = false, val letterSpacing: Float = 0f, val align: Int = 1,
    val strokeW: Float = 0f, val strokeColor: Int = 0xFF000000.toInt(),
    val shadow: Float = 0f, val shadowColor: Int = 0xFF000000.toInt(),
    val glow: Float = 0f, val glowColor: Int = 0xFF35D0FF.toInt(),
    val bgColor: Int = 0, val gradA: Int = 0, val gradB: Int = 0,
    val x: Float = 0.5f, val y: Float = 0.5f, val rot: Float = 0f, val scale: Float = 1f, val opacity: Float = 1f,
    val anims: List<TextAnimRef> = emptyList(), val words: List<WordTiming> = emptyList(),
    val subtitle: Boolean = false, val highlightColor: Int = 0xFFFFE14D.toInt(), val emphasis: Boolean = false,
    val keyframes: List<KfTrack> = emptyList(),
)

@Serializable
data class StickerItem(
    val id: String = newId(), val trackId: String, val emoji: String? = null, val imageUri: String? = null,
    val startMs: Long, val durMs: Long,
    val x: Float = 0.5f, val y: Float = 0.5f, val scale: Float = 1f, val rot: Float = 0f, val opacity: Float = 1f,
    val keyframes: List<KfTrack> = emptyList(),
)

@Serializable data class FxItem(val id: String = newId(), val trackId: String, val startMs: Long, val durMs: Long, val fx: FxInstance)

@Serializable data class Track(
    val id: String, val kind: TrackKind, val name: String,
    val locked: Boolean = false, val hidden: Boolean = false, val muted: Boolean = false,
)

@Serializable data class BeatEdit(
    val shiftMs: Long = 0, val removed: List<Long> = emptyList(), val added: List<Long> = emptyList(),
    val phase: Int = 0, val doubleTempo: Boolean = false, val halfTempo: Boolean = false,
)

@Serializable
data class Project(
    val id: String = newId(), val name: String = "โปรเจกต์ใหม่",
    val createdAt: Long = System.currentTimeMillis(), val updatedAt: Long = System.currentTimeMillis(),
    val aspect: Aspect = Aspect.R9_16, val fps: Int = 30,
    val assets: List<MediaAsset> = emptyList(), val tracks: List<Track> = defaultTracks(),
    val clips: List<Clip> = emptyList(), val texts: List<TextItem> = emptyList(),
    val stickers: List<StickerItem> = emptyList(), val fxItems: List<FxItem> = emptyList(),
    val beatEdits: Map<String, BeatEdit> = emptyMap(), val beatAssetId: String? = null,
    val snap: Boolean = true, val ducking: Boolean = false, val duckLevel: Float = 0.3f,
    val styleId: String? = null,
) {
    fun asset(id: String) = assets.firstOrNull { it.id == id }
    fun track(id: String) = tracks.firstOrNull { it.id == id }
    val mainTrackId: String get() = tracks.first { it.kind == TrackKind.VIDEO }.id
}

fun defaultTracks() = listOf(
    Track("V1", TrackKind.VIDEO, "วิดีโอหลัก"), Track("O1", TrackKind.OVERLAY, "โอเวอร์เลย์"),
    Track("S1", TrackKind.STICKER, "สติ๊กเกอร์"), Track("T1", TrackKind.TEXT, "ข้อความ"),
    Track("E1", TrackKind.EFFECT, "เอฟเฟกต์"), Track("A1", TrackKind.AUDIO, "เพลง"), Track("A2", TrackKind.AUDIO, "เสียงพากย์/อื่นๆ"),
)

// ---------- Derived helpers ----------

fun ease(e: Ease, t: Float): Float = when (e) {
    Ease.LINEAR -> t; Ease.IN -> t * t; Ease.OUT -> 1f - (1f - t) * (1f - t)
    Ease.IN_OUT -> if (t < .5f) 2f * t * t else 1f - 2f * (1f - t) * (1f - t)
    Ease.HOLD -> 0f
}

fun evalKf(keys: List<Keyframe>, tMs: Long, default: Float): Float {
    if (keys.isEmpty()) return default
    if (tMs <= keys.first().tMs) return keys.first().v
    if (tMs >= keys.last().tMs) return keys.last().v
    for (i in 0 until keys.size - 1) {
        val a = keys[i]; val b = keys[i + 1]
        if (tMs in a.tMs..b.tMs) {
            val span = (b.tMs - a.tMs).coerceAtLeast(1)
            val f = ease(a.ease, (tMs - a.tMs).toFloat() / span)
            return a.v + (b.v - a.v) * f
        }
    }
    return keys.last().v
}

fun List<KfTrack>.value(prop: String, tMs: Long, default: Float): Float =
    firstOrNull { it.prop == prop }?.let { evalKf(it.keys.sortedBy { k -> k.tMs }, tMs, default) } ?: default

fun speedAt(clip: Clip, pos: Float): Float {
    val c = clip.speedCurve
    if (c.isEmpty()) return clip.speed
    val s = c.sortedBy { it.pos }
    if (pos <= s.first().pos) return s.first().speed
    if (pos >= s.last().pos) return s.last().speed
    for (i in 0 until s.size - 1) if (pos in s[i].pos..s[i + 1].pos) {
        val f = (pos - s[i].pos) / (s[i + 1].pos - s[i].pos).coerceAtLeast(1e-4f)
        return s[i].speed + (s[i + 1].speed - s[i].speed) * f
    }
    return s.last().speed
}

/** Timeline length of a clip in ms (integrates 1/speed over the source range). */
fun clipDurMs(c: Clip): Long {
    val src = (c.outMs - c.inMs).coerceAtLeast(1)
    if (c.speedCurve.isEmpty()) return (src / c.speed.coerceAtLeast(0.05f)).toLong().coerceAtLeast(1)
    val n = 64; var acc = 0.0
    for (i in 0 until n) acc += 1.0 / speedAt(c, (i + 0.5f) / n).coerceAtLeast(0.05f)
    return (src * acc / n).toLong().coerceAtLeast(1)
}

fun Clip.endMs() = startMs + clipDurMs(this)

/** Source position (ms) that plays at [localMs] after the clip start. */
fun sourceAtLocal(c: Clip, localMs: Long): Long {
    val total = clipDurMs(c).coerceAtLeast(1)
    val src = (c.outMs - c.inMs).toDouble()
    if (c.speedCurve.isEmpty()) return (c.inMs + localMs * c.speed).toLong().coerceIn(c.inMs, c.outMs)
    val n = 256; var t = 0.0; var p = 0.0
    val target = localMs.coerceIn(0, total).toDouble()
    for (i in 0 until n) {
        val sp = speedAt(c, (i + 0.5f) / n).coerceAtLeast(0.05f)
        val dtSeg = src / n / sp
        if (t + dtSeg >= target) { p = (i + (target - t) / dtSeg) / n; return (c.inMs + src * p).toLong() }
        t += dtSeg
    }
    return c.outMs
}

fun Project.endMs(): Long {
    var e = clips.maxOfOrNull { it.endMs() } ?: 0L
    e = maxOf(e, texts.maxOfOrNull { it.startMs + it.durMs } ?: 0L)
    e = maxOf(e, stickers.maxOfOrNull { it.startMs + it.durMs } ?: 0L)
    return e
}

/** Length of the picture (main video track + overlay images); what Export renders. */
fun Project.videoEndMs(): Long {
    val main = clips.filter { it.trackId == mainTrackId }.maxOfOrNull { it.endMs() } ?: 0L
    return if (main > 0) main else endMs()
}
