package com.sinzer.autoedit.audio

import android.content.Context
import android.media.AudioFormat
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import com.sinzer.autoedit.data.AppJson
import com.sinzer.autoedit.model.MediaAsset
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import java.io.File
import java.nio.ByteOrder
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

const val PEAK_MS = 20
const val RMS_MS = 100

@Serializable
class AudioAnalysis(
    val version: Int = 3,
    val durationMs: Long,
    val bpm: Float,
    val beatsMs: List<Long>,
    val beatStrength: List<Float>,
    val peaks: List<Int>,            // waveform, one value (0..100) per PEAK_MS
    val rms: List<Float>,            // loudness 0..1, one value per RMS_MS
    val silenceMs: List<Long>,       // flat list [start0,end0,start1,end1,...]
    val voice: List<Float>,          // speech-likelihood 0..1 per second (heuristic estimate)
) {
    fun rmsAt(ms: Long): Float = rms.getOrElse((ms / RMS_MS).toInt().coerceAtLeast(0)) { 0f }
    fun silences(): List<LongRange> = silenceMs.chunked(2).filter { it.size == 2 }.map { it[0]..it[1] }
    fun isSilent(ms: Long) = silences().any { ms in it }
    fun voiceAt(ms: Long): Float = voice.getOrElse((ms / 1000).toInt().coerceAtLeast(0)) { 0f }
}

/** Streaming box-filter resampler to mono 22050 Hz. */
private class Downsampler(inRate: Int, outRate: Int, private val sink: (Float) -> Unit) {
    private val ratio = inRate.toDouble() / outRate
    private var acc = 0.0
    private var w = 0.0
    fun push(s: Float) {
        var remaining = 1.0
        while (remaining > 1e-9) {
            val take = min(remaining, ratio - w)
            acc += s * take; w += take; remaining -= take
            if (w >= ratio - 1e-9) { sink((acc / ratio).toFloat()); acc = 0.0; w = 0.0 }
        }
    }
}

object AudioDecoder {
    /** Decodes the first audio track as mono 22050 Hz. Returns false when the file has no audio. */
    suspend fun decode(ctx: Context, uri: Uri, onSamples: (FloatArray, Int) -> Unit, onProgress: (Float) -> Unit): Boolean =
        withContext(Dispatchers.Default) {
            val ex = MediaExtractor()
            var codec: MediaCodec? = null
            try {
                ex.setDataSource(ctx, uri, null)
                var track = -1; var fmt: MediaFormat? = null
                for (i in 0 until ex.trackCount) {
                    val f = ex.getTrackFormat(i)
                    if (f.getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true) { track = i; fmt = f; break }
                }
                if (track < 0 || fmt == null) return@withContext false
                ex.selectTrack(track)
                val durUs = if (fmt.containsKey(MediaFormat.KEY_DURATION)) fmt.getLong(MediaFormat.KEY_DURATION) else 0L
                val c = MediaCodec.createDecoderByType(fmt.getString(MediaFormat.KEY_MIME)!!)
                codec = c
                c.configure(fmt, null, null, 0); c.start()

                var chans = if (fmt.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT) else 2
                var rate = if (fmt.containsKey(MediaFormat.KEY_SAMPLE_RATE)) fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE) else 44100
                var pcmFloat = false
                val out = FloatArray(16384); var outN = 0
                fun flush() { if (outN > 0) { onSamples(out, outN); outN = 0 } }
                var ds = Downsampler(rate, BeatTracker.SR) { v -> out[outN++] = v; if (outN == out.size) flush() }

                val info = MediaCodec.BufferInfo()
                var inDone = false; var outDone = false; var lastProg = 0f
                while (!outDone && currentCoroutineContext().isActive) {
                    if (!inDone) {
                        val ii = c.dequeueInputBuffer(5000)
                        if (ii >= 0) {
                            val ib = c.getInputBuffer(ii)!!
                            val sz = ex.readSampleData(ib, 0)
                            if (sz < 0) { c.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM); inDone = true }
                            else { c.queueInputBuffer(ii, 0, sz, ex.sampleTime, 0); ex.advance() }
                        }
                    }
                    val oi = c.dequeueOutputBuffer(info, 5000)
                    if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                        val nf = c.outputFormat
                        chans = nf.getInteger(MediaFormat.KEY_CHANNEL_COUNT); rate = nf.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                        pcmFloat = nf.containsKey(MediaFormat.KEY_PCM_ENCODING) && nf.getInteger(MediaFormat.KEY_PCM_ENCODING) == AudioFormat.ENCODING_PCM_FLOAT
                        flush()
                        ds = Downsampler(rate, BeatTracker.SR) { v -> out[outN++] = v; if (outN == out.size) flush() }
                    } else if (oi >= 0) {
                        if (info.size > 0) {
                            val ob = c.getOutputBuffer(oi)!!
                            ob.order(ByteOrder.nativeOrder()); ob.position(info.offset); ob.limit(info.offset + info.size)
                            if (pcmFloat) {
                                val fb = ob.asFloatBuffer(); val frames = fb.remaining() / chans
                                for (f in 0 until frames) { var s = 0f; for (ch in 0 until chans) s += fb.get(); ds.push(s / chans) }
                            } else {
                                val sb = ob.asShortBuffer(); val frames = sb.remaining() / chans
                                for (f in 0 until frames) { var s = 0; for (ch in 0 until chans) s += sb.get(); ds.push(s / chans / 32768f) }
                            }
                        }
                        c.releaseOutputBuffer(oi, false)
                        if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outDone = true
                        if (durUs > 0) { val p = (info.presentationTimeUs.toFloat() / durUs).coerceIn(0f, 1f); if (p - lastProg > 0.01f) { lastProg = p; onProgress(p) } }
                    }
                }
                flush()
                true
            } finally {
                runCatching { codec?.stop() }; runCatching { codec?.release() }; runCatching { ex.release() }
            }
        }
}

object AudioAnalyzer {
    private fun cacheFile(ctx: Context, a: MediaAsset) =
        File(ctx.cacheDir, "analysis").apply { mkdirs() }.let { File(it, "a_${(a.uri + a.sizeBytes + a.durationMs).hashCode().toUInt()}.json") }

    fun cached(ctx: Context, a: MediaAsset): AudioAnalysis? = runCatching {
        val f = cacheFile(ctx, a)
        if (f.exists()) AppJson.decodeFromString<AudioAnalysis>(f.readText()).takeIf { it.version == 3 } else null
    }.getOrNull()

    /** Full audio analysis in a single decode pass: waveform, loudness, silence, voice estimate, tempo, beats. */
    suspend fun analyze(ctx: Context, a: MediaAsset, onProgress: (Float) -> Unit): AudioAnalysis? {
        cached(ctx, a)?.let { onProgress(1f); return it }
        val ext = BeatTracker.Extractor()
        val peaks = ArrayList<Int>(); val rms = ArrayList<Float>()
        val peakBin = BeatTracker.SR * PEAK_MS / 1000; val rmsBin = BeatTracker.SR * RMS_MS / 1000
        var pMax = 0f; var pN = 0; var rSum = 0.0; var rN = 0
        var total = 0L
        val ok = AudioDecoder.decode(ctx, Uri.parse(a.uri), { buf, n ->
            ext.push(buf, n)
            for (i in 0 until n) {
                val v = abs(buf[i]); if (v > pMax) pMax = v
                if (++pN == peakBin) { peaks.add((sqrt(pMax) * 100f).toInt().coerceIn(0, 100)); pMax = 0f; pN = 0 }
                rSum += buf[i] * buf[i]
                if (++rN == rmsBin) { rms.add(sqrt((rSum / rN).toFloat()).coerceIn(0f, 1f)); rSum = 0.0; rN = 0 }
            }
            total += n
        }, onProgress)
        if (!ok || total < BeatTracker.SR) return null
        val beat = ext.finish()
        val durMs = total * 1000L / BeatTracker.SR

        // silence: quiet for >= 700 ms
        val sorted = rms.sorted()
        val p95 = if (sorted.isEmpty()) 0f else sorted[(sorted.size * 0.95f).toInt().coerceAtMost(sorted.size - 1)]
        val thr = max(0.004f, 0.08f * p95)
        val sil = ArrayList<Long>(); var runStart = -1
        for (i in 0..rms.size) {
            val quiet = i < rms.size && rms[i] < thr
            if (quiet && runStart < 0) runStart = i
            if (!quiet && runStart >= 0) { if ((i - runStart) * RMS_MS >= 700) { sil.add(runStart * RMS_MS.toLong()); sil.add(i * RMS_MS.toLong()) }; runStart = -1 }
        }

        // voice heuristic per second: speech-band ratio high AND strong syllable-rate energy modulation
        val fps = BeatTracker.FPS; val voice = ArrayList<Float>()
        var s = 0
        while (s < ext.frames) {
            val e = min(ext.frames, s + fps.toInt())
            var tot = 0.0; var mid = 0.0; var m = 0.0; var m2 = 0.0
            for (i in s until e) { tot += ext.energy[i]; mid += ext.midEnergy[i]; val v = sqrt(ext.energy[i].toDouble()); m += v; m2 += v * v }
            val n = (e - s).coerceAtLeast(1)
            val mean = m / n; val cv = if (mean > 1e-6) sqrt(max(0.0, m2 / n - mean * mean)) / mean else 0.0
            val ratio = if (tot > 1e-9) mid / tot else 0.0
            val v = (((ratio - 0.45) / 0.35).coerceIn(0.0, 1.0) * (cv / 0.9).coerceIn(0.0, 1.0)).toFloat()
            voice.add(if (mean < 0.5) 0f else v)
            s = e
        }

        val res = AudioAnalysis(
            durationMs = durMs, bpm = beat.bpm, beatsMs = beat.beatsMs.toList(), beatStrength = beat.strength.toList(),
            peaks = peaks, rms = rms, silenceMs = sil, voice = voice,
        )
        runCatching { cacheFile(ctx, a).writeText(AppJson.encodeToString(AudioAnalysis.serializer(), res)) }
        return res
    }
}
