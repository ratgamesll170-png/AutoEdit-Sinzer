package com.sinzer.autoedit.catalog

import com.sinzer.autoedit.model.ColorAdj

data class ColorPreset(val id: String, val nameTh: String, val adj: ColorAdj)

/** 50+ one-tap grades. Each is a full [ColorAdj] the user can still fine-tune afterwards. */
object ColorPresets {
    val all: List<ColorPreset> = listOf(
        ColorPreset("c_neutral", "ปกติ", ColorAdj()),
        ColorPreset("c_vivid", "สดใส", ColorAdj(saturation = .35f, contrast = .12f, vignette = .1f)),
        ColorPreset("c_cinematic", "ซีนีม่า", ColorAdj(contrast = .22f, saturation = -.08f, temperature = .05f, shadows = -.1f, vignette = .3f)),
        ColorPreset("c_teal_orange", "ทีล-ส้ม", ColorAdj(contrast = .2f, saturation = .12f, temperature = .2f, tint = -.1f, shadows = -.1f)),
        ColorPreset("c_neon", "นีออน", ColorAdj(saturation = .5f, contrast = .25f, temperature = -.15f, tint = .2f, vignette = .25f)),
        ColorPreset("c_golden", "ทอง", ColorAdj(temperature = .45f, exposure = .05f, highlights = .15f, saturation = .1f, fade = .05f)),
        ColorPreset("c_dark", "มืด", ColorAdj(exposure = -.2f, contrast = .3f, saturation = -.25f, vignette = .5f, blacks = -.2f)),
        ColorPreset("c_pastel", "พาสเทล", ColorAdj(brightness = .12f, saturation = -.05f, fade = .15f, contrast = -.1f, temperature = .1f, tint = .12f)),
        ColorPreset("c_moody", "หม่นเศร้า", ColorAdj(temperature = -.35f, saturation = -.3f, contrast = .1f, fade = .1f, vignette = .35f)),
        ColorPreset("c_travel", "ท่องเที่ยว", ColorAdj(saturation = .4f, contrast = .12f, highlights = -.1f, temperature = .12f)),
        ColorPreset("c_cool", "เย็น", ColorAdj(temperature = -.5f, saturation = .05f, tint = .05f)),
        ColorPreset("c_warm", "อุ่น", ColorAdj(temperature = .5f, saturation = .08f)),
        ColorPreset("c_bw", "ขาวดำ", ColorAdj(saturation = -1f, contrast = .15f)),
        ColorPreset("c_bw_soft", "ขาวดำนุ่ม", ColorAdj(saturation = -1f, contrast = -.1f, fade = .12f)),
        ColorPreset("c_noir", "นัวร์", ColorAdj(saturation = -1f, contrast = .5f, vignette = .55f, grain = .08f, blacks = -.2f)),
        ColorPreset("c_sepia", "ซีเปีย", ColorAdj(saturation = -.55f, temperature = .5f, tint = .15f, fade = .08f)),
        ColorPreset("c_faded", "ซีดฟิล์ม", ColorAdj(fade = .25f, contrast = -.12f, saturation = -.2f, grain = .05f)),
        ColorPreset("c_matte", "แมตต์", ColorAdj(fade = .2f, blacks = .15f, contrast = -.05f, saturation = -.1f)),
        ColorPreset("c_hi_contrast", "คอนทราสต์สูง", ColorAdj(contrast = .5f, saturation = .1f)),
        ColorPreset("c_low_contrast", "คอนทราสต์ต่ำ", ColorAdj(contrast = -.3f, brightness = .05f)),
        ColorPreset("c_bright", "สว่างใส", ColorAdj(exposure = .3f, brightness = .08f, highlights = -.1f)),
        ColorPreset("c_lowkey", "ฉากมืดลึก", ColorAdj(exposure = -.4f, contrast = .35f, shadows = -.2f)),
        ColorPreset("c_sunset", "พระอาทิตย์ตก", ColorAdj(temperature = .6f, tint = .25f, saturation = .2f, vignette = .2f)),
        ColorPreset("c_sunrise", "แสงเช้า", ColorAdj(temperature = .35f, exposure = .1f, tint = .1f, fade = .06f)),
        ColorPreset("c_moonlight", "แสงจันทร์", ColorAdj(temperature = -.6f, exposure = -.2f, tint = .1f, saturation = -.1f)),
        ColorPreset("c_forest", "ป่าเขียว", ColorAdj(tint = -.35f, saturation = .2f, temperature = .05f, contrast = .1f)),
        ColorPreset("c_ocean", "ทะเลฟ้า", ColorAdj(temperature = -.35f, saturation = .25f, tint = -.1f, contrast = .1f)),
        ColorPreset("c_autumn", "ใบไม้ร่วง", ColorAdj(temperature = .55f, saturation = .2f, tint = .1f, contrast = .1f)),
        ColorPreset("c_winter", "หน้าหนาว", ColorAdj(temperature = -.45f, brightness = .08f, saturation = -.15f)),
        ColorPreset("c_summer", "หน้าร้อน", ColorAdj(temperature = .3f, saturation = .3f, exposure = .1f)),
        ColorPreset("c_film_kodak", "ฟิล์มโคดัก", ColorAdj(temperature = .25f, saturation = .12f, fade = .1f, grain = .06f, contrast = .08f)),
        ColorPreset("c_film_fuji", "ฟิล์มฟูจิ", ColorAdj(temperature = -.1f, tint = -.12f, saturation = .15f, fade = .08f, grain = .05f)),
        ColorPreset("c_vintage", "วินเทจ", ColorAdj(temperature = .35f, fade = .2f, saturation = -.15f, vignette = .35f, grain = .06f)),
        ColorPreset("c_polaroid", "โพลารอยด์", ColorAdj(fade = .15f, temperature = .15f, vignette = .25f, contrast = -.08f)),
        ColorPreset("c_cyber", "ไซเบอร์", ColorAdj(temperature = -.3f, tint = .35f, saturation = .45f, contrast = .25f)),
        ColorPreset("c_synthwave", "ซินธ์เวฟ", ColorAdj(tint = .4f, temperature = -.2f, saturation = .5f, contrast = .2f, vignette = .2f)),
        ColorPreset("c_anime", "อนิเมะ", ColorAdj(saturation = .45f, contrast = .15f, brightness = .05f, highlights = .1f)),
        ColorPreset("c_game", "เกม", ColorAdj(saturation = .35f, contrast = .28f, vignette = .2f)),
        ColorPreset("c_horror", "สยองขวัญ", ColorAdj(saturation = -.45f, tint = -.3f, contrast = .35f, exposure = -.2f, vignette = .55f)),
        ColorPreset("c_dream", "ฝันหวาน", ColorAdj(brightness = .1f, fade = .12f, saturation = .1f, tint = .15f, temperature = .12f)),
        ColorPreset("c_cute", "น่ารัก", ColorAdj(brightness = .1f, saturation = .22f, fade = .1f, temperature = .1f, tint = .2f)),
        ColorPreset("c_sad", "เศร้า", ColorAdj(saturation = -.4f, temperature = -.35f, contrast = .08f, vignette = .4f, fade = .1f)),
        ColorPreset("c_phonk", "ฟังก์", ColorAdj(contrast = .4f, saturation = -.2f, grain = .12f, vignette = .5f, temperature = -.1f)),
        ColorPreset("c_portrait", "พอร์ตเทรต", ColorAdj(temperature = .12f, highlights = -.12f, shadows = .12f, saturation = -.05f, contrast = .05f)),
        ColorPreset("c_food", "อาหารน่ากิน", ColorAdj(temperature = .25f, saturation = .35f, contrast = .15f, brightness = .05f)),
        ColorPreset("c_street", "สตรีท", ColorAdj(contrast = .3f, saturation = -.2f, grain = .08f, vignette = .3f)),
        ColorPreset("c_clean", "คลีน", ColorAdj(brightness = .06f, contrast = .08f, saturation = .08f, sharpen = .3f)),
        ColorPreset("c_sharp", "คมชัด", ColorAdj(sharpen = .8f, contrast = .1f)),
        ColorPreset("c_hdr", "HDR", ColorAdj(highlights = -.4f, shadows = .4f, contrast = .25f, saturation = .25f, sharpen = .4f)),
        ColorPreset("c_lift", "ยกส่วนมืด", ColorAdj(shadows = .45f, exposure = .1f)),
        ColorPreset("c_crush", "บีบส่วนมืด", ColorAdj(blacks = -.4f, contrast = .25f)),
        ColorPreset("c_rose", "โรสโกลด์", ColorAdj(temperature = .2f, tint = .3f, saturation = .1f, fade = .08f)),
        ColorPreset("c_mint", "มินต์", ColorAdj(tint = -.3f, temperature = -.15f, brightness = .06f, saturation = .1f)),
        ColorPreset("c_violet", "ม่วงมนต์", ColorAdj(tint = .35f, hue = -20f, saturation = .25f, contrast = .1f)),
    )
    private val byId by lazy { all.associateBy { it.id } }
    fun get(id: String?): ColorPreset? = id?.let { byId[it] }
}
