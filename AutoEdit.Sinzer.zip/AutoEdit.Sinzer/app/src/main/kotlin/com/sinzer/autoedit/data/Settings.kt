package com.sinzer.autoedit.data

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.store by preferencesDataStore("settings")

data class AppSettings(
    val previewHeight: Int = 540,          // short side of the preview render (px)
    val autoSave: Boolean = true,
    val openAiKey: String = "",
    val saveFolderUri: String = "",
    val seenTips: Set<String> = emptySet(),
    val snapToBeat: Boolean = true,
    val keepScreenOnExport: Boolean = true,
)

class SettingsStore(private val ctx: Context) {
    private object K {
        val preview = intPreferencesKey("preview_h")
        val autoSave = booleanPreferencesKey("auto_save")
        val key = stringPreferencesKey("openai_key")
        val folder = stringPreferencesKey("save_folder")
        val tips = stringSetPreferencesKey("tips")
        val snap = booleanPreferencesKey("snap")
        val keepOn = booleanPreferencesKey("keep_on")
    }

    val flow: Flow<AppSettings> = ctx.store.data.map { p ->
        AppSettings(p[K.preview] ?: 540, p[K.autoSave] ?: true, p[K.key] ?: "", p[K.folder] ?: "",
            p[K.tips] ?: emptySet(), p[K.snap] ?: true, p[K.keepOn] ?: true)
    }

    suspend fun setPreviewHeight(v: Int) = ctx.store.edit { it[K.preview] = v }
    suspend fun setAutoSave(v: Boolean) = ctx.store.edit { it[K.autoSave] = v }
    suspend fun setOpenAiKey(v: String) = ctx.store.edit { it[K.key] = v.trim() }
    suspend fun setSaveFolder(v: String) = ctx.store.edit { it[K.folder] = v }
    suspend fun setSnap(v: Boolean) = ctx.store.edit { it[K.snap] = v }
    suspend fun setKeepOn(v: Boolean) = ctx.store.edit { it[K.keepOn] = v }
    suspend fun markTipSeen(id: String) = ctx.store.edit { it[K.tips] = (it[K.tips] ?: emptySet()) + id }
    suspend fun resetTips() = ctx.store.edit { it[K.tips] = emptySet() }
}
