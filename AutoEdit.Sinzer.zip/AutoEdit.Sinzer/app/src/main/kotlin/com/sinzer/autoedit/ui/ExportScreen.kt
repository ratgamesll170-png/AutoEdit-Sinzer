package com.sinzer.autoedit.ui

import android.content.Intent
import android.media.MediaCodecInfo
import android.media.MediaCodecList
import android.media.MediaFormat
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.util.UnstableApi
import com.sinzer.autoedit.model.Aspect
import com.sinzer.autoedit.model.videoEndMs
import com.sinzer.autoedit.render.CompositionBuilder
import com.sinzer.autoedit.render.ExportSettings
import com.sinzer.autoedit.render.ExportState
import com.sinzer.autoedit.vm.MainVM

private fun encoderSupports(mime: String, w: Int, h: Int): Boolean = runCatching {
    MediaCodecList(MediaCodecList.REGULAR_CODECS).codecInfos.any { ci ->
        ci.isEncoder && ci.supportedTypes.any { it.equals(mime, true) } &&
            ci.getCapabilitiesForType(mime).videoCapabilities?.isSizeSupported(w, h) == true
    }
}.getOrDefault(false)

private fun hasEncoder(mime: String) = runCatching { MediaCodecList(MediaCodecList.REGULAR_CODECS).codecInfos.any { ci -> ci.isEncoder && ci.supportedTypes.any { it.equals(mime, true) } } }.getOrDefault(false)

@OptIn(UnstableApi::class)
@Composable
fun ExportScreen(vm: MainVM, onBack: () -> Unit) {
    val p by vm.project.collectAsState()
    val project = p ?: run { LaunchedEffect(Unit) { onBack() }; return }
    val st by vm.exporter.state.collectAsState()
    val settings by vm.settings.collectAsState()
    val ctx = LocalContext.current
    val view = LocalView.current
    val running = st is ExportState.Running

    val shorts = listOf(480 to "480p", 720 to "720p", 1080 to "1080p", 1440 to "1440p", 2160 to "4K")
    var resI by remember { mutableIntStateOf(2) }
    val fpsList = listOf(24, 30, 60); var fpsI by remember { mutableIntStateOf(1) }
    val brList = listOf<Float?>(null, 4f, 8f, 12f, 20f, 40f); var brI by remember { mutableIntStateOf(0) }
    var hevc by remember { mutableStateOf(false) }
    var name by remember { mutableStateOf(project.name.replace(Regex("[^A-Za-z0-9ก-๙ _-]"), "_")) }
    val hevcOk = remember { hasEncoder(MediaFormat.MIMETYPE_VIDEO_HEVC) }
    val mime = if (hevc) MediaFormat.MIMETYPE_VIDEO_HEVC else MediaFormat.MIMETYPE_VIDEO_AVC

    DisposableEffect(running, settings.keepScreenOnExport) { view.keepScreenOn = running && settings.keepScreenOnExport; onDispose { view.keepScreenOn = false } }
    DisposableEffect(Unit) { onDispose { vm.exporter.reset() } }

    ScreenScaffold("ส่งออกวิดีโอ", { if (!running) onBack() }, actions = { HelpIcon("export") }) {
        Column(Modifier.verticalScroll(rememberScrollState())) {
            val dur = project.videoEndMs()
            val (w, h) = CompositionBuilder.dims(project.aspect, shorts[resI].first)
            val mbps = brList[brI] ?: (listOf(2f, 5f, 10f, 18f, 35f)[resI] * fpsList[fpsI] / 30f)
            Text("ผลลัพธ์: ${w}×${h} · ${fpsList[fpsI]} fps · ความยาว ${fmtTime(dur)} · ประมาณ ${"%.0f".format(mbps * dur / 8000f)} MB", fontWeight = androidx.compose.ui.text.font.FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            when (val s = st) {
                is ExportState.Running -> {
                    Text(s.stage)
                    LinearProgressIndicator(progress = { s.progress / 100f }, Modifier.fillMaxWidth().height(10.dp))
                    Text("${s.progress}%", fontSize = 28.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.ExtraBold, color = NeonBlue)
                    Text("อย่าปิดแอปหรือสลับไปแอปอื่นจนกว่าจะเสร็จ", fontSize = 12.sp, color = TextDim)
                    OutlinedButton(onClick = { vm.exporter.cancel() }) { Text("ยกเลิกการ Export", color = Danger) }
                }
                is ExportState.Done -> {
                    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF0E3A2A))) { Column(Modifier.padding(14.dp)) {
                        Text("✅ ส่งออกสำเร็จ", fontWeight = androidx.compose.ui.text.font.FontWeight.Bold)
                        Text(s.message, fontSize = 13.sp)
                    } }
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        NeonButton("▶ เปิดดู") { ctx.startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(s.uri, "video/mp4").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)) }
                        OutlinedButton(onClick = { ctx.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("video/mp4").putExtra(Intent.EXTRA_STREAM, s.uri).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION), "แชร์วิดีโอ")) }) { Text("แชร์") }
                    }
                    TextButton(onClick = { vm.exporter.reset() }) { Text("Export อีกครั้งด้วยค่าอื่น") }
                    TextButton(onClick = onBack) { Text("กลับไปแก้ไข") }
                }
                is ExportState.Failed -> {
                    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF4A1620))) { Text("❌ ${s.message}", Modifier.padding(14.dp)) }
                    TextButton(onClick = { vm.exporter.reset() }) { Text("ลองใหม่") }
                }
                ExportState.Cancelled -> { Text("ยกเลิกการ Export แล้ว (ไม่มีไฟล์ที่ไม่สมบูรณ์ถูกบันทึก)", color = TextDim); TextButton(onClick = { vm.exporter.reset() }) { Text("กลับไปตั้งค่า") } }
                ExportState.Idle -> {}
            }
            if (st is ExportState.Idle) {
                SectionTitle("ความละเอียด")
                ChipRow(shorts.mapIndexed { i, (sh, l) -> val (ww, hh) = CompositionBuilder.dims(project.aspect, sh); if (encoderSupports(mime, ww, hh)) l else "⚠ $l" }, resI) { i ->
                    val (ww, hh) = CompositionBuilder.dims(project.aspect, shorts[i].first)
                    if (encoderSupports(mime, ww, hh)) resI = i else vm.toast("เครื่องนี้ไม่รองรับการเข้ารหัส ${shorts[i].second} ด้วย ${if (hevc) "HEVC" else "H.264"}")
                }
                Text("ถ้ามีเครื่องหมาย ⚠ แปลว่าอุปกรณ์/ตัวเข้ารหัสของเครื่องไม่รองรับ", fontSize = 11.sp, color = TextDim)
                SectionTitle("เฟรมเรต (FPS)")
                ChipRow(fpsList.map { "$it fps" }, fpsI) { fpsI = it }
                Text("เลือกสูงกว่าเฟรมเรตของคลิปต้นฉบับ จะไม่เพิ่มความลื่นขึ้น", fontSize = 11.sp, color = TextDim)
                SectionTitle("บิตเรต")
                ChipRow(listOf("อัตโนมัติ", "4 Mbps", "8 Mbps", "12 Mbps", "20 Mbps", "40 Mbps"), brI) { brI = it }
                SectionTitle("Codec")
                ChipRow(listOf("H.264 (เข้ากันได้ทุกที่)", if (hevcOk) "H.265/HEVC (ไฟล์เล็ก)" else "⚠ HEVC (ไม่รองรับ)"), if (hevc) 1 else 0) { i -> if (i == 1 && !hevcOk) vm.toast("เครื่องนี้ไม่มีตัวเข้ารหัส HEVC") else { hevc = i == 1; if (!encoderSupports(if (hevc) MediaFormat.MIMETYPE_VIDEO_HEVC else MediaFormat.MIMETYPE_VIDEO_AVC, w, h)) resI = 2.coerceAtMost(resI) } }
                SectionTitle("อัตราส่วน", "aspect")
                ChipRow(Aspect.values().map { it.label }, project.aspect.ordinal) { vm.setAspect(Aspect.values()[it]) }
                OutlinedTextField(name, { name = it }, Modifier.fillMaxWidth(), label = { Text("ชื่อไฟล์") }, singleLine = true)
                Text(if (settings.saveFolderUri.isBlank()) "บันทึกที่: Movies/FlashCutAI (เปลี่ยนโฟลเดอร์ได้ในหน้าตั้งค่า)" else "บันทึกที่โฟลเดอร์ที่เลือกไว้ในตั้งค่า", fontSize = 12.sp, color = TextDim)
                Text("ไม่มีลายน้ำ · ภาพและเสียงซิงก์ตามไทม์ไลน์ · หลังเสร็จจะตรวจสอบว่าไฟล์เปิดเล่นได้", fontSize = 12.sp, color = TextDim)
                Spacer(Modifier.height(10.dp))
                NeonButton("🚀 เริ่ม Export", Modifier.fillMaxWidth()) {
                    vm.startExport(ExportSettings(shorts[resI].first, fpsList[fpsI], brList[brI], hevc, name.ifBlank { "FlashCut" }, settings.saveFolderUri))
                }
                Spacer(Modifier.height(20.dp))
            }
        }
    }
}
