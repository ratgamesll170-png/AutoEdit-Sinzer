package com.sinzer.autoedit

import android.app.Application

class App : Application()
