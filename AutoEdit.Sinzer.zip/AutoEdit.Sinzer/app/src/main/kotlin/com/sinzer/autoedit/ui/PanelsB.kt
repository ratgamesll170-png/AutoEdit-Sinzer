@file:OptIn(ExperimentalLayoutApi::class)

package com.sinzer.autoedit.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sinzer.autoedit.catalog.*
import com.sinzer.autoedit.model.*
import com.sinzer.autoedit.vm.MainVM
import kotlinx.coroutines.launch

// ------------------------------------------------------------------ TEXT
@Composable
fun TextPanel(vm: MainVM, p: Project, sel: Sel?) {
    val t = sel?.takeIf { it.kind == ItemKind.TEXT }?.let { s -> p.texts.firstOrNull { it.id == s.id } }
    var tab by remember { mutableIntStateOf(0) }
    PanelScroll {
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedButton(onClick = { vm.addText() }) { Text("＋ เพิ่มข้อความ") }
            HelpIcon("text")
        }
        if (t == null) {
            val all = p.texts.filter { !it.subtitle }
            if (all.isEmpty()) Text("กด “เพิ่มข้อความ” หรือแตะข้อความบนไทม์ไลน์เพื่อแก้ไข ลากบนวิดีโอเพื่อย้ายตำแหน่ง", fontSize = 12.sp, color = TextDim)
            all.forEach { x -> Text("T  ${x.text.take(30)}", Modifier.fillMaxWidth().clickable { vm.selection.value = Sel(ItemKind.TEXT, x.id) }.padding(8.dp), fontSize = 13.sp) }
            return@PanelScroll
        }
        OutlinedTextField(t.text, { v -> vm.updateText(t.id) { it.copy(text = v) } }, Modifier.fillMaxWidth(), label = { Text("ข้อความ (ขึ้นบรรทัดใหม่ได้)") }, minLines = 1, maxLines = 3)
        ChipRow(listOf("ฟอนต์", "สไตล์", "แอนิเมชัน", "ตำแหน่ง"), tab) { tab = it }
        when (tab) {
            0 -> FontTab(vm, t)
            1 -> StyleTab(vm, t)
            2 -> AnimTab(vm, t)
            else -> PosTab(vm, t)
        }
    }
}

@Composable
private fun FontTab(vm: MainVM, t: TextItem) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var q by remember { mutableStateOf("") }
    var cat by remember { mutableIntStateOf(0) }
    var refresh by remember { mutableIntStateOf(0) }
    var busy by remember { mutableStateOf<String?>(null) }
    val cats = listOf("ทั้งหมด") + FontCatalog.categories + listOf("ฟอนต์ของฉัน")
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) scope.launch { val e = FontManager.importFile(ctx, u); if (e != null) vm.toast(e) else { refresh++; vm.toast("นำเข้าฟอนต์แล้ว (ผู้ใช้ต้องมีสิทธิ์ใช้งานฟอนต์นี้)") } }
    }
    SectionTitle("ฟอนต์ (${FontCatalog.all.size} แบบ)", "font")
    OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth(), label = { Text("ค้นหาฟอนต์") }, singleLine = true)
    ChipRow(cats, cat) { cat = it }
    val list = when {
        cat == 0 -> FontCatalog.system + FontCatalog.all
        cat == cats.size - 1 -> FontManager.installedUserFonts(ctx)
        else -> FontCatalog.all.filter { it.cat == cats[cat] }
    }.filter { q.isBlank() || it.family.contains(q, true) }
    @Suppress("UNUSED_VARIABLE") val r = refresh
    Column(Modifier.heightIn(max = 220.dp).verticalScroll(rememberScrollState())) {
        list.forEach { f ->
            val installed = FontManager.isInstalled(ctx, f.id) || f.id.startsWith("u:")
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp)).background(if (t.fontId == f.id) Surface2 else Color.Transparent)
                .clickable(enabled = installed) { vm.updateText(t.id) { it.copy(fontId = f.id) } }.padding(horizontal = 8.dp, vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(f.family + (if (f.thai) "  🇹🇭" else ""), fontSize = 11.sp, color = TextDim)
                    Text(if (t.text.isBlank()) "ตัวอย่างข้อความ Sample" else t.text.take(20).replace("\n", " "), fontSize = 20.sp, maxLines = 1,
                        fontFamily = if (installed) androidx.compose.ui.text.font.FontFamily(FontManager.typeface(ctx, f.id)) else FontFamily.Default,
                        color = if (installed) Color.White else TextDim)
                }
                if (!installed) {
                    if (busy == f.id) CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp)
                    else TextButton(onClick = { busy = f.id; scope.launch { val e = FontManager.download(ctx, f); busy = null; if (e != null) vm.toast(e) else { refresh++; vm.updateText(t.id) { it.copy(fontId = f.id) } } } }) { Text("ดาวน์โหลด") }
                } else if (t.fontId == f.id) Text("✓", color = NeonBlue)
            }
        }
        if (list.isEmpty()) Text("ไม่พบฟอนต์", color = TextDim, fontSize = 12.sp)
    }
    OutlinedButton(onClick = { picker.launch(arrayOf("font/ttf", "font/otf", "application/x-font-ttf", "application/octet-stream")) }) { Text("นำเข้าไฟล์ฟอนต์ (.ttf/.otf) ของฉัน") }
    Text("ฟอนต์ทั้งหมดมาจาก Google Fonts (ฟรี) ต้องมีอินเทอร์เน็ตตอนดาวน์โหลดครั้งแรกเท่านั้น", fontSize = 11.sp, color = TextDim)
}

@Composable
private fun StyleTab(vm: MainVM, t: TextItem) {
    fun up(f: (TextItem) -> TextItem) { vm.beginGestureOnce(); vm.updateText(t.id, f) }
    val done = { vm.endGesture() }
    LabeledSlider("ขนาด", t.size, 16f..220f, "%.0f".format(t.size), { v -> up { it.copy(size = v) } }, done)
    Row { SwitchRowW("ตัวหนา", t.bold) { v -> vm.updateText(t.id) { it.copy(bold = v) } }; Spacer(Modifier.width(12.dp)); SwitchRowW("ตัวเอียง", t.italic) { v -> vm.updateText(t.id) { it.copy(italic = v) } } }
    LabeledSlider("ระยะห่างตัวอักษร", t.letterSpacing, -0.1f..0.6f, "%.2f".format(t.letterSpacing), { v -> up { it.copy(letterSpacing = v) } }, done)
    ChipRow(listOf("ชิดซ้าย", "กลาง", "ชิดขวา"), t.align) { v -> vm.updateText(t.id) { it.copy(align = v) } }
    ColorRow("สีตัวอักษร", t.color) { c -> vm.updateText(t.id) { it.copy(color = c, gradA = 0, gradB = 0) } }
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text("Gradient", fontSize = 13.sp, color = TextDim); Spacer(Modifier.width(8.dp))
        listOf(0xFFFFE14D to 0xFFFF4D4D, 0xFF35D0FF to 0xFF9B6BFF, 0xFFFFFFFF to 0xFF35D0FF, 0xFF4DFF88 to 0xFF35D0FF).forEach { (a, b) ->
            Box(Modifier.padding(end = 8.dp).size(28.dp).clip(RoundedCornerShape(14.dp)).background(androidx.compose.ui.graphics.Brush.verticalGradient(listOf(Color(a), Color(b)))).clickable { vm.updateText(t.id) { it.copy(gradA = a.toInt(), gradB = b.toInt()) } })
        }
        TextButton(onClick = { vm.updateText(t.id) { it.copy(gradA = 0, gradB = 0) } }) { Text("ปิด") }
    }
    LabeledSlider("เส้นขอบ", t.strokeW, 0f..14f, "%.1f".format(t.strokeW), { v -> up { it.copy(strokeW = v) } }, done)
    if (t.strokeW > 0f) ColorRow("สีเส้นขอบ", t.strokeColor) { c -> vm.updateText(t.id) { it.copy(strokeColor = c) } }
    LabeledSlider("เงา", t.shadow, 0f..4f, "%.1f".format(t.shadow), { v -> up { it.copy(shadow = v) } }, done)
    LabeledSlider("Glow", t.glow, 0f..4f, "%.1f".format(t.glow), { v -> up { it.copy(glow = v) } }, done)
    if (t.glow > 0f) ColorRow("สี Glow", t.glowColor) { c -> vm.updateText(t.id) { it.copy(glowColor = c) } }
    ColorRow("พื้นหลังข้อความ", t.bgColor, allowNone = true) { c -> vm.updateText(t.id) { it.copy(bgColor = if (c == 0) 0 else (c and 0x00FFFFFF) or 0xCC000000.toInt()) } }
    LabeledSlider("ระยะเวลาแสดง", t.durMs / 1000f, 0.3f..30f, "%.1f วิ".format(t.durMs / 1000f), { v -> up { it.copy(durMs = (v * 1000).toLong()) } }, done)
}

@Composable
private fun SwitchRowW(label: String, v: Boolean, f: (Boolean) -> Unit) = Row(verticalAlignment = Alignment.CenterVertically) { Text(label, fontSize = 13.sp); Spacer(Modifier.width(6.dp)); Switch(v, f) }

@Composable
private fun AnimTab(vm: MainVM, t: TextItem) {
    var phase by remember { mutableIntStateOf(0) }   // 0 in, 1 out, 2 loop
    var cat by remember { mutableIntStateOf(0) }
    SectionTitle("แอนิเมชันข้อความ (${TextAnims.all.size} แบบ)", "text_anim")
    ChipRow(listOf("เข้า", "ออก", "วนซ้ำ"), phase) { phase = it }
    val kinds = TextAnims.all.map { it.kind }.distinct()
    val pool = TextAnims.all.filter { if (phase == 2) it.loop else !it.loop }
    val groups = pool.map { it.kind }.distinct()
    ChipRow(listOf("ทั้งหมด") + groups.map { it.name.lowercase().replace('_', ' ') }, cat) { cat = it }
    val shown = if (cat == 0) pool else pool.filter { it.kind == groups[cat - 1] }
    Column(Modifier.heightIn(max = 150.dp).verticalScroll(rememberScrollState())) {
        FlowRow {
            shown.forEach { a ->
                val on = t.anims.any { it.presetId == a.id && (a.loop || it.phase == phase) }
                SmallChip(a.nameTh, on) {
                    vm.updateText(t.id) { x ->
                        val others = x.anims.filterNot { it.presetId == a.id && (a.loop || it.phase == phase) }
                        if (on) x.copy(anims = others) else x.copy(anims = x.anims.filterNot { r -> !a.loop && TextAnims.get(r.presetId)?.loop != true && r.phase == phase } + TextAnimRef(a.id, if (a.loop) 2 else phase, if (a.kind == TKind.KARAOKE) 300 else 600))
                    }
                }
            }
        }
    }
    @Suppress("UNUSED_VARIABLE") val k = kinds
    if (t.anims.isNotEmpty()) SectionTitle("ที่ใช้อยู่ (ปรับได้)")
    t.anims.forEachIndexed { i, r ->
        val a = TextAnims.get(r.presetId) ?: return@forEachIndexed
        Column(Modifier.fillMaxWidth().padding(vertical = 3.dp).clip(RoundedCornerShape(10.dp)).background(Surface2).padding(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("${listOf("เข้า", "ออก", "วนซ้ำ")[r.phase]} · ${a.nameTh}", Modifier.weight(1f), fontSize = 13.sp)
                TextButton(onClick = { vm.updateText(t.id) { x -> x.copy(anims = x.anims.filterIndexed { j, _ -> j != i }) } }) { Text("ลบ", color = Danger) }
            }
            fun up(f: (TextAnimRef) -> TextAnimRef) { vm.beginGestureOnce(); vm.updateText(t.id) { x -> x.copy(anims = x.anims.mapIndexed { j, rr -> if (j == i) f(rr) else rr }) } }
            if (!a.loop) LabeledSlider("ระยะเวลา", r.durMs / 1000f, 0.1f..3f, "%.1f วิ".format(r.durMs / 1000f), { v -> up { it.copy(durMs = (v * 1000).toLong()) } }, { vm.endGesture() })
            LabeledSlider("ความเร็ว", r.speed, 0.3f..3f, "×%.1f".format(r.speed), { v -> up { it.copy(speed = v) } }, { vm.endGesture() })
            LabeledSlider("ความแรง", r.strength, 0.2f..2f, "%.1f".format(r.strength), { v -> up { it.copy(strength = v) } }, { vm.endGesture() })
        }
    }
    Text("ใส่ได้หลายแอนิเมชันพร้อมกัน เช่น ป๊อปอัพ + สั่น", fontSize = 11.sp, color = TextDim)
}

@Composable
private fun PosTab(vm: MainVM, t: TextItem) {
    fun up(f: (TextItem) -> TextItem) { vm.beginGestureOnce(); vm.updateText(t.id, f) }
    val done = { vm.endGesture() }
    Text("ลากข้อความบนวิดีโอเพื่อย้าย · บีบสองนิ้วเพื่อย่อ/ขยาย/หมุน", fontSize = 11.sp, color = TextDim)
    LabeledSlider("ตำแหน่งแนวนอน", t.x, 0f..1f, "%.2f".format(t.x), { v -> up { it.copy(x = v) } }, done)
    LabeledSlider("ตำแหน่งแนวตั้ง", t.y, 0f..1f, "%.2f".format(t.y), { v -> up { it.copy(y = v) } }, done)
    LabeledSlider("ขนาด (ซูม)", t.scale, 0.2f..4f, "%.2f".format(t.scale), { v -> up { it.copy(scale = v) } }, done)
    LabeledSlider("หมุน", t.rot, -180f..180f, "%.0f°".format(t.rot), { v -> up { it.copy(rot = v) } }, done)
    LabeledSlider("ความโปร่งใส (Opacity)", t.opacity, 0f..1f, "%.2f".format(t.opacity), { v -> up { it.copy(opacity = v) } }, done)
}

// ------------------------------------------------------------------ STICKER
private val EMOJIS = ("😀😂🤣😍🥰😎🤩😭😡🥶🤯🥳😴🙄😱🤔👍👎👏🙌🔥💥✨⭐🌟💫💯❤️🧡💛💚💙💜🖤💔🎉🎊🎁🏆🎵🎶🎤🎧🎮👑💎🚀🌈☀️🌙⚡🌸🌹🍕🍔🍩🐶🐱🦊🐼🦄👻💀👀💬❗❓➡️⬆️").let { s ->
    val out = ArrayList<String>(); val bi = java.text.BreakIterator.getCharacterInstance(); bi.setText(s)
    var a = bi.first(); var b = bi.next(); while (b != java.text.BreakIterator.DONE) { out.add(s.substring(a, b)); a = b; b = bi.next() }; out
}

@Composable
fun StickerPanel(vm: MainVM, p: Project, sel: Sel?) {
    val s = sel?.takeIf { it.kind == ItemKind.STICKER }?.let { x -> p.stickers.firstOrNull { it.id == x.id } }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) { com.sinzer.autoedit.media.MediaProbe.persist(vm.getApplication(), u); vm.addSticker(null, u.toString()) }
    }
    PanelScroll {
        SectionTitle("สติ๊กเกอร์และรูปซ้อน", "sticker")
        Column(Modifier.heightIn(max = 130.dp).verticalScroll(rememberScrollState())) {
            FlowRow { EMOJIS.forEach { e -> Text(e, fontSize = 26.sp, modifier = Modifier.clickable { vm.addSticker(e, null) }.padding(5.dp)) } }
        }
        OutlinedButton(onClick = { picker.launch(arrayOf("image/*")) }) { Text("＋ เพิ่มรูปภาพซ้อนบนวิดีโอ") }
        if (s != null) {
            fun up(f: (StickerItem) -> StickerItem) { vm.beginGestureOnce(); vm.updateSticker(s.id, f) }
            val done = { vm.endGesture() }
            LabeledSlider("ขนาด", s.scale, 0.2f..4f, "%.2f".format(s.scale), { v -> up { it.copy(scale = v) } }, done)
            LabeledSlider("หมุน", s.rot, -180f..180f, "%.0f°".format(s.rot), { v -> up { it.copy(rot = v) } }, done)
            LabeledSlider("ความโปร่งใส", s.opacity, 0f..1f, "%.2f".format(s.opacity), { v -> up { it.copy(opacity = v) } }, done)
            LabeledSlider("ตำแหน่งแนวนอน", s.x, 0f..1f, "%.2f".format(s.x), { v -> up { it.copy(x = v) } }, done)
            LabeledSlider("ตำแหน่งแนวตั้ง", s.y, 0f..1f, "%.2f".format(s.y), { v -> up { it.copy(y = v) } }, done)
            Text("ลากบนวิดีโอเพื่อย้าย · ปรับความยาวด้วยจุดจับบนไทม์ไลน์", fontSize = 11.sp, color = TextDim)
        }
    }
}
