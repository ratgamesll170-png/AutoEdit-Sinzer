package com.sinzer.autoedit.audio

import kotlin.math.*

/**
 * Beat / tempo detection (pure Kotlin, no Android dependency, unit-testable).
 * Algorithm: 3-band log-magnitude spectral flux -> tempo by weighted autocorrelation
 * -> dynamic-programming beat tracking (Ellis 2007) -> edge cleanup.
 * Ported from a numpy prototype that was validated on synthetic click/drum tracks
 * (see README: ~0.3% of beats off by >30 ms, almost all at the very first/last beat).
 */
object BeatTracker {
    const val SR = 22050
    const val NFFT = 1024
    const val HOP = 256
    const val FPS = SR.toFloat() / HOP
    /** Measured constant latency of the framing: detected beats are ~7 ms early. */
    const val LATENCY_MS = 7L

    private val BANDS = arrayOf(intArrayOf(30, 200), intArrayOf(200, 2000), intArrayOf(2000, 8000))
    private val WEIGHTS = floatArrayOf(1.6f, 1.0f, 0.5f)

    class Result(val bpm: Float, val beatFrames: IntArray, val strength: FloatArray, val onset: FloatArray) {
        val beatsMs: LongArray get() = LongArray(beatFrames.size) { frameToMs(beatFrames[it]) }
    }

    fun frameToMs(frame: Int): Long = ((frame.toDouble() * HOP + NFFT / 2.0) / SR * 1000.0).toLong() + LATENCY_MS

    /** Streaming feature extractor: push mono 22050 Hz samples, then call [finish]. */
    class Extractor {
        private val buf = FloatArray(NFFT)
        private var filled = 0
        private val win = FloatArray(NFFT) { (0.5 - 0.5 * cos(2.0 * PI * it / NFFT)).toFloat() }   // periodic Hann
        private val re = FloatArray(NFFT)
        private val im = FloatArray(NFFT)
        private val prev = FloatArray(NFFT / 2 + 1)
        private var hasPrev = false
        private val df = SR.toFloat() / NFFT
        private val bandIdx = Array(3) { intArrayOf((BANDS[it][0] / df).toInt(), (BANDS[it][1] / df).toInt()) }
        private val kmax = bandIdx[2][1] + 1
        private val bands = Array(3) { GrowFloat() }
        private val fft = Fft(NFFT)
        /** Per-frame total energy (0-8 kHz) and speech-band energy (300-3400 Hz); used for the voice heuristic. */
        val energy = GrowFloat()
        val midEnergy = GrowFloat()
        private val midLo = (300f / (SR.toFloat() / NFFT)).toInt()
        private val midHi = (3400f / (SR.toFloat() / NFFT)).toInt()

        fun push(x: FloatArray, n: Int) {
            var i = 0
            while (i < n) {
                val take = min(NFFT - filled, n - i)
                System.arraycopy(x, i, buf, filled, take)
                filled += take; i += take
                if (filled == NFFT) { frame(); System.arraycopy(buf, HOP, buf, 0, NFFT - HOP); filled = NFFT - HOP }
            }
        }

        private fun frame() {
            for (i in 0 until NFFT) { re[i] = buf[i] * win[i]; im[i] = 0f }
            fft.transform(re, im)
            val s = FloatArray(kmax)
            var tot = 0f; var mid = 0f
            for (k in 0 until kmax) {
                val m2 = re[k] * re[k] + im[k] * im[k]
                val mag = sqrt(m2)
                s[k] = ln(1f + 400f * mag / NFFT)
                tot += m2; if (k in midLo..midHi) mid += m2
            }
            energy.add(tot); midEnergy.add(mid)
            for (b in 0 until 3) {
                var acc = 0f
                if (hasPrev) for (k in bandIdx[b][0] until bandIdx[b][1]) { val d = s[k] - prev[k]; if (d > 0f) acc += d }
                val w = (bandIdx[b][1] - bandIdx[b][0]).coerceAtLeast(1)
                bands[b].add(acc / sqrt(w.toFloat()))
            }
            System.arraycopy(s, 0, prev, 0, kmax); hasPrev = true
        }

        val frames: Int get() = bands[0].size

        /** Combine bands into the final onset-strength curve and track the beats. */
        fun finish(): Result {
            val n = bands[0].size
            val out = FloatArray(n)
            val w = (0.5f * SR / HOP).toInt() or 1
            for (b in 0 until 3) {
                val e = bands[b].toArray()
                val mean = boxMean(e, w)
                var sum = 0.0; var sum2 = 0.0
                for (i in 0 until n) { e[i] = max(0f, e[i] - mean[i]); sum += e[i]; sum2 += e[i] * e[i] }
                val sd = if (n > 0) sqrt(max(0.0, sum2 / n - (sum / n) * (sum / n))).toFloat() + 1e-9f else 1f
                for (i in 0 until n) out[i] += WEIGHTS[b] * e[i] / sd
            }
            return analyzeOnset(out)
        }
    }

    fun analyzeOnset(onsetIn: FloatArray): Result {
        val n = onsetIn.size
        if (n < FPS * 3) return Result(0f, IntArray(0), FloatArray(0), onsetIn)
        var s = 0.0; var s2 = 0.0
        for (v in onsetIn) { s += v; s2 += v * v }
        val sd = sqrt(max(0.0, s2 / n - (s / n) * (s / n))).toFloat() + 1e-9f
        val o = FloatArray(n) { onsetIn[it] / sd }
        val (bpm, lag) = estimateTempo(o)
        if (lag <= 0f) return Result(0f, IntArray(0), FloatArray(0), o)
        var beats = track(o, lag)
        beats = trimEdges(beats, o)
        beats = regularize(beats, lag)
        val st = FloatArray(beats.size) { i -> val b = beats[i]; var m = 0f; for (j in max(0, b - 2)..min(n - 1, b + 2)) m = max(m, o[j]); m }
        val ref = if (st.isNotEmpty()) percentile(st, 0.9f).coerceAtLeast(1e-3f) else 1f
        for (i in st.indices) st[i] = (st[i] / ref).coerceIn(0.05f, 1f)
        return Result(bpm, beats, st, o)
    }

    private fun boxMean(e: FloatArray, w: Int): FloatArray {
        val n = e.size; val h = w / 2
        val pre = DoubleArray(n + 1)
        for (i in 0 until n) pre[i + 1] = pre[i] + e[i]
        return FloatArray(n) { i -> ((pre[min(n, i + h + 1)] - pre[max(0, i - h)]) / w).toFloat() }   // zero padded like numpy 'same'
    }

    private fun estimateTempo(o: FloatArray): Pair<Float, Float> {
        val n = o.size
        val lo = (FPS * 60f / 200f).toInt(); val hi = (FPS * 60f / 60f).toInt()
        fun ac(lag: Int): Float { if (lag >= n) return 0f; var a = 0.0; for (t in 0 until n - lag) a += o[t] * o[t + lag]; return a.toFloat() }
        val sc = FloatArray(hi + 2)
        var best = -1; var bs = -1f
        for (lag in lo..hi) {
            val bpm = 60f * FPS / lag
            val wgt = exp(-0.5 * (ln(bpm / 120.0) / ln(2.0)).pow(2.0)).toFloat()
            var v = ac(lag) + 0.5f * ac(2 * lag) + 0.25f * ac(4 * lag)
            v *= wgt; sc[lag] = v
            if (v > bs) { bs = v; best = lag }
        }
        if (best < 0 || bs <= 0f) return 0f to 0f
        var l = best.toFloat()
        if (best in (lo + 1) until hi) {
            val a = sc[best - 1]; val b = sc[best]; val c = sc[best + 1]
            val d = a - 2 * b + c
            if (d != 0f) l = best + 0.5f * (a - c) / d
        }
        return (60f * FPS / l) to l
    }

    private fun track(o: FloatArray, period: Float, tight: Float = 100f): IntArray {
        val n = o.size
        val c = o.copyOf()
        val back = IntArray(n) { -1 }
        val lo = (period / 2f).roundToInt(); val hi = (period * 2f).roundToInt()
        val pen = FloatArray(hi - lo + 1) { -tight * ln((lo + it) / period).pow(2) }
        for (t in 0 until n) {
            val b = t - lo
            if (b < 0) continue
            val a0 = max(t - hi, 0)
            var bi = -1; var bv = -Float.MAX_VALUE
            for (s in a0..b) { val v = c[s] + pen[(t - s) - lo]; if (v > bv) { bv = v; bi = s } }
            if (bv > 0f) { c[t] = o[t] + bv; back[t] = bi } else { c[t] = o[t]; back[t] = -1 }
        }
        val loc = ArrayList<Int>()
        for (i in 1 until n - 1) if (c[i] >= c[i - 1] && c[i] > c[i + 1]) loc.add(i)
        if (loc.isEmpty()) return IntArray(0)
        val med = percentile(FloatArray(loc.size) { c[loc[it]] }, 0.5f)
        val cands = loc.filter { c[it] >= 0.5f * med }
        val last = if (cands.isNotEmpty()) cands.last() else loc.last()
        val out = ArrayList<Int>(); var cur = last
        out.add(cur)
        while (back[cur] >= 0) { cur = back[cur]; out.add(cur) }
        out.reverse()
        return out.toIntArray()
    }

    private fun trimEdges(b: IntArray, o: FloatArray, frac: Float = 0.3f): IntArray {
        if (b.size < 4) return b
        val st = FloatArray(b.size) { i -> var m = 0f; for (j in max(0, b[i] - 2)..min(o.size - 1, b[i] + 2)) m = max(m, o[j]); m }
        val thr = frac * percentile(st, 0.5f)
        var s = 0; var e = b.size
        while (s < e && st[s] < thr) s++
        while (e > s && st[e - 1] < thr) e--
        return b.copyOfRange(s, e)
    }

    private fun regularize(b: IntArray, lag: Float): IntArray {
        if (b.size < 8) return b
        val a = (b.size * 0.15).toInt(); val c = (b.size * 0.85).toInt()
        // least squares line through (index, frame) of the middle 70 %
        var sx = 0.0; var sy = 0.0; var sxx = 0.0; var sxy = 0.0; val m = (c - a).toDouble()
        for (i in a until c) { sx += i; sy += b[i]; sxx += i.toDouble() * i; sxy += i.toDouble() * b[i] }
        val den = m * sxx - sx * sx
        if (abs(den) < 1e-9) return b
        val k = (m * sxy - sx * sy) / den; val q = (sy - k * sx) / m
        val tol = 0.12 * lag
        var s = 0; var e = b.size
        while (s < e && abs(b[s] - (k * s + q)) > tol) s++
        while (e > s && abs(b[e - 1] - (k * (e - 1) + q)) > tol) e--
        return b.copyOfRange(s, e)
    }

    private fun percentile(a: FloatArray, p: Float): Float {
        val s = a.sortedArray()
        if (s.isEmpty()) return 0f
        val idx = p * (s.size - 1); val i = idx.toInt(); val f = idx - i
        return if (i + 1 < s.size) s[i] * (1 - f) + s[i + 1] * f else s[i]
    }
}

class GrowFloat {
    private var a = FloatArray(4096)
    var size = 0; private set
    fun add(v: Float) { if (size == a.size) a = a.copyOf(a.size * 2); a[size++] = v }
    fun toArray(): FloatArray = a.copyOf(size)
    operator fun get(i: Int) = a[i]
}

/** In-place radix-2 complex FFT. */
class Fft(private val n: Int) {
    private val cosT = FloatArray(n / 2) { cos(2.0 * PI * it / n).toFloat() }
    private val sinT = FloatArray(n / 2) { -sin(2.0 * PI * it / n).toFloat() }
    private val rev = IntArray(n).also { r ->
        val bits = Integer.numberOfTrailingZeros(n)
        for (i in 0 until n) r[i] = Integer.reverse(i) ushr (32 - bits)
    }

    fun transform(re: FloatArray, im: FloatArray) {
        for (i in 0 until n) { val j = rev[i]; if (j > i) { val tr = re[i]; re[i] = re[j]; re[j] = tr; val ti = im[i]; im[i] = im[j]; im[j] = ti } }
        var size = 2
        while (size <= n) {
            val half = size / 2; val step = n / size
            var i = 0
            while (i < n) {
                var k = 0
                for (j in i until i + half) {
                    val l = j + half
                    val tre = re[l] * cosT[k] - im[l] * sinT[k]
                    val tim = re[l] * sinT[k] + im[l] * cosT[k]
                    re[l] = re[j] - tre; im[l] = im[j] - tim
                    re[j] += tre; im[j] += tim
                    k += step
                }
                i += size
            }
            size *= 2
        }
    }
}
