package com.sinzer.autoedit.render

import android.content.Context
import androidx.media3.common.C
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.SpeedChangingAudioProcessor
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.FrameDropEffect
import androidx.media3.effect.OverlayEffect
import androidx.media3.effect.Presentation
import androidx.media3.effect.SpeedChangeEffect
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Effects
import com.google.common.collect.ImmutableList
import com.sinzer.autoedit.audio.BeatMap
import com.sinzer.autoedit.catalog.FxCatalog
import com.sinzer.autoedit.catalog.TransitionCatalog
import com.sinzer.autoedit.model.*
import kotlin.math.max
import kotlin.math.min

class Built(val composition: Composition, val outW: Int, val outH: Int, val totalMs: Long)

/**
 * Turns a [Project] into a Media3 [Composition]. The very same builder feeds the preview player and the exporter,
 * so what you see in the preview is what gets rendered (preview just uses a smaller output size).
 */
@UnstableApi
object CompositionBuilder {

    fun dims(a: Aspect, shortSide: Int): Pair<Int, Int> {
        fun even(v: Float) = (v / 2f).toInt() * 2
        return when (a) {
            Aspect.R9_16 -> even(shortSide.toFloat()) to even(shortSide * 16f / 9f)
            Aspect.R16_9 -> even(shortSide * 16f / 9f) to even(shortSide.toFloat())
            Aspect.R1_1 -> even(shortSide.toFloat()) to even(shortSide.toFloat())
            Aspect.R4_5 -> even(shortSide.toFloat()) to even(shortSide * 5f / 4f)
        }
    }

    fun build(ctx: Context, p: Project, beat: BeatMap?, duck: DuckEnvelope?, shortSide: Int, fpsOut: Int?): Built? {
        val (w, h) = dims(p.aspect, shortSide)
        val mainTrack = p.track(p.mainTrackId)
        val main = p.clips.filter { it.trackId == p.mainTrackId }.sortedBy { it.startMs }
        if (main.isEmpty()) return null
        val totalMs = p.videoEndMs()
        val fps = p.fps

        // ---------------- main video sequence ----------------
        val items = ArrayList<EditedMediaItem>()
        main.forEachIndexed { i, c ->
            val a = p.asset(c.assetId) ?: return@forEachIndexed
            val dur = clipDurMs(c)
            val mi = MediaItem.Builder().setUri(a.uri).apply {
                if (a.type == MediaType.IMAGE) setImageDurationMs(dur)
                else setClippingConfiguration(MediaItem.ClippingConfiguration.Builder().setStartPositionMs(c.inMs).setEndPositionMs(c.outMs).build())
            }.build()

            val audio = ArrayList<AudioProcessor>()
            val video = ArrayList<Effect>()
            val speedy = a.type != MediaType.IMAGE && (c.speed != 1f || c.speedCurve.isNotEmpty())
            if (speedy) {
                val sp = ClipSpeedProvider(c)
                video.add(SpeedChangeEffect(sp)); audio.add(SpeedChangingAudioProcessor(sp))
            }
            val gain = ClipGain(c, null, mainTrack?.muted == true)
            if (!gain.isUnity) audio.add(GainProcessor(gain))

            video.add(Presentation.createForWidthAndHeight(w, h, if (c.fit) Presentation.LAYOUT_SCALE_TO_FIT else Presentation.LAYOUT_SCALE_TO_FIT_WITH_CROP))
            if (mainTrack?.hidden == true) video.add(UberEffect(setOf("opac"), FxDriver { FxFrame(1f, mapOf("opac" to 0f)) }))
            val hasTransform = c.tx != 0f || c.ty != 0f || c.scale != 1f || c.rot != 0f || c.opacity != 1f ||
                c.keyframes.any { it.prop in Prop.all && it.prop != Prop.VOLUME }
            if (hasTransform) video.add(UberEffect(TransformDriver.KEYS, TransformDriver(c)))
            val keys = GradeDriver.keysFor(c, c.color)
            if (keys.isNotEmpty()) video.add(UberEffect(keys, GradeDriver(c, c.color)))
            for (inst in c.fx) {
                if (!inst.enabled) continue
                val pr = FxCatalog.get(inst.presetId) ?: continue
                val s = c.startMs + inst.startMs
                val e = if (inst.durMs < 0) c.startMs + dur else s + inst.durMs
                val kf = c.keyframes.firstOrNull { it.prop == "fx:${inst.id}" }?.keys?.sortedBy { it.tMs }
                video.add(UberEffect(pr.params.keys, PresetFxDriver(pr, inst, s, e, beat, kf, c.startMs)))
            }
            // transitions on both sides of every cut
            c.transition?.let { tr ->
                val next = main.getOrNull(i + 1)
                val tp = TransitionCatalog.get(tr.presetId)
                if (next != null && tp != null) {
                    val d = min(tr.durMs, (min(dur, clipDurMs(next)) * 0.45).toLong())
                    if (d >= 60) video.add(UberEffect(tp.keys, TransitionDriver(tp, c.startMs + dur, d, true, tr.intensity, tr.dir)))
                }
            }
            main.getOrNull(i - 1)?.transition?.let { tr ->
                val prev = main[i - 1]; val tp = TransitionCatalog.get(tr.presetId)
                if (tp != null) {
                    val d = min(tr.durMs, (min(dur, clipDurMs(prev)) * 0.45).toLong())
                    if (d >= 60) video.add(UberEffect(tp.keys, TransitionDriver(tp, c.startMs, d, false, tr.intensity, tr.dir)))
                }
            }

            val b = EditedMediaItem.Builder(mi).setEffects(Effects(audio, video))
            if (a.type == MediaType.IMAGE) b.setDurationUs(dur * 1000).setFrameRate(fps)
            items.add(b.build())
        }
        if (items.isEmpty()) return null
        val seqVideo = EditedMediaItemSequence.Builder().apply { items.forEach { addItem(it) } }.build()
        val sequences = arrayListOf(seqVideo)

        // ---------------- audio tracks ----------------
        val firstAudio = p.tracks.firstOrNull { it.kind == TrackKind.AUDIO }?.id
        for (tr in p.tracks.filter { it.kind == TrackKind.AUDIO }) {
            if (tr.hidden) continue
            val cl = p.clips.filter { it.trackId == tr.id }.sortedBy { it.startMs }
            if (cl.isEmpty()) continue
            val sb = EditedMediaItemSequence.Builder()
            var cursor = 0L; var any = false
            for (c0 in cl) {
                val a = p.asset(c0.assetId) ?: continue
                if (c0.startMs >= totalMs) continue
                var c = c0
                val dur0 = clipDurMs(c)
                if (c.startMs + dur0 > totalMs) c = c.copy(outMs = c.inMs + ((totalMs - c.startMs) * c.speed).toLong().coerceAtLeast(100))
                if (c.startMs > cursor) sb.addGap((c.startMs - cursor) * 1000)
                val mi = MediaItem.Builder().setUri(a.uri)
                    .setClippingConfiguration(MediaItem.ClippingConfiguration.Builder().setStartPositionMs(c.inMs).setEndPositionMs(c.outMs).build()).build()
                val audio = ArrayList<AudioProcessor>()
                if (c.speed != 1f || c.speedCurve.isNotEmpty()) audio.add(SpeedChangingAudioProcessor(ClipSpeedProvider(c)))
                val gain = ClipGain(c, if (p.ducking && tr.id == firstAudio) duck else null, tr.muted)
                if (!gain.isUnity) audio.add(GainProcessor(gain))
                sb.addItem(EditedMediaItem.Builder(mi).setRemoveVideo(true).setEffects(Effects(audio, emptyList())).build())
                cursor = c.startMs + clipDurMs(c); any = true
            }
            if (any) sequences.add(sb.build())
        }

        // ---------------- composition-level effects: effect track, text, stickers ----------------
        val comp = ArrayList<Effect>()
        if (fpsOut != null) comp.add(FrameDropEffect.createDefaultFrameDropEffect(fpsOut.toFloat()))
        for (fi in p.fxItems) {
            if (p.track(fi.trackId)?.hidden == true || !fi.fx.enabled) continue
            val pr = FxCatalog.get(fi.fx.presetId) ?: continue
            comp.add(UberEffect(pr.params.keys, PresetFxDriver(pr, fi.fx, fi.startMs, fi.startMs + fi.durMs, beat, null, fi.startMs)))
        }
        val visTexts = p.texts.filter { p.track(it.trackId)?.hidden != true }
        val visStickers = p.stickers.filter { p.track(it.trackId)?.hidden != true }
        if (visTexts.isNotEmpty() || visStickers.isNotEmpty()) {
            val scene = OverlayScene(ctx, visTexts, visStickers, w, h, beat)
            if (scene.slotCount > 0) comp.add(OverlayEffect(ImmutableList.copyOf(scene.overlays())))
        }

        val composition = Composition.Builder(sequences)
            .setEffects(Effects(emptyList(), comp))
            .setHdrMode(Composition.HDR_MODE_TONE_MAP_HDR_TO_SDR_USING_OPEN_GL)
            .build()
        return Built(composition, w, h, totalMs)
    }
}
