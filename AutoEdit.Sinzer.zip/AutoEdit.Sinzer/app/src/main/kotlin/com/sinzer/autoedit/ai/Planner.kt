package com.sinzer.autoedit.ai

import com.sinzer.autoedit.audio.AudioAnalysis
import com.sinzer.autoedit.audio.BeatMap
import com.sinzer.autoedit.model.*
import java.util.Random
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min

class SourceInput(val asset: MediaAsset, val scenes: SceneInfo?, val audio: AudioAnalysis?)

class PlanCut(
    val assetId: String, val inMs: Long, val outMs: Long, val speed: Float, val curve: List<SpeedPoint>,
    val transitionId: String?, val transitionMs: Long, val dir: Int, val punch: Float,
)

/** [beats] are in the music's own time base (ms). [musicInMs] is where the music must start so that timeline 0 = first beat. */
class Plan(val cuts: List<PlanCut>, val musicInMs: Long, val totalMs: Long, val musicAssetId: String?, val timelineBeats: LongArray)

private class Seg(val src: Int, val order: Int, val start: Long, val end: Long, val bins: FloatArray, val isImage: Boolean) {
    val len get() = end - start
}

/**
 * Pure planning logic (no Android). Turns analysed sources + music + a style into a list of cuts.
 * Deterministic for a given [seed].
 */
object AutoEditPlanner {

    fun plan(
        sources: List<SourceInput>, music: BeatMap?, musicAssetId: String?, musicDurMs: Long,
        style: AutoStyle, targetMs: Long, seed: Long = 7L,
    ): Plan {
        require(sources.isNotEmpty()) { "ไม่มีคลิปให้ตัดต่อ" }
        val rnd = Random(seed)
        val hasBeats = music != null && music.beatsMs.size >= 8
        val musicIn = if (hasBeats) music!!.beatsMs.first() else 0L
        val tlBeats = if (hasBeats) LongArray(music!!.beatsMs.size) { music.beatsMs[it] - musicIn } else LongArray(0)
        val strength = if (hasBeats) music!!.strength else FloatArray(0)

        var target = targetMs
        if (hasBeats && musicDurMs > 0) target = min(target, musicDurMs - musicIn)
        val cutTimes = cutTimes(style, tlBeats, strength, target, rnd)

        val pool = buildPool(sources)
        val used = HashMap<Int, MutableList<LongRange>>()
        val usage = IntArray(sources.size)
        var lastOrder = -1
        val cuts = ArrayList<PlanCut>()

        for (i in 0 until cutTimes.size - 1) {
            val len = cutTimes[i + 1] - cutTimes[i]
            val curve = speedCurve(style)
            val speed = when (style.speed) { SpeedMode.SLOWMO -> style.slow; SpeedMode.FAST -> style.fast; else -> 1f }
            val meanInv = if (curve.isNotEmpty()) meanInv(curve) else 1.0 / speed
            val need = (len / meanInv).toLong().coerceAtLeast(120)

            var best: Seg? = null; var bestStart = 0L; var bestVal = -1e9f
            for (s in pool) {
                if (s.isImage) {
                    val v = 0.25f - 0.2f * usage[s.src] + rnd.nextFloat() * 0.02f
                    if (v > bestVal) { bestVal = v; best = s; bestStart = 0 }
                    continue
                }
                val win = min(need, s.len)
                if (win < need * 0.55) continue
                val (st, avg) = bestWindow(s, win)
                var v = avg
                v *= (1f - 0.22f * usage[s.src])
                val ov = overlap(used[s.src], st, st + win) / win.toFloat()
                v *= (1f - 0.85f * ov)
                if (style.chronological) v -= if (s.order < lastOrder) 0.35f else 0f
                if (style.chronological && s.order >= lastOrder && s.order <= lastOrder + 2) v += 0.15f
                v += rnd.nextFloat() * 0.03f
                if (v > bestVal) { bestVal = v; best = s; bestStart = st }
            }
            if (best == null) { // nothing long enough: stretch the longest scene (slow motion)
                best = pool.filter { !it.isImage }.maxByOrNull { it.len } ?: pool.first()
                bestStart = best.start
            }
            val s = best
            lastOrder = s.order; usage[s.src]++
            val cut: PlanCut
            if (s.isImage) {
                cut = PlanCut(sources[s.src].asset.id, 0, len, 1f, emptyList(), null, 0, 0, style.punchZoom)
            } else {
                val win = min(need, s.len)
                used.getOrPut(s.src) { ArrayList() }.add(bestStart..(bestStart + win))
                val realSpeed = if (win < need) (speed * win / need.toFloat()).coerceAtLeast(0.2f) else speed
                val cv = if (win < need) emptyList() else curve
                cut = PlanCut(sources[s.src].asset.id, bestStart, bestStart + win, realSpeed, cv, null, 0, 0, style.punchZoom)
            }
            cuts.add(cut)
        }

        // transitions between consecutive cuts
        val withT = cuts.mapIndexed { i, c ->
            if (i == cuts.size - 1 || style.transitions.isEmpty() || i % style.transEvery != 0) c else {
                val l = cutTimes[i + 1] - cutTimes[i]; val l2 = cutTimes[i + 2] - cutTimes[i + 1]
                val d = min(style.transMs.toLong(), (min(l, l2) * 0.4).toLong())
                if (d < 80) c else PlanCut(c.assetId, c.inMs, c.outMs, c.speed, c.curve,
                    style.transitions[((i / style.transEvery) + (seed % 5).toInt()) % style.transitions.size], d, (i / style.transEvery) % 4, c.punch)
            }
        }
        return Plan(withT, musicIn, cutTimes.last(), if (hasBeats) musicAssetId else null, tlBeats)
    }

    /** Timeline cut points (ms), starting at 0. */
    fun cutTimes(style: AutoStyle, tl: LongArray, strength: FloatArray, target: Long, rnd: Random): List<Long> {
        val cuts = arrayListOf(0L)
        if (tl.size >= 8) {
            var bi = 0; var p = 0; var last = 0L
            while (true) {
                val n = style.beatPattern[p % style.beatPattern.size]; p++
                var tgt = bi + n
                while (tgt < tl.size && tl[tgt] - last < style.minCutMs) tgt++
                if (tgt >= tl.size) break
                if (style.strongBeats && tgt + 1 < tl.size && tl[tgt + 1] - last <= style.maxCutMs && strength[tgt + 1] > strength[tgt] + 0.15f) tgt++
                val t = tl[tgt]
                if (t > target) break
                if (t - last > style.maxCutMs) {
                    val parts = ceil((t - last).toDouble() / style.maxCutMs).toInt()
                    for (k in 1 until parts) cuts.add(last + (t - last) * k / parts)
                }
                cuts.add(t); last = t; bi = tgt
            }
            if (cuts.size < 2) cuts.add(min(target, style.maxCutMs.toLong()))
            if (target - cuts.last() > style.minCutMs && tl.isNotEmpty()) cuts.add(target.coerceAtMost(cuts.last() + style.maxCutMs))
        } else {
            var t = 0L; var k = 0
            while (t < target) {
                val ratio = if (k % 3 == 2) 1.6 else (0.8 + rnd.nextDouble() * 0.45)
                val l = (style.fallbackCutMs * ratio).toLong().coerceIn(style.minCutMs.toLong(), style.maxCutMs.toLong())
                t += l; cuts.add(min(t, target)); k++
                if (t >= target) break
            }
        }
        return cuts.distinct()
    }

    private fun speedCurve(style: AutoStyle): List<SpeedPoint> =
        if (style.speed != SpeedMode.VELOCITY) emptyList()
        else listOf(SpeedPoint(0f, style.slow), SpeedPoint(0.35f, style.slow * 1.15f), SpeedPoint(0.62f, style.fast * 0.7f), SpeedPoint(1f, style.fast))

    private fun meanInv(curve: List<SpeedPoint>): Double {
        val c = Clip(assetId = "", trackId = "", startMs = 0, inMs = 0, outMs = 1000, speedCurve = curve)
        return clipDurMs(c) / 1000.0
    }

    private fun overlap(list: List<LongRange>?, a: Long, b: Long): Long {
        if (list == null) return 0
        var sum = 0L
        for (r in list) { val lo = max(a, r.first); val hi = min(b, r.last); if (hi > lo) sum += hi - lo }
        return sum
    }

    /** Best window of [win] ms inside [s]: returns (startMs, averageScore). */
    private fun bestWindow(s: Seg, win: Long): Pair<Long, Float> {
        val n = max(1, (win / BIN_MS).toInt())
        if (s.bins.size <= n) return s.start to (if (s.bins.isEmpty()) 0.4f else s.bins.average().toFloat())
        var sum = 0f; for (i in 0 until n) sum += s.bins[i]
        var best = sum; var bi = 0
        for (i in 1..(s.bins.size - n)) { sum += s.bins[i + n - 1] - s.bins[i - 1]; if (sum > best) { best = sum; bi = i } }
        val start = (s.start + bi * BIN_MS).coerceAtMost(s.end - win)
        return start to best / n
    }

    private fun buildPool(sources: List<SourceInput>): List<Seg> {
        val pool = ArrayList<Seg>(); var order = 0
        sources.forEachIndexed { si, src ->
            val a = src.asset
            if (a.type == MediaType.IMAGE) { pool.add(Seg(si, order++, 0, 5000, FloatArray(0), true)); return@forEachIndexed }
            val cuts = (listOf(0L) + (src.scenes?.cutsMs ?: emptyList()) + listOf(a.durationMs)).distinct().sorted()
            val merged = ArrayList<LongRange>()
            for (i in 0 until cuts.size - 1) {
                val r = cuts[i]..cuts[i + 1]
                if (merged.isNotEmpty() && (r.last - r.first) < 500) merged[merged.size - 1] = merged.last().first..r.last else merged.add(r)
            }
            for (r in merged) {
                val nb = max(1, ((r.last - r.first) / BIN_MS).toInt())
                val bins = FloatArray(nb) { b ->
                    val t = r.first + b * BIN_MS
                    val m = src.scenes?.motion?.getOrNull((t / BIN_MS).toInt()) ?: 0.5f
                    val e = src.audio?.rmsAt(t + BIN_MS / 2)?.let { (it * 6f).coerceIn(0f, 1f) } ?: 0.4f
                    val edge = if (b == 0 || b == nb - 1) 0.85f else 1f      // avoid scene boundaries (cut jitter)
                    (0.6f * m + 0.4f * e) * edge
                }
                // trim the first/last 100 ms of each scene so cuts never show the neighbouring scene
                val st = if (merged.size > 1) r.first + 100 else r.first
                val en = if (merged.size > 1) r.last - 100 else r.last
                if (en - st >= 300) pool.add(Seg(si, order++, st, en, bins, false))
            }
        }
        return pool
    }
}
