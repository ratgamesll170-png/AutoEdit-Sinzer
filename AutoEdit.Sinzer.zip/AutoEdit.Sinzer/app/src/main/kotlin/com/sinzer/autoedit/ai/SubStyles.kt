package com.sinzer.autoedit.ai

import com.sinzer.autoedit.model.TextAnimRef
import com.sinzer.autoedit.model.TextItem

class SubStyle(val id: String, val nameTh: String)

/** Subtitle looks. Each one really changes font weight/colour/stroke/box/animation of every subtitle line. */
object SubStyles {
    val all = listOf(
        SubStyle("classic", "คลาสสิก ขาวขอบดำ"), SubStyle("karaoke", "คาราโอเกะเหลือง"), SubStyle("neon", "นีออนฟ้า"),
        SubStyle("box", "กล่องดำ"), SubStyle("minimal", "มินิมอล"), SubStyle("pop", "ป๊อปเหลืองใหญ่"),
        SubStyle("comic", "การ์ตูน"), SubStyle("elegant", "หรูหรา เฟดเข้า"),
    )

    fun apply(id: String, t: TextItem): TextItem {
        val base = t.copy(y = 0.8f, size = 52f, align = 1, bold = true, italic = false, strokeW = 0f, shadow = 0f, glow = 0f, bgColor = 0, anims = emptyList(), emphasis = false,
            color = 0xFFFFFFFF.toInt(), fontId = "sys:sans", letterSpacing = 0f)
        return when (id) {
            "classic" -> base.copy(strokeW = 4f, anims = listOf(TextAnimRef("ta_fade_whole_0", 0, 180)))
            "karaoke" -> base.copy(strokeW = 4f, highlightColor = 0xFFFFE14D.toInt(), anims = listOf(TextAnimRef("ta_karaoke_word_0", 2, 300)))
            "neon" -> base.copy(color = 0xFFE8FBFF.toInt(), glow = 1.2f, glowColor = 0xFF35D0FF.toInt(), anims = listOf(TextAnimRef("ta_fade_whole_0", 0, 200)))
            "box" -> base.copy(bgColor = 0xCC000000.toInt(), size = 46f, anims = listOf(TextAnimRef("ta_pop_whole_0", 0, 220)))
            "minimal" -> base.copy(bold = false, shadow = 1f, size = 44f, anims = listOf(TextAnimRef("ta_fade_whole_0", 0, 250)))
            "pop" -> base.copy(size = 66f, color = 0xFFFFE14D.toInt(), strokeW = 5f, emphasis = true, highlightColor = 0xFFFFFFFF.toInt(), anims = listOf(TextAnimRef("ta_pop_whole_0", 0, 240)))
            "comic" -> base.copy(size = 60f, color = 0xFFFFE14D.toInt(), strokeW = 7f, anims = listOf(TextAnimRef("ta_bounce_whole_1", 0, 380)))
            "elegant" -> base.copy(bold = false, italic = true, shadow = 1.5f, fontId = "sys:serif", size = 50f, anims = listOf(TextAnimRef("ta_fade_whole_0", 0, 450), TextAnimRef("ta_fade_whole_0", 1, 300)))
            else -> base
        }
    }
}
