package com.sinzer.autoedit.vm

import android.app.Application
import android.media.MediaRecorder
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.transformer.CompositionPlayer
import com.sinzer.autoedit.ai.*
import com.sinzer.autoedit.audio.AudioAnalysis
import com.sinzer.autoedit.audio.AudioAnalyzer
import com.sinzer.autoedit.audio.BeatMap
import com.sinzer.autoedit.catalog.*
import com.sinzer.autoedit.data.*
import com.sinzer.autoedit.media.*
import com.sinzer.autoedit.model.*
import com.sinzer.autoedit.render.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import java.io.File
import kotlin.math.max
import kotlin.math.min

data class Busy(val label: String, val progress: Float = -1f, val cancellable: Boolean = true)

data class AutoConfig(
    val styleId: String = "beatsync", val musicAssetId: String? = null, val useVideoAudioAsMusic: Boolean = false,
    val targetSec: Int = 30, val subtitles: Boolean = false, val applyAspect: Boolean = true, val seed: Long = 7L,
)

@UnstableApi
class MainVM(app: Application) : AndroidViewModel(app) {
    private val ctx get() = getApplication<Application>()
    private val db = AppDb.get(app)
    val repo = ProjectRepository(db.projects())
    val settingsStore = SettingsStore(app)
    val settings = settingsStore.flow.stateIn(viewModelScope, SharingStarted.Eagerly, AppSettings())
    val projects = repo.observe()

    // ---------------- editing session ----------------
    private val _project = MutableStateFlow<Project?>(null)
    val project: StateFlow<Project?> = _project
    private val undoStack = ArrayDeque<Project>()
    private val redoStack = ArrayDeque<Project>()
    private val _histVersion = MutableStateFlow(0)
    val canUndo = _histVersion.map { undoStack.isNotEmpty() }.stateIn(viewModelScope, SharingStarted.Eagerly, false)
    val canRedo = _histVersion.map { redoStack.isNotEmpty() }.stateIn(viewModelScope, SharingStarted.Eagerly, false)
    val selection = MutableStateFlow<Sel?>(null)
    val playhead = MutableStateFlow(0L)
    val playing = MutableStateFlow(false)
    val analyses = MutableStateFlow<Map<String, AudioAnalysis>>(emptyMap())
    val busy = MutableStateFlow<Busy?>(null)
    val messages = MutableSharedFlow<String>(extraBufferCapacity = 8)
    val missingAssets = MutableStateFlow<Set<String>>(emptySet())
    val previewError = MutableStateFlow<String?>(null)
    val recording = MutableStateFlow(false)
    private var job: Job? = null
    private var saveJob: Job? = null
    private var gestureBase: Project? = null
    private val sceneCache = HashMap<String, SceneInfo>()

    val exporter = Exporter(app, viewModelScope)

    fun toast(s: String) { messages.tryEmit(s) }

    // ---------------- projects ----------------
    fun newProject(name: String, aspect: Aspect): Project {
        val p = Project(name = name.ifBlank { "โปรเจกต์ใหม่" }, aspect = aspect)
        openProject(p); viewModelScope.launch { repo.save(p) }
        return p
    }

    fun openProject(p: Project) {
        undoStack.clear(); redoStack.clear(); _histVersion.value++
        selection.value = null; playhead.value = 0; analyses.value = emptyMap(); sceneCache.clear()
        _project.value = p
        checkMissing(p)
        viewModelScope.launch(Dispatchers.Default) {
            val map = HashMap<String, AudioAnalysis>()
            p.assets.filter { it.hasAudio || it.type == MediaType.AUDIO }.forEach { a -> AudioAnalyzer.cached(ctx, a)?.let { map[a.id] = it } }
            analyses.value = map
        }
    }

    fun openById(id: String, onDone: (Boolean) -> Unit) = viewModelScope.launch {
        val p = repo.load(id)
        if (p == null) { toast("เปิดโปรเจกต์ไม่ได้ (ข้อมูลเสียหาย)"); onDone(false) } else { openProject(p); onDone(true) }
    }

    fun closeProject() { viewModelScope.launch { _project.value?.let { repo.save(it) }; _project.value = null } }

    private fun checkMissing(p: Project) = viewModelScope.launch(Dispatchers.IO) {
        missingAssets.value = p.assets.filter { !MediaProbe.exists(ctx, it.uri) }.map { it.id }.toSet()
    }

    /** Re-link a missing source file. The user picks the replacement. */
    fun relink(assetId: String, uri: Uri) = viewModelScope.launch {
        try {
            val n = MediaProbe.probe(ctx, uri)
            edit { p -> p.copy(assets = p.assets.map { if (it.id == assetId) n.copy(id = assetId) else it }) }
            _project.value?.let { checkMissing(it) }
        } catch (e: Exception) { toast(e.message ?: "ไฟล์ใช้ไม่ได้") }
    }

    fun renameProject(id: String, name: String) = viewModelScope.launch { repo.rename(id, name); if (_project.value?.id == id) _project.update { it?.copy(name = name) } }
    fun duplicateProject(id: String, name: String) = viewModelScope.launch { repo.duplicate(id, name) }
    fun deleteProject(id: String) = viewModelScope.launch { repo.delete(id) }

    // ---------------- history ----------------
    fun edit(push: Boolean = true, f: (Project) -> Project) {
        val cur = _project.value ?: return
        val n = f(cur)
        if (n == cur) return
        if (push && gestureBase == null) { undoStack.addLast(cur); if (undoStack.size > 100) undoStack.removeFirst(); redoStack.clear(); _histVersion.value++ }
        _project.value = n
        scheduleSave()
    }

    fun beginGesture() { gestureBase = _project.value }
    /** For sliders: opens one undo step on the first change and closes it when the slider is released. */
    fun beginGestureOnce() { if (gestureBase == null) gestureBase = _project.value }
    fun viewModelScope_markTip(key: String) { viewModelScope.launch { settingsStore.markTipSeen(key) } }
    fun viewModelScope_readText(u: Uri, done: (String) -> Unit) {
        viewModelScope.launch {
            val t = withContext(Dispatchers.IO) { runCatching { ctx.contentResolver.openInputStream(u)?.bufferedReader()?.readText() }.getOrNull() }
            if (t == null) toast("เปิดไฟล์ไม่ได้") else done(t)
        }
    }
    fun viewModelScope_launchProbe(u: Uri) {
        viewModelScope.launch {
            try { val a = MediaProbe.probe(ctx, u); addAudioAsset(a) } catch (e: Exception) { toast(e.message ?: "นำเข้าเสียงไม่ได้") }
        }
    }
    fun endGesture() {
        val base = gestureBase ?: return
        gestureBase = null
        if (_project.value != base) { undoStack.addLast(base); if (undoStack.size > 100) undoStack.removeFirst(); redoStack.clear(); _histVersion.value++ }
    }

    fun undo() { val cur = _project.value ?: return; val p = undoStack.removeLastOrNull() ?: return; redoStack.addLast(cur); _project.value = p; _histVersion.value++; fixSel(); scheduleSave() }
    fun redo() { val cur = _project.value ?: return; val p = redoStack.removeLastOrNull() ?: return; undoStack.addLast(cur); _project.value = p; _histVersion.value++; fixSel(); scheduleSave() }
    private fun fixSel() { val s = selection.value; val p = _project.value; if (s != null && p != null && Ops.span(p, s) == null) selection.value = null }

    private fun scheduleSave() {
        if (!settings.value.autoSave) return
        saveJob?.cancel()
        saveJob = viewModelScope.launch { delay(1200); _project.value?.let { repo.save(it) } }
    }
    fun saveNow() { viewModelScope.launch { _project.value?.let { repo.save(it) } } }

    // ---------------- import ----------------
    fun importMedia(uris: List<Uri>, toTimeline: Boolean = true) {
        if (uris.isEmpty()) return
        job = viewModelScope.launch {
            busy.value = Busy("กำลังนำเข้าไฟล์", 0f)
            val ok = ArrayList<MediaAsset>(); val errs = ArrayList<String>()
            uris.forEachIndexed { i, u ->
                try { ok.add(MediaProbe.probe(ctx, u)) } catch (e: Exception) { errs.add(e.message ?: "นำเข้าไม่ได้") }
                busy.value = Busy("กำลังนำเข้าไฟล์ ${i + 1}/${uris.size}", (i + 1f) / uris.size)
            }
            edit { p0 -> var p = p0; ok.forEach { a -> p = if (toTimeline) Ops.appendToMain(p, a) else Ops.addAssets(p, listOf(a)) }; p }
            busy.value = null
            if (errs.isNotEmpty()) toast(errs.joinToString("\n"))
            ok.filter { it.hasAudio || it.type == MediaType.AUDIO }.forEach { a ->
                analyzeAudio(a, quiet = true) { r -> if (r != null && a.type == MediaType.AUDIO && _project.value?.beatAssetId == null) setBeatSource(a.id) }
            }
        }
    }

    // ---------------- audio / beats ----------------
    fun analyzeAudio(a: MediaAsset, quiet: Boolean = false, onDone: (AudioAnalysis?) -> Unit = {}) {
        if (analyses.value.containsKey(a.id)) { onDone(analyses.value[a.id]); return }
        viewModelScope.launch {
            if (!quiet) busy.value = Busy("กำลังวิเคราะห์เสียงและจังหวะ", 0f)
            val r = try { AudioAnalyzer.analyze(ctx, a) { pr -> if (!quiet) busy.value = Busy("กำลังวิเคราะห์เสียงและจังหวะ ${(pr * 100).toInt()}%", pr) } }
            catch (e: Exception) { toast("วิเคราะห์เสียงไม่สำเร็จ: ${e.message}"); null }
            if (!quiet) busy.value = null
            if (r != null) analyses.update { it + (a.id to r) }
            else if (!quiet) toast("ไม่พบเสียงในไฟล์นี้")
            onDone(r)
        }
    }

    fun setBeatSource(assetId: String?) = edit { it.copy(beatAssetId = assetId) }
    fun editBeats(assetId: String, f: (BeatEdit) -> BeatEdit) = edit { p -> p.copy(beatEdits = p.beatEdits + (assetId to f(p.beatEdits[assetId] ?: BeatEdit()))) }

    /** Beats on the project timeline (after user corrections), or empty. */
    fun timelineBeats(p: Project, an: Map<String, AudioAnalysis>): BeatMap {
        val id = p.beatAssetId ?: return BeatMap.EMPTY
        val a = an[id] ?: return BeatMap.EMPTY
        val clip = p.clips.firstOrNull { it.assetId == id && p.track(it.trackId)?.kind == TrackKind.AUDIO } ?: p.clips.firstOrNull { it.assetId == id } ?: return BeatMap.EMPTY
        val bm = BeatMap.build(a, p.beatEdits[id])
        val t = ArrayList<Long>(); val s = ArrayList<Float>()
        for (i in bm.beatsMs.indices) {
            val b = bm.beatsMs[i]
            if (b < clip.inMs || b > clip.outMs) continue
            t.add(clip.startMs + ((b - clip.inMs) / clip.speed).toLong()); s.add(bm.strength.getOrElse(i) { 0.8f })
        }
        return BeatMap(t.toLongArray(), s.toFloatArray(), bm.bpm)
    }

    private fun buildDuck(p: Project, an: Map<String, AudioAnalysis>): DuckEnvelope? {
        if (!p.ducking) return null
        val firstAudio = p.tracks.firstOrNull { it.kind == TrackKind.AUDIO }?.id
        val iv = ArrayList<LongRange>()
        for (c in p.clips) {
            if (c.muted || c.trackId == firstAudio) continue
            val a = an[c.assetId] ?: continue
            if (p.track(c.trackId)?.muted == true) continue
            var s = (c.inMs / 1000) * 1000
            while (s < c.outMs) {
                if (a.voiceAt(s) > 0.5f) { val st = c.startMs + ((max(s, c.inMs) - c.inMs) / c.speed).toLong(); iv.add(st..(st + (1000 / c.speed).toLong())) }
                s += 1000
            }
        }
        return DuckEnvelope.of(iv, p.duckLevel)
    }

    // ---------------- clip operations ----------------
    fun split() { val p = _project.value ?: return; val s = selection.value ?: autoSel(p) ?: return toast("เลือกคลิปก่อนแล้วจึงกด Split")
        val n = Ops.split(p, s, playhead.value); if (n == null) toast("ตำแหน่งนี้แบ่งไม่ได้ (ใกล้ขอบเกินไป หรืออยู่นอกคลิป)") else edit { n } }
    private fun autoSel(p: Project): Sel? = p.clips.firstOrNull { it.trackId == p.mainTrackId && playhead.value >= it.startMs && playhead.value < it.endMs() }?.let { Sel(ItemKind.CLIP, it.id) }
    fun deleteSel() { val s = selection.value ?: return; edit { Ops.delete(it, s) }; selection.value = null }
    fun duplicateSel() { val s = selection.value ?: return; edit { Ops.duplicate(it, s) } }
    fun trim(s: Sel, side: Int, delta: Long) = edit { Ops.trim(it, s, side, delta) }
    fun move(s: Sel, start: Long, track: String? = null) = edit { Ops.move(it, s, start, track) }
    fun updateClip(id: String, f: (Clip) -> Clip) = edit { Ops.updateClip(it, id, f) }
    fun updateText(id: String, f: (TextItem) -> TextItem) = edit { Ops.updateText(it, id, f) }
    fun updateSticker(id: String, f: (StickerItem) -> StickerItem) = edit { Ops.updateSticker(it, id, f) }
    fun updateFxItem(id: String, f: (FxItem) -> FxItem) = edit { Ops.updateFxItem(it, id, f) }
    fun setAspect(a: Aspect) = edit { it.copy(aspect = a) }
    fun addTrack(k: TrackKind) = edit { Ops.addTrack(it, k) }
    fun updateTrack(id: String, f: (Track) -> Track) = edit { Ops.updateTrack(it, id, f) }
    fun setSnap(v: Boolean) { edit { it.copy(snap = v) }; viewModelScope.launch { settingsStore.setSnap(v) } }

    fun applyColorPreset(clipId: String, presetId: String?) {
        val pr = ColorPresets.get(presetId)
        updateClip(clipId) { it.copy(color = pr?.adj ?: ColorAdj(), colorPreset = if (pr?.id == "c_neutral") null else pr?.id) }
    }

    /** Constant speed: clears any speed curve. Main-track clips re-flow automatically. */
    fun setSpeed(clipId: String, speed: Float) = updateClip(clipId) { it.copy(speed = speed.coerceIn(0.1f, 16f), speedCurve = emptyList()) }
    fun setSpeedCurve(clipId: String, curve: List<SpeedPoint>) = updateClip(clipId) { it.copy(speedCurve = curve.sortedBy { p -> p.pos }) }

    fun freezeFrame() {
        val p = _project.value ?: return
        val s = selection.value?.takeIf { it.kind == ItemKind.CLIP } ?: autoSel(p) ?: return toast("เลือกคลิปวิดีโอก่อน")
        val c = p.clips.first { it.id == s.id }; val a = p.asset(c.assetId) ?: return
        if (a.type != MediaType.VIDEO) return toast("Freeze ใช้ได้กับคลิปวิดีโอเท่านั้น")
        val local = (playhead.value - c.startMs).coerceIn(0, clipDurMs(c))
        val src = sourceAtLocal(c, local)
        viewModelScope.launch {
            busy.value = Busy("กำลังสร้างภาพนิ่ง", -1f, false)
            val f = FrameGrab.savePng(ctx, a, src)
            busy.value = null
            if (f == null) return@launch toast("ดึงเฟรมไม่สำเร็จ")
            try {
                val img = MediaProbe.probe(ctx, Uri.fromFile(f))
                edit { cur ->
                    val withA = Ops.addAssets(cur, listOf(img.copy(width = a.width, height = a.height)))
                    val split = Ops.split(withA, Sel(ItemKind.CLIP, c.id), playhead.value) ?: withA
                    val right = split.clips.firstOrNull { it.trackId == c.trackId && it.startMs >= playhead.value - 1 && it.id != c.id && it.assetId == c.assetId && it.inMs == src }
                    val still = Clip(assetId = img.id, trackId = c.trackId, startMs = playhead.value, inMs = 0, outMs = 2000, fit = c.fit)
                    var q = split.copy(clips = split.clips + still)
                    // place still between the two halves on the main track
                    if (c.trackId == q.mainTrackId && right != null) q = Ops.reorderMain(q, still.id, (right.startMs - 1))
                    Ops.relayoutMain(q)
                }
            } catch (e: Exception) { toast("สร้างภาพนิ่งไม่สำเร็จ: ${e.message}") }
        }
    }

    fun extractAudio(clipId: String) {
        val p = _project.value ?: return
        val c = p.clips.firstOrNull { it.id == clipId } ?: return
        val a = p.asset(c.assetId) ?: return
        if (!a.hasAudio) return toast("คลิปนี้ไม่มีเสียง")
        val tr = p.tracks.filter { it.kind == TrackKind.AUDIO }.getOrNull(1)?.id ?: Ops.firstAudioTrack(p)
        edit { cur ->
            val ac = c.copy(id = newId(), trackId = tr, audioOnly = true, fx = emptyList(), transition = null, keyframes = emptyList(), color = ColorAdj(), muted = false)
            val muted = Ops.updateClip(cur, clipId) { it.copy(muted = true) }
            Ops.resolveOverlap(muted.copy(clips = muted.clips + ac), Sel(ItemKind.CLIP, ac.id))
        }
        analyzeAudio(a, quiet = true)
    }

    fun addAudioAsset(a: MediaAsset, trackIdx: Int = 0) {
        val p = _project.value ?: return
        val tr = p.tracks.filter { it.kind == TrackKind.AUDIO }.getOrNull(trackIdx)?.id ?: Ops.firstAudioTrack(p)
        edit { Ops.addAudio(it, a, tr, playhead.value) }
        analyzeAudio(a, quiet = true) { if (it != null && trackIdx == 0 && _project.value?.beatAssetId == null) setBeatSource(a.id) }
    }

    // ---------------- text / sticker / effects ----------------
    fun addText(text: String = "พิมพ์ข้อความ"): String {
        val p = _project.value ?: return ""
        val tr = p.tracks.first { it.kind == TrackKind.TEXT }.id
        val t = TextItem(trackId = tr, text = text, startMs = playhead.value, durMs = 3000, y = 0.5f, size = 72f, strokeW = 3f)
        edit { Ops.resolveOverlap(it.copy(texts = it.texts + t), Sel(ItemKind.TEXT, t.id)) }
        selection.value = Sel(ItemKind.TEXT, t.id)
        return t.id
    }

    fun addSticker(emoji: String?, uri: String?) {
        val p = _project.value ?: return
        val tr = p.tracks.first { it.kind == TrackKind.STICKER }.id
        val s = StickerItem(trackId = tr, emoji = emoji, imageUri = uri, startMs = playhead.value, durMs = 3000)
        edit { Ops.resolveOverlap(it.copy(stickers = it.stickers + s), Sel(ItemKind.STICKER, s.id)) }
        selection.value = Sel(ItemKind.STICKER, s.id)
    }

    fun addClipFx(clipId: String, presetId: String) {
        val pr = FxCatalog.get(presetId) ?: return
        updateClip(clipId) { it.copy(fx = it.fx + FxInstance(presetId = presetId, beatSync = pr.beat)) }
    }
    fun updateClipFx(clipId: String, fxId: String, f: (FxInstance) -> FxInstance) = updateClip(clipId) { c -> c.copy(fx = c.fx.map { if (it.id == fxId) f(it) else it }) }
    fun removeClipFx(clipId: String, fxId: String) = updateClip(clipId) { c -> c.copy(fx = c.fx.filterNot { it.id == fxId }) }
    fun moveClipFx(clipId: String, fxId: String, dir: Int) = updateClip(clipId) { c ->
        val i = c.fx.indexOfFirst { it.id == fxId }; val j = i + dir
        if (i < 0 || j !in c.fx.indices) c else c.copy(fx = c.fx.toMutableList().apply { add(j, removeAt(i)) })
    }

    fun addFxItem(presetId: String) {
        val pr = FxCatalog.get(presetId) ?: return
        val p = _project.value ?: return
        val tr = p.tracks.first { it.kind == TrackKind.EFFECT }.id
        val it0 = FxItem(trackId = tr, startMs = playhead.value, durMs = 3000, fx = FxInstance(presetId = presetId, beatSync = pr.beat))
        edit { Ops.resolveOverlap(it.copy(fxItems = it.fxItems + it0), Sel(ItemKind.FX, it0.id)) }
        selection.value = Sel(ItemKind.FX, it0.id)
    }

    fun setTransition(clipId: String, t: TransitionRef?) = updateClip(clipId) { it.copy(transition = t) }
    fun setTransitionAll(t: TransitionRef) = edit { p ->
        val main = p.clips.filter { it.trackId == p.mainTrackId }.sortedBy { it.startMs }
        val last = main.lastOrNull()?.id
        p.copy(clips = p.clips.map { if (it.trackId == p.mainTrackId && it.id != last) it.copy(transition = t) else if (it.trackId == p.mainTrackId) it.copy(transition = null) else it })
    }

    /** Manual "cut to the music": splits the clip at every [every]-th beat inside it. every = 0.5, 1, 2, 4. */
    fun splitAtBeats(clipId: String, every: Float) {
        val p = _project.value ?: return
        val bm = timelineBeats(p, analyses.value)
        if (bm.isEmpty) return toast("ยังไม่มีบีต: เลือกเพลงในแท็บบีตแล้วรอวิเคราะห์ก่อน")
        val c = p.clips.firstOrNull { it.id == clipId } ?: return
        val phase = p.beatAssetId?.let { p.beatEdits[it]?.phase } ?: 0
        val cuts = bm.grouped(every, phase).filter { it > c.startMs + 150 && it < c.endMs() - 150 }
        if (cuts.isEmpty()) return toast("ไม่มีบีตอยู่ในช่วงของคลิปนี้")
        edit { cur ->
            var q = cur
            for (t in cuts) {
                val target = q.clips.firstOrNull { it.trackId == c.trackId && it.assetId == c.assetId && t > it.startMs && t < it.endMs() } ?: continue
                q = Ops.split(q, Sel(ItemKind.CLIP, target.id), t) ?: q
            }
            q
        }
        toast("ตัดตามบีตแล้ว ${cuts.size} จุด")
    }

    // ---------------- keyframes ----------------
    fun setKeyframe(s: Sel, prop: String, value: Float) {
        val local = (playhead.value - (Ops.span(_project.value ?: return, s)?.start ?: return)).coerceAtLeast(0)
        when (s.kind) {
            ItemKind.CLIP -> updateClip(s.id) { it.copy(keyframes = Ops.setKeyframe(it.keyframes, prop, local, value)) }
            ItemKind.TEXT -> updateText(s.id) { it.copy(keyframes = Ops.setKeyframe(it.keyframes, prop, local, value)) }
            ItemKind.STICKER -> updateSticker(s.id) { it.copy(keyframes = Ops.setKeyframe(it.keyframes, prop, local, value)) }
            else -> {}
        }
    }
    fun removeKeyframe(s: Sel, prop: String, tMs: Long) = when (s.kind) {
        ItemKind.CLIP -> updateClip(s.id) { it.copy(keyframes = Ops.removeKeyframe(it.keyframes, prop, tMs)) }
        ItemKind.TEXT -> updateText(s.id) { it.copy(keyframes = Ops.removeKeyframe(it.keyframes, prop, tMs)) }
        ItemKind.STICKER -> updateSticker(s.id) { it.copy(keyframes = Ops.removeKeyframe(it.keyframes, prop, tMs)) }
        else -> Unit
    }

    // ---------------- voice-over ----------------
    private var recorder: MediaRecorder? = null
    private var recFile: File? = null
    fun startRecording(): Boolean {
        return try {
            val f = File(File(ctx.filesDir, "voice").apply { mkdirs() }, "voiceover_${System.currentTimeMillis()}.m4a")
            val r = if (android.os.Build.VERSION.SDK_INT >= 31) MediaRecorder(ctx) else @Suppress("DEPRECATION") MediaRecorder()
            r.setAudioSource(MediaRecorder.AudioSource.MIC); r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC); r.setAudioSamplingRate(44100); r.setAudioEncodingBitRate(128000)
            r.setOutputFile(f.absolutePath); r.prepare(); r.start()
            recorder = r; recFile = f; recording.value = true; true
        } catch (e: Exception) { toast("เริ่มอัดเสียงไม่ได้: ${e.message}"); recording.value = false; false }
    }
    fun stopRecording() {
        val r = recorder ?: return; val f = recFile ?: return
        try { r.stop() } catch (e: Exception) { toast("อัดเสียงสั้นเกินไป"); f.delete() }
        runCatching { r.release() }; recorder = null; recording.value = false
        if (!f.exists()) return
        viewModelScope.launch {
            try { val a = MediaProbe.probe(ctx, Uri.fromFile(f)); addAudioAsset(a, 1) } catch (e: Exception) { toast(e.message ?: "นำเข้าเสียงที่อัดไม่ได้") }
        }
    }

    // ---------------- AI Auto Edit ----------------
    fun runAutoEdit(cfg: AutoConfig, onDone: (Boolean) -> Unit = {}) {
        val p0 = _project.value ?: return
        val vids = p0.assets.filter { it.type != MediaType.AUDIO }
        if (vids.isEmpty()) { toast("นำเข้าวิดีโอหรือรูปภาพก่อน"); return onDone(false) }
        job?.cancel()
        job = viewModelScope.launch {
            try {
                val style = AutoStyles.get(cfg.styleId)
                val total = vids.size + 2; var step = 0
                fun prog(label: String, f: Float = 0f) { busy.value = Busy("$label", (step + f) / total) }
                // 1. music
                val musicAsset = when {
                    cfg.musicAssetId != null -> p0.asset(cfg.musicAssetId)
                    cfg.useVideoAudioAsMusic -> vids.firstOrNull { it.hasAudio }
                    else -> p0.assets.firstOrNull { it.type == MediaType.AUDIO }
                }
                var music: BeatMap? = null
                if (musicAsset != null) {
                    prog("วิเคราะห์เพลงและจังหวะ")
                    val a = analyses.value[musicAsset.id] ?: AudioAnalyzer.analyze(ctx, musicAsset) { prog("วิเคราะห์เพลงและจังหวะ", it) }
                    if (a != null) { analyses.update { it + (musicAsset.id to a) }; music = BeatMap.build(a, p0.beatEdits[musicAsset.id]) }
                    else toast("อ่านเสียงจากไฟล์เพลงไม่ได้ จะตัดตามความยาวคงที่แทน")
                }
                step++
                // 2. visual + audio analysis per source
                val srcs = ArrayList<SourceInput>()
                for (a in vids) {
                    prog("วิเคราะห์ฉาก: ${a.name}")
                    val sc = sceneCache.getOrPut(a.id) { SceneDetector.analyze(ctx, a) { prog("วิเคราะห์ฉาก: ${a.name}", it) } }
                    val au = if (a.hasAudio) (analyses.value[a.id] ?: AudioAnalyzer.analyze(ctx, a) { }?.also { r -> analyses.update { m -> m + (a.id to r) } }) else null
                    srcs.add(SourceInput(a, sc, au)); step++
                }
                // 3. plan
                prog("กำลังวางแผนการตัด")
                val srcDur = vids.sumOf { if (it.type == MediaType.IMAGE) 3000L else it.durationMs }
                val musicDur = musicAsset?.let { analyses.value[it.id]?.durationMs ?: it.durationMs } ?: 0L
                val target = if (cfg.targetSec <= 0) (if (musicDur > 0) musicDur else srcDur) else cfg.targetSec * 1000L
                val plan = withContext(Dispatchers.Default) { AutoEditPlanner.plan(srcs, music, musicAsset?.id, musicDur, style, target, cfg.seed) }
                // 4. apply
                edit { applyPlan(it, plan, style, cfg, musicAsset, vids) }
                playhead.value = 0; selection.value = null
                busy.value = null
                toast("AI ตัดต่อเสร็จแล้ว: ${plan.cuts.size} คลิป ความยาว ${plan.totalMs / 1000} วินาที — แก้ไขต่อได้ทุกส่วน")
                if (cfg.subtitles) generateSubtitles(null)
                onDone(true)
            } catch (e: CancellationException) { busy.value = null; toast("ยกเลิกการตัดต่ออัตโนมัติ"); onDone(false) }
            catch (e: Exception) { busy.value = null; toast("AI Auto Edit ผิดพลาด: ${e.message}"); onDone(false) }
        }
    }

    private fun applyPlan(p: Project, plan: Plan, style: AutoStyle, cfg: AutoConfig, music: MediaAsset?, vids: List<MediaAsset>): Project {
        val main = p.mainTrackId
        val musicTrack = Ops.firstAudioTrack(p)
        val grade = ColorPresets.get(style.color)
        var t = 0L
        val newClips = ArrayList<Clip>()
        val mutedAsset = if (cfg.useVideoAudioAsMusic && music != null) music.id else null
        plan.cuts.forEach { pc ->
            val a = p.asset(pc.assetId)!!
            val isImg = a.type == MediaType.IMAGE
            val punch = if (pc.punch > 0f) listOf(KfTrack(Prop.SCALE, listOf(Keyframe(0, 1f + pc.punch, Ease.OUT), Keyframe(220, 1f)))) else emptyList()
            val c = Clip(assetId = a.id, trackId = main, startMs = t, inMs = pc.inMs, outMs = pc.outMs, speed = pc.speed, speedCurve = pc.curve,
                volume = style.origVol, muted = style.origVol <= 0.01f || a.id == mutedAsset || !a.hasAudio,
                fadeInMs = 0, fadeOutMs = 0, color = grade?.adj ?: ColorAdj(), colorPreset = grade?.id,
                fx = style.fx.map { FxInstance(presetId = it.presetId, intensity = it.intensity, beatSync = it.beat) },
                transition = pc.transitionId?.let { TransitionRef(it, pc.transitionMs, 1f, pc.dir) }, keyframes = punch)
            newClips.add(c); t += clipDurMs(c)
        }
        val others = p.clips.filter { it.trackId != main && !(it.trackId == musicTrack) }
        var q = p.copy(clips = others + newClips, styleId = style.id)
        if (cfg.applyAspect && style.aspect != null) q = q.copy(aspect = style.aspect)
        if (music != null && plan.musicAssetId != null) {
            val dur = plan.totalMs
            val mc = Clip(assetId = music.id, trackId = musicTrack, startMs = 0, inMs = plan.musicInMs, outMs = (plan.musicInMs + dur).coerceAtMost(music.durationMs.coerceAtLeast(plan.musicInMs + 1000)),
                volume = style.musicVol, fadeOutMs = 900, audioOnly = music.type == MediaType.VIDEO)
            q = q.copy(clips = q.clips + mc, beatAssetId = music.id, ducking = style.origVol > 0.4f)
        } else q = q.copy(beatAssetId = null)
        return Ops.relayoutMain(q)
    }

    // ---------------- subtitles ----------------
    fun generateSubtitles(language: String?) {
        val p = _project.value ?: return
        val key = settings.value.openAiKey
        if (key.isBlank()) return toast("ใส่ OpenAI API Key ในหน้าตั้งค่าก่อน (ดูค่าใช้จ่ายในหน้าคำบรรยาย)")
        job?.cancel()
        job = viewModelScope.launch {
            try {
                val clips = p.clips.filter { it.trackId == p.mainTrackId && !it.muted && p.asset(it.assetId)?.hasAudio == true }.sortedBy { it.startMs }
                if (clips.isEmpty()) { toast("ไม่มีคลิปที่มีเสียงพูด"); return@launch }
                val out = ArrayList<TextItem>()
                val tr = p.tracks.lastOrNull { it.kind == TrackKind.TEXT }?.id ?: return@launch
                clips.forEachIndexed { i, c ->
                    val a = p.asset(c.assetId)!!
                    busy.value = Busy("กำลังแปลงเสียงเป็นข้อความ (${i + 1}/${clips.size})", i / clips.size.toFloat())
                    val lines = WhisperClient.transcribe(ctx, a.uri, c.inMs, c.outMs, language, key) { }
                    lines.forEach { l ->
                        val st = c.startMs + (l.startMs / c.speed).toLong(); val en = (c.startMs + (l.endMs / c.speed).toLong()).coerceAtMost(c.endMs())
                        if (en - st < 150) return@forEach
                        out.add(SubStyles.apply(SubStyles.all[0].id, TextItem(trackId = tr, text = l.text, startMs = st, durMs = en - st, subtitle = true,
                            words = l.words.map { w -> WordTiming(w.text, c.startMs + (w.startMs / c.speed).toLong(), c.startMs + (w.endMs / c.speed).toLong()) })))
                    }
                }
                busy.value = null
                edit { cur -> cur.copy(texts = cur.texts.filterNot { it.subtitle } + out) }
                toast("สร้างคำบรรยาย ${out.size} บรรทัดแล้ว ตรวจและแก้คำผิดได้")
            } catch (e: CancellationException) { busy.value = null }
            catch (e: Exception) { busy.value = null; toast(e.message ?: "สร้างคำบรรยายไม่สำเร็จ") }
        }
    }

    fun importSrt(text: String) {
        val p = _project.value ?: return
        val tr = p.tracks.lastOrNull { it.kind == TrackKind.TEXT }?.id ?: return
        val lines = Srt.parse(text)
        if (lines.isEmpty()) return toast("อ่านไฟล์ SRT ไม่ได้")
        edit { cur -> cur.copy(texts = cur.texts.filterNot { it.subtitle } + lines.map { SubStyles.apply(SubStyles.all[0].id, TextItem(trackId = tr, text = it.text, startMs = it.startMs, durMs = it.endMs - it.startMs, subtitle = true)) }) }
    }

    fun applySubtitleStyle(styleId: String) = edit { p -> p.copy(texts = p.texts.map { if (it.subtitle) SubStyles.apply(styleId, it) else it }) }
    fun addSubtitleLine() {
        val p = _project.value ?: return
        val tr = p.tracks.lastOrNull { it.kind == TrackKind.TEXT }?.id ?: return
        val t = SubStyles.apply(SubStyles.all[0].id, TextItem(trackId = tr, text = "ข้อความใหม่", startMs = playhead.value, durMs = 2000, subtitle = true))
        edit { Ops.resolveOverlap(it.copy(texts = it.texts + t), Sel(ItemKind.TEXT, t.id)) }
    }

    fun exportSrt() = viewModelScope.launch {
        val p = _project.value ?: return@launch
        val lines = p.texts.filter { it.subtitle }.map { SubLine(it.startMs, it.startMs + it.durMs, it.text, it.words) }
        if (lines.isEmpty()) return@launch toast("ยังไม่มีคำบรรยาย")
        try { toast(Saver.saveText(ctx, Srt.format(lines), "${p.name}.srt", "application/x-subrip", settings.value.saveFolderUri)) } catch (e: Exception) { toast("บันทึก SRT ไม่ได้: ${e.message}") }
    }

    fun cancelJob() { job?.cancel(); busy.value = null }

    // ---------------- export ----------------
    fun startExport(s: ExportSettings) {
        val p = _project.value ?: return
        val an = analyses.value
        exporter.start(p, timelineBeats(p, an), buildDuck(p, an), s) { file, settings, expectedMs ->
            val err = exporter.verify(file, expectedMs)
            if (err != null) { exporter.setFailed("ส่งออกเสร็จแต่ไฟล์ผิดปกติ: $err"); return@start }
            val uri = Saver.saveVideo(ctx, file, settings.name, settings.folderUri)
            file.delete()
            exporter.setDone(uri, "บันทึกแล้ว และตรวจสอบแล้วว่าเปิดเล่นได้")
        }
    }

    // ---------------- preview ----------------
    private var player: CompositionPlayer? = null
    private var previewJob: Job? = null
    val previewPlayer: Player? get() = player

    fun ensurePlayer(): Player {
        player?.let { return it }
        val pl = CompositionPlayer.Builder(ctx).build()
        pl.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) { playing.value = isPlaying }
            override fun onPlaybackStateChanged(state: Int) { if (state == Player.STATE_ENDED) { playing.value = false } }
            override fun onPlayerError(error: PlaybackException) { previewError.value = "พรีวิวผิดพลาด (${error.errorCodeName}) ลองลดคุณภาพ Preview ในตั้งค่า"; playing.value = false }
        })
        player = pl; return pl
    }

    /** Rebuilds the preview composition shortly after the project stops changing. */
    fun refreshPreview() {
        val p = _project.value ?: return
        previewJob?.cancel()
        previewJob = viewModelScope.launch {
            delay(350)
            val pl = ensurePlayer()
            val an = analyses.value
            val built = try { CompositionBuilder.build(ctx, p, timelineBeats(p, an), buildDuck(p, an), settings.value.previewHeight, null) }
            catch (e: Exception) { previewError.value = "สร้างพรีวิวไม่ได้: ${e.message}"; null }
            if (built == null) { pl.pause(); return@launch }
            val wasPlaying = pl.isPlaying
            previewError.value = null
            pl.setComposition(built.composition)
            pl.prepare()
            pl.seekTo(min(playhead.value, max(0L, built.totalMs - 1)))
            if (wasPlaying) pl.play()
        }
    }

    fun seek(ms: Long) { playhead.value = ms.coerceAtLeast(0); player?.seekTo(ms.coerceAtLeast(0)) }
    fun togglePlay() {
        val pl = player ?: return
        val end = _project.value?.videoEndMs() ?: 0L
        if (pl.isPlaying) pl.pause() else { if (playhead.value >= end - 50) seek(0); pl.play() }
    }
    fun pollPlayhead() { player?.let { if (it.isPlaying) playhead.value = it.currentPosition } }
    fun pause() { player?.pause() }

    override fun onCleared() {
        runCatching { recorder?.release() }
        player?.release(); player = null
        super.onCleared()
    }
}
