@file:OptIn(ExperimentalLayoutApi::class)

package com.sinzer.autoedit.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sinzer.autoedit.ai.SubStyles
import com.sinzer.autoedit.ai.WhisperClient
import com.sinzer.autoedit.catalog.*
import com.sinzer.autoedit.model.*
import com.sinzer.autoedit.vm.MainVM
import kotlin.math.abs
import kotlin.math.ln
import kotlin.math.pow

// ------------------------------------------------------------------ EFFECTS
@Composable
fun FxPanel(vm: MainVM, p: Project, sel: Sel?) {
    var cat by remember { mutableIntStateOf(0) }
    var q by remember { mutableStateOf("") }
    var toTrack by remember { mutableStateOf(false) }
    val clip = p.clipOf(sel)
    val item = sel?.takeIf { it.kind == ItemKind.FX }?.let { s -> p.fxItems.firstOrNull { it.id == s.id } }
    val cats = listOf("ทั้งหมด") + FxCatalog.categories
    val list = FxCatalog.all.filter { (cat == 0 || it.cat == cats[cat]) && (q.isBlank() || it.nameTh.contains(q, true) || it.id.contains(q, true)) }
    PanelScroll {
        Row(verticalAlignment = Alignment.CenterVertically) { SectionTitle("เอฟเฟกต์ (${FxCatalog.all.size} แบบ)", "effects") }
        OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth(), label = { Text("ค้นหาเอฟเฟกต์") }, singleLine = true)
        ChipRow(cats, cat) { cat = it }
        ChipRow(listOf("ใส่กับคลิปที่เลือก", "ใส่เป็นช่วงบนแทร็กเอฟเฟกต์"), if (toTrack) 1 else 0) { toTrack = it == 1 }
        if (!toTrack && clip == null) Text("เลือกคลิปบนไทม์ไลน์ก่อน หรือสลับเป็นแทร็กเอฟเฟกต์", fontSize = 12.sp, color = Danger)
        Column(Modifier.heightIn(max = 150.dp).verticalScroll(rememberScrollState())) {
            FlowRow {
                list.forEach { f -> SmallChip((if (f.beat) "♪ " else "") + f.nameTh, false) { if (toTrack) vm.addFxItem(f.id) else clip?.let { vm.addClipFx(it.id, f.id) } ?: vm.toast("เลือกคลิปก่อน") } }
            }
        }
        Text("♪ = ตอบสนองต่อจังหวะเพลงโดยอัตโนมัติ · เห็นผลทันทีในพรีวิว กด Undo เพื่อย้อนกลับ", fontSize = 11.sp, color = TextDim)
        if (clip != null && clip.fx.isNotEmpty()) {
            SectionTitle("เอฟเฟกต์บนคลิปนี้ (เรียงจากบนลงล่าง)")
            clip.fx.forEachIndexed { i, fx ->
                FxRow(FxCatalog.get(fx.presetId)?.nameTh ?: fx.presetId, fx, { f -> vm.updateClipFx(clip.id, fx.id, f) }, { vm.removeClipFx(clip.id, fx.id) },
                    { d -> vm.moveClipFx(clip.id, fx.id, d) }, i > 0, i < clip.fx.size - 1, vm)
            }
        }
        if (item != null) {
            SectionTitle("เอฟเฟกต์บนแทร็ก (ลากจุดจับบนไทม์ไลน์เพื่อปรับช่วงเวลา)")
            FxRow(FxCatalog.get(item.fx.presetId)?.nameTh ?: "", item.fx, { f -> vm.updateFxItem(item.id) { it.copy(fx = f(it.fx)) } }, { vm.deleteSel() }, {}, false, false, vm)
        }
    }
}

@Composable
private fun FxRow(name: String, fx: FxInstance, upd: ((FxInstance) -> FxInstance) -> Unit, del: () -> Unit, move: (Int) -> Unit, canUp: Boolean, canDown: Boolean, vm: MainVM) {
    Column(Modifier.fillMaxWidth().padding(vertical = 3.dp).clip(RoundedCornerShape(10.dp)).background(Surface2).padding(8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Switch(fx.enabled, { v -> upd { it.copy(enabled = v) } }); Spacer(Modifier.width(8.dp))
            Text(name, Modifier.weight(1f), fontSize = 14.sp)
            if (canUp) TextButton(onClick = { move(-1) }) { Text("▲") }
            if (canDown) TextButton(onClick = { move(1) }) { Text("▼") }
            TextButton(onClick = del) { Text("ลบ", color = Danger) }
        }
        LabeledSlider("ความเข้ม", fx.intensity, 0f..1.5f, "${(fx.intensity * 100).toInt()}%", { v -> vm.beginGestureOnce(); upd { it.copy(intensity = v) } }, { vm.endGesture() })
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("ซิงก์กับบีต", fontSize = 13.sp); HelpIcon("fx_beat"); Spacer(Modifier.weight(1f)); Switch(fx.beatSync, { v -> upd { it.copy(beatSync = v) } })
        }
    }
}

// ------------------------------------------------------------------ TRANSITIONS
@Composable
fun TransPanel(vm: MainVM, p: Project, sel: Sel?) {
    var cat by remember { mutableIntStateOf(0) }
    val clip = p.clipOf(sel)
    val main = p.clips.filter { it.trackId == p.mainTrackId }.sortedBy { it.startMs }
    val isLast = clip != null && main.lastOrNull()?.id == clip.id
    val cats = listOf("ทั้งหมด") + TransitionCatalog.categories
    val list = TransitionCatalog.all.filter { cat == 0 || it.cat == cats[cat] }
    PanelScroll {
        SectionTitle("ทรานซิชัน (${TransitionCatalog.all.size} แบบ)", "transition")
        if (clip == null || clip.trackId != p.mainTrackId) { Text("เลือกคลิปบนแทร็กวิดีโอหลัก ทรานซิชันจะอยู่ที่ท้ายคลิปนั้น (จุดต่อกับคลิปถัดไป)", fontSize = 12.sp, color = TextDim) }
        else if (isLast) Text("นี่คือคลิปสุดท้าย: ไม่มีคลิปถัดไปให้เปลี่ยนฉาก", fontSize = 12.sp, color = Danger)
        ChipRow(cats, cat) { cat = it }
        val cur = clip?.transition
        Column(Modifier.heightIn(max = 150.dp).verticalScroll(rememberScrollState())) {
            FlowRow {
                SmallChip("ไม่มี", cur == null) { clip?.let { vm.setTransition(it.id, null) } }
                list.forEach { t -> SmallChip(t.nameTh, cur?.presetId == t.id) {
                    if (clip != null && clip.trackId == p.mainTrackId && !isLast) vm.setTransition(clip.id, TransitionRef(t.id, cur?.durMs ?: 400, cur?.intensity ?: 1f, cur?.dir ?: 0)) else vm.toast("เลือกคลิปที่ไม่ใช่คลิปสุดท้ายบนแทร็กหลัก")
                } }
            }
        }
        if (clip != null && cur != null) {
            LabeledSlider("ระยะเวลา", cur.durMs / 1000f, 0.1f..2f, "%.2f วิ".format(cur.durMs / 1000f), { v -> vm.beginGestureOnce(); vm.setTransition(clip.id, cur.copy(durMs = (v * 1000).toLong())) }, { vm.endGesture() })
            LabeledSlider("ความแรง", cur.intensity, 0.2f..1.5f, "${(cur.intensity * 100).toInt()}%", { v -> vm.beginGestureOnce(); vm.setTransition(clip.id, cur.copy(intensity = v)) }, { vm.endGesture() })
            ChipRow(listOf("ทิศทางปกติ", "ทิศทางกลับ"), cur.dir) { d -> vm.setTransition(clip.id, cur.copy(dir = d)) }
            OutlinedButton(onClick = { vm.setTransitionAll(cur) }) { Text("ใช้แบบนี้กับทุกจุดตัด") }
        }
        Text("ทรานซิชันเรนเดอร์เป็นวิดีโอจริงทั้งในพรีวิวและ Export · แบบข้ามเฟรมทับซ้อนสองคลิป (cross-dissolve จริง) ยังไม่มีในเวอร์ชันนี้", fontSize = 11.sp, color = TextDim)
    }
}

// ------------------------------------------------------------------ SPEED
private val VELOCITY = listOf(
    "มอนทาจ" to listOf(0f to 1f, .3f to .3f, .5f to .3f, .7f to 2.5f, 1f to 1f),
    "ฮีโร่ไทม์" to listOf(0f to 1f, .25f to .2f, .6f to .2f, .85f to 3f, 1f to 1f),
    "บูลเล็ตไทม์" to listOf(0f to 1f, .4f to .15f, .6f to .15f, 1f to 1f),
    "จัมป์คัต" to listOf(0f to 3f, .2f to 3f, .3f to 1f, 1f to 1f),
    "แฟลชอิน" to listOf(0f to .2f, .3f to .2f, .35f to 3f, 1f to 1f),
    "แฟลชเอาต์" to listOf(0f to 1f, .65f to 1f, .7f to 3f, 1f to 3f),
    "ช้าตรงกลาง" to listOf(0f to 1f, .4f to .4f, .6f to .4f, 1f to 1f),
    "พัลส์" to listOf(0f to 1f, .25f to 2.5f, .5f to .4f, .75f to 2.5f, 1f to 1f),
    "เร่งขึ้น" to listOf(0f to .5f, 1f to 3f),
    "ชะลอลง" to listOf(0f to 3f, 1f to .5f),
    "นุ่มนวล" to listOf(0f to 1f, .5f to 2f, 1f to 1f),
    "ดับเบิลพัลส์" to listOf(0f to .5f, .2f to 2.5f, .4f to .5f, .6f to 2.5f, .8f to .5f, 1f to 1f),
)

@Composable
fun SpeedPanel(vm: MainVM, p: Project, sel: Sel?) {
    val clip = p.clipOf(sel)
    PanelScroll {
        SectionTitle("ความเร็ว / Velocity", "speed")
        if (clip == null) { Text("เลือกคลิปบนไทม์ไลน์", fontSize = 12.sp, color = TextDim); return@PanelScroll }
        val a = p.asset(clip.assetId)
        if (a?.type == MediaType.IMAGE) { Text("รูปภาพไม่มีความเร็ว: ปรับความยาวด้วยจุดจับบนไทม์ไลน์", fontSize = 12.sp, color = TextDim); return@PanelScroll }
        if (clip.speedCurve.isEmpty()) {
            LabeledSlider("ความเร็วคงที่", clip.speed, 0.1f..8f, "×%.2f".format(clip.speed), { v -> vm.beginGestureOnce(); vm.setSpeed(clip.id, v) }, { vm.endGesture() })
            ChipRow(listOf("0.25×", "0.5×", "1×", "1.5×", "2×", "3×", "4×"), -1) { i -> vm.setSpeed(clip.id, listOf(.25f, .5f, 1f, 1.5f, 2f, 3f, 4f)[i]) }
        } else Text("กำลังใช้กราฟความเร็ว (Speed Ramp) · ความยาวหลังปรับ ${clipDurMs(clip) / 1000f} วิ", fontSize = 12.sp)
        SectionTitle("Velocity Preset (${VELOCITY.size} แบบ)")
        Column(Modifier.heightIn(max = 90.dp).verticalScroll(rememberScrollState())) {
            FlowRow { VELOCITY.forEach { (n, pts) -> SmallChip(n, false) { vm.setSpeedCurve(clip.id, pts.map { SpeedPoint(it.first, it.second) }) } } }
        }
        SectionTitle("กราฟความเร็ว", "speed_curve")
        SpeedGraph(vm, clip)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            OutlinedButton(onClick = { vm.setSpeed(clip.id, 1f) }) { Text("รีเซ็ต") }
            OutlinedButton(onClick = { vm.freezeFrame() }) { Text("❄ Freeze Frame") }
            HelpIcon("freeze")
        }
        Text("ช้าลง/เร็วขึ้นรักษาระดับเสียงเดิม · Preview ก่อนใช้ได้ทันที · ไม่มี Reverse และ Optical-flow slow-motion ในเวอร์ชันนี้ (Media3 ยังไม่รองรับ) ภาพช้าใช้การทำซ้ำเฟรม", fontSize = 11.sp, color = TextDim)
    }
}

@Composable
private fun SpeedGraph(vm: MainVM, clip: Clip) {
    val c by rememberUpdatedState(clip)
    var selIdx by remember { mutableIntStateOf(-1) }
    val lo = ln(0.1f) / ln(2f); val hi = 3f
    fun pts(): List<SpeedPoint> = c.speedCurve.ifEmpty { listOf(SpeedPoint(0f, c.speed), SpeedPoint(1f, c.speed)) }
    Canvas(Modifier.fillMaxWidth().height(130.dp).clip(RoundedCornerShape(10.dp)).background(Color(0xFF0B1128))
        .pointerInput(Unit) {
            detectTapGestures { off ->
                val w = size.width.toFloat(); val h = size.height.toFloat()
                val list = pts()
                val near = list.indexOfFirst { abs(it.pos * w - off.x) < 36f && abs(yOf(it.speed, lo, hi, h) - off.y) < 36f }
                if (near >= 0) selIdx = near
                else {
                    val pos = (off.x / w).coerceIn(0.02f, 0.98f)
                    val sp = 2f.pow(lo + (1f - off.y / h) * (hi - lo))
                    vm.setSpeedCurve(c.id, list + SpeedPoint(pos, sp.coerceIn(0.1f, 8f)))
                    selIdx = list.size
                }
            }
        }
        .pointerInput(Unit) {
            detectDragGestures(
                onDragStart = { off ->
                    val w = size.width.toFloat(); val h = size.height.toFloat()
                    selIdx = pts().indexOfFirst { abs(it.pos * w - off.x) < 40f && abs(yOf(it.speed, lo, hi, h) - off.y) < 40f }
                    if (selIdx >= 0) vm.beginGesture()
                },
                onDragEnd = { vm.endGesture() }, onDragCancel = { vm.endGesture() },
            ) { change, _ ->
                val i = selIdx
                if (i >= 0) {
                    val w = size.width.toFloat(); val h = size.height.toFloat()
                    val list = pts().sortedBy { it.pos }
                    val sp = 2f.pow(lo + (1f - change.position.y / h).coerceIn(0f, 1f) * (hi - lo)).coerceIn(0.1f, 8f)
                    val pos = if (i == 0) 0f else if (i == list.size - 1) 1f else (change.position.x / w).coerceIn(list[i - 1].pos + 0.02f, list[i + 1].pos - 0.02f)
                    vm.setSpeedCurve(c.id, list.mapIndexed { j, pt -> if (j == i) SpeedPoint(pos, sp) else pt })
                    change.consume()
                }
            }
        }) {
        val w = size.width; val h = size.height
        val one = yOf(1f, lo, hi, h)
        drawLine(Color(0xFF3A456E), Offset(0f, one), Offset(w, one), 2f)
        listOf(.25f, .5f, 2f, 4f).forEach { drawLine(Color(0xFF1E2750), Offset(0f, yOf(it, lo, hi, h)), Offset(w, yOf(it, lo, hi, h)), 1f) }
        val list = pts().sortedBy { it.pos }
        val path = Path()
        for (i in 0..60) { val pos = i / 60f; val sp = speedAt(c.copy(speedCurve = list), pos); val x = pos * w; val y = yOf(sp, lo, hi, h); if (i == 0) path.moveTo(x, y) else path.lineTo(x, y) }
        drawPath(path, NeonBlue, style = Stroke(4f))
        list.forEachIndexed { i, pt -> drawCircle(if (i == selIdx) Color.White else NeonPurple, 14f, Offset(pt.pos * w, yOf(pt.speed, lo, hi, h))) }
    }
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text("แตะพื้นที่ว่างเพื่อเพิ่มจุด · ลากจุดเพื่อปรับ · เส้นขาว = ความเร็วปกติ", fontSize = 11.sp, color = TextDim, modifier = Modifier.weight(1f))
        TextButton(enabled = selIdx > 0 && selIdx < pts().size - 1, onClick = { vm.setSpeedCurve(c.id, pts().sortedBy { it.pos }.filterIndexed { j, _ -> j != selIdx }); selIdx = -1 }) { Text("ลบจุด") }
    }
}
private fun yOf(speed: Float, lo: Float, hi: Float, h: Float): Float = h * (1f - ((ln(speed) / ln(2f)) - lo) / (hi - lo))

// ------------------------------------------------------------------ COLOR
@Composable
fun ColorPanel(vm: MainVM, p: Project, sel: Sel?) {
    val clip = p.clipOf(sel)
    PanelScroll {
        SectionTitle("ปรับสี (Color Grading)", "color")
        if (clip == null) { Text("เลือกคลิปบนไทม์ไลน์", fontSize = 12.sp, color = TextDim); return@PanelScroll }
        Text("พรีเซ็ต ${ColorPresets.all.size} แบบ", fontSize = 12.sp, color = TextDim)
        Column(Modifier.heightIn(max = 110.dp).verticalScroll(rememberScrollState())) {
            FlowRow { ColorPresets.all.forEach { c -> SmallChip(c.nameTh, clip.colorPreset == c.id || (c.id == "c_neutral" && clip.colorPreset == null && clip.color.isNeutral())) { vm.applyColorPreset(clip.id, c.id) } } }
        }
        val a = clip.color
        val up = { f: (ColorAdj) -> ColorAdj -> vm.beginGestureOnce(); vm.updateClip(clip.id) { it.copy(color = f(it.color), colorPreset = null) } }
        val done = { vm.endGesture() }
        LabeledSlider("Exposure", a.exposure, -2f..2f, "%.2f".format(a.exposure), { v -> up { it.copy(exposure = v) } }, done)
        LabeledSlider("Brightness", a.brightness, -.5f..0.5f, "%.2f".format(a.brightness), { v -> up { it.copy(brightness = v) } }, done)
        LabeledSlider("Contrast", a.contrast, -.8f..1f, "%.2f".format(a.contrast), { v -> up { it.copy(contrast = v) } }, done)
        LabeledSlider("Saturation", a.saturation, -1f..1f, "%.2f".format(a.saturation), { v -> up { it.copy(saturation = v) } }, done)
        LabeledSlider("Temperature", a.temperature, -1f..1f, "%.2f".format(a.temperature), { v -> up { it.copy(temperature = v) } }, done)
        LabeledSlider("Tint", a.tint, -1f..1f, "%.2f".format(a.tint), { v -> up { it.copy(tint = v) } }, done)
        LabeledSlider("Highlights", a.highlights, -1f..1f, "%.2f".format(a.highlights), { v -> up { it.copy(highlights = v) } }, done)
        LabeledSlider("Shadows", a.shadows, -1f..1f, "%.2f".format(a.shadows), { v -> up { it.copy(shadows = v) } }, done)
        LabeledSlider("Whites", a.whites, -1f..1f, "%.2f".format(a.whites), { v -> up { it.copy(whites = v) } }, done)
        LabeledSlider("Blacks", a.blacks, -1f..1f, "%.2f".format(a.blacks), { v -> up { it.copy(blacks = v) } }, done)
        LabeledSlider("Hue", a.hue, -180f..180f, "%.0f°".format(a.hue), { v -> up { it.copy(hue = v) } }, done)
        LabeledSlider("Fade", a.fade, 0f..1f, "%.2f".format(a.fade), { v -> up { it.copy(fade = v) } }, done)
        LabeledSlider("Vignette", a.vignette, 0f..1f, "%.2f".format(a.vignette), { v -> up { it.copy(vignette = v) } }, done)
        LabeledSlider("Grain", a.grain, 0f..0.5f, "%.2f".format(a.grain), { v -> up { it.copy(grain = v) } }, done)
        LabeledSlider("Sharpen", a.sharpen, 0f..1f, "%.2f".format(a.sharpen), { v -> up { it.copy(sharpen = v) } }, done)
        OutlinedButton(onClick = { vm.applyColorPreset(clip.id, "c_neutral") }) { Text("รีเซ็ตสี") }
        Text("เวอร์ชันนี้ยังไม่มี Curves และการนำเข้า LUT (.cube)", fontSize = 11.sp, color = TextDim)
    }
}

// ------------------------------------------------------------------ KEYFRAMES
private val MOTIONS: List<Pair<String, (Long) -> List<KfTrack>>> = listOf(
    "ซูมเข้าช้า" to { d -> listOf(KfTrack(Prop.SCALE, listOf(Keyframe(0, 1f, Ease.IN_OUT), Keyframe(d, 1.3f)))) },
    "ซูมออกช้า" to { d -> listOf(KfTrack(Prop.SCALE, listOf(Keyframe(0, 1.3f, Ease.IN_OUT), Keyframe(d, 1f)))) },
    "Ken Burns" to { d -> listOf(KfTrack(Prop.SCALE, listOf(Keyframe(0, 1f, Ease.IN_OUT), Keyframe(d, 1.25f))), KfTrack(Prop.X, listOf(Keyframe(0, 0f, Ease.IN_OUT), Keyframe(d, -.05f)))) },
    "ป๊อป" to { _ -> listOf(KfTrack(Prop.SCALE, listOf(Keyframe(0, .6f, Ease.OUT), Keyframe(200, 1.1f, Ease.IN_OUT), Keyframe(350, 1f)))) },
    "สั่น" to { _ -> listOf(KfTrack(Prop.X, listOf(Keyframe(0, 0f), Keyframe(80, .015f), Keyframe(160, -.015f), Keyframe(240, .01f), Keyframe(320, 0f)))) },
    "เฟดเข้า" to { _ -> listOf(KfTrack(Prop.OPACITY, listOf(Keyframe(0, 0f), Keyframe(500, 1f)))) },
    "เฟดออก" to { d -> listOf(KfTrack(Prop.OPACITY, listOf(Keyframe((d - 500).coerceAtLeast(0), 1f), Keyframe(d, 0f)))) },
    "สไลด์เข้าจากซ้าย" to { _ -> listOf(KfTrack(Prop.X, listOf(Keyframe(0, -1f, Ease.OUT), Keyframe(400, 0f)))) },
    "หมุนเข้า" to { _ -> listOf(KfTrack(Prop.ROT, listOf(Keyframe(0, 180f, Ease.OUT), Keyframe(500, 0f))), KfTrack(Prop.SCALE, listOf(Keyframe(0, 0f, Ease.OUT), Keyframe(500, 1f)))) },
)

@Composable
fun KeyframePanel(vm: MainVM, p: Project, sel: Sel?, playhead: Long) {
    PanelScroll {
        SectionTitle("Keyframe", "keyframe")
        if (sel == null || sel.kind == ItemKind.FX) { Text("เลือกคลิป ข้อความ หรือสติ๊กเกอร์บนไทม์ไลน์", fontSize = 12.sp, color = TextDim); return@PanelScroll }
        val sp = Ops.span(p, sel) ?: return@PanelScroll
        val keys: List<KfTrack>; val base: (String) -> Float; val clip = p.clipOf(sel)
        when (sel.kind) {
            ItemKind.CLIP -> { val c = clip!!; keys = c.keyframes; base = { pr -> when (pr) { Prop.X -> c.tx; Prop.Y -> c.ty; Prop.SCALE -> c.scale; Prop.ROT -> c.rot; Prop.OPACITY -> c.opacity; Prop.VOLUME -> c.volume
                else -> if (pr.startsWith("col:")) colorBase(c.color, pr.removePrefix("col:")) else 1f } } }
            ItemKind.TEXT -> { val t = p.texts.first { it.id == sel.id }; keys = t.keyframes; base = { pr -> if (pr == Prop.SCALE || pr == Prop.OPACITY) 1f else 0f } }
            else -> { val t = p.stickers.first { it.id == sel.id }; keys = t.keyframes; base = { pr -> if (pr == Prop.SCALE || pr == Prop.OPACITY) 1f else 0f } }
        }
        val props: List<Pair<String, String>> = buildList {
            add(Prop.X to "ตำแหน่ง X"); add(Prop.Y to "ตำแหน่ง Y"); add(Prop.SCALE to "ขนาด"); add(Prop.ROT to "หมุน"); add(Prop.OPACITY to "Opacity")
            if (sel.kind == ItemKind.CLIP) { add(Prop.VOLUME to "ระดับเสียง")
                listOf("exposure", "contrast", "saturation", "temperature").forEach { add("col:$it" to "สี: $it") }
                clip?.fx?.forEach { add("fx:${it.id}" to "ความเข้ม: ${FxCatalog.get(it.presetId)?.nameTh}") } }
        }
        var pi by remember(sel) { mutableIntStateOf(0) }
        val prop = props[pi.coerceIn(0, props.size - 1)].first
        ChipRow(props.map { it.second }, pi) { pi = it }
        val local = (playhead - sp.start).coerceAtLeast(0)
        val track = keys.firstOrNull { it.prop == prop }
        val cur = if (track != null) evalKf(track.keys.sortedBy { it.tMs }, local, base(prop)) else base(prop)
        var v by remember(sel, prop, playhead, track?.keys?.size) { mutableFloatStateOf(cur) }
        val range = when { prop.startsWith("col:") -> -1f..1f; prop.startsWith("fx:") -> 0f..1.5f; else -> Prop.range(prop) }
        Text("เวลาในรายการ: ${fmtTime(local)} (เลื่อนเพลย์เฮดเพื่อเลือกตำแหน่ง)", fontSize = 12.sp, color = TextDim)
        LabeledSlider("ค่า ณ เพลย์เฮด", v, range, "%.2f".format(v), { v = it })
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            NeonButton("◆ ใส่/แก้ Keyframe") { vm.setKeyframe(sel, prop, v) }
        }
        if (track != null) track.keys.sortedBy { it.tMs }.forEach { k ->
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("◆ ${fmtTime(k.tMs)}  =  %.2f".format(k.v), Modifier.weight(1f), fontSize = 13.sp)
                TextButton(onClick = { vm.removeKeyframe(sel, prop, k.tMs) }) { Text("ลบ", color = Danger) }
            }
        }
        SectionTitle("Preset การเคลื่อนไหว")
        FlowRow {
            MOTIONS.forEach { (n, mk) -> SmallChip(n, false) {
                val set = mk(sp.end - sp.start)
                val merge = { old: List<KfTrack> -> old.filter { o -> set.none { it.prop == o.prop } } + set }
                when (sel.kind) { ItemKind.CLIP -> vm.updateClip(sel.id) { it.copy(keyframes = merge(it.keyframes)) }
                    ItemKind.TEXT -> vm.updateText(sel.id) { it.copy(keyframes = merge(it.keyframes)) }
                    else -> vm.updateSticker(sel.id) { it.copy(keyframes = merge(it.keyframes)) } }
            } }
        }
        Text("Keyframe ตำแหน่ง/ขนาด/หมุน/โปร่งใส/เสียง/สี/ความเข้มเอฟเฟกต์ เรนเดอร์จริงทั้งพรีวิวและ Export", fontSize = 11.sp, color = TextDim)
    }
}

private fun colorBase(c: ColorAdj, n: String) = when (n) { "exposure" -> c.exposure; "contrast" -> c.contrast; "saturation" -> c.saturation; "temperature" -> c.temperature; else -> 0f }

// ------------------------------------------------------------------ SUBTITLES
@Composable
fun SubtitlePanel(vm: MainVM, p: Project, hasKey: Boolean) {
    var lang by remember { mutableIntStateOf(0) }
    val srtPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) vm.viewModelScope_readText(u) { vm.importSrt(it) }
    }
    val subs = p.texts.filter { it.subtitle }.sortedBy { it.startMs }
    PanelScroll {
        SectionTitle("คำบรรยายอัตโนมัติ", "subtitle")
        Card(colors = CardDefaults.cardColors(containerColor = Surface2)) {
            Text("⚠ ${WhisperClient.PRICE_NOTE}", Modifier.padding(10.dp), fontSize = 12.sp)
        }
        if (!hasKey) Text("ต้องใส่ OpenAI API Key ในหน้า ตั้งค่า ก่อน (ไม่มีคีย์ ก็พิมพ์คำบรรยายเองหรือนำเข้า SRT ได้ฟรี)", fontSize = 12.sp, color = Danger)
        ChipRow(listOf("ไทย", "English", "ตรวจภาษาอัตโนมัติ"), lang) { lang = it }
        NeonButton("🎙 สร้างคำบรรยายจากเสียงพูด", Modifier.fillMaxWidth(), enabled = hasKey) { vm.generateSubtitles(listOf("th", "en", null)[lang]) }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            OutlinedButton(onClick = { vm.addSubtitleLine() }) { Text("＋ เพิ่มบรรทัด") }
            OutlinedButton(onClick = { srtPicker.launch(arrayOf("*/*")) }) { Text("นำเข้า SRT") }
            OutlinedButton(onClick = { vm.exportSrt() }) { Text("ส่งออก SRT") }
        }
        SectionTitle("สไตล์คำบรรยาย", "subtitle_style")
        ChipRow(SubStyles.all.map { it.nameTh }, -1) { vm.applySubtitleStyle(SubStyles.all[it].id) }
        Text("สไตล์ “คาราโอเกะ” ไฮไลต์ทีละคำตามเวลาพูดจริง (ต้องมีเวลาระดับคำจากการสร้างอัตโนมัติ) · “ป๊อปเหลือง” เน้นคำที่ยาวที่สุดของแต่ละบรรทัด", fontSize = 11.sp, color = TextDim)
        SectionTitle("บรรทัดคำบรรยาย (${subs.size})")
        subs.forEach { s ->
            Column(Modifier.fillMaxWidth().padding(vertical = 3.dp).clip(RoundedCornerShape(10.dp)).background(Surface2).padding(8.dp)) {
                OutlinedTextField(s.text, { v -> vm.updateText(s.id) { it.copy(text = v, words = emptyList()) } }, Modifier.fillMaxWidth(), textStyle = androidx.compose.ui.text.TextStyle(fontSize = 14.sp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("${fmtTime(s.startMs)} → ${fmtTime(s.startMs + s.durMs)}", fontSize = 11.sp, color = TextDim, modifier = Modifier.weight(1f))
                    TextButton(onClick = { vm.updateText(s.id) { it.copy(startMs = (it.startMs - 100).coerceAtLeast(0)) } }) { Text("เริ่ม −0.1") }
                    TextButton(onClick = { vm.updateText(s.id) { it.copy(startMs = it.startMs + 100, durMs = (it.durMs - 100).coerceAtLeast(200)) } }) { Text("+0.1") }
                    TextButton(onClick = { vm.updateText(s.id) { it.copy(durMs = (it.durMs - 100).coerceAtLeast(200)) } }) { Text("จบ −0.1") }
                    TextButton(onClick = { vm.updateText(s.id) { it.copy(durMs = it.durMs + 100) } }) { Text("+0.1") }
                    TextButton(onClick = { vm.edit { cur -> cur.copy(texts = cur.texts.filterNot { it.id == s.id }) } }) { Text("ลบ", color = Danger) }
                }
                SwitchRow("เน้นคำสำคัญ (คำที่ยาวที่สุด)", s.emphasis) { v -> vm.updateText(s.id) { it.copy(emphasis = v) } }
            }
        }
        Text("Export วิดีโอจะรวมคำบรรยายไว้ในภาพ (burn-in) อัตโนมัติ · เปลี่ยนฟอนต์/สีได้โดยแตะบรรทัดบนไทม์ไลน์แล้วเปิดแท็บ “ข้อความ”", fontSize = 11.sp, color = TextDim)
    }
}
