package com.sinzer.autoedit.render

import android.content.Context
import android.graphics.*
import android.net.Uri
import android.util.LruCache
import androidx.media3.common.util.GlUtil
import androidx.media3.common.util.Size
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.OverlaySettings
import androidx.media3.effect.TextureOverlay
import com.sinzer.autoedit.audio.BeatMap
import com.sinzer.autoedit.catalog.*
import com.sinzer.autoedit.media.Thumbs
import com.sinzer.autoedit.model.*
import java.text.BreakIterator
import java.util.Locale
import kotlin.math.*

/** One textured quad for one frame. Coordinates are pixels of the output frame (origin top-left). */
class Sprite(val key: String, val make: () -> Bitmap, val cx: Float, val cy: Float, val sx: Float, val sy: Float, val rot: Float, val alpha: Float)

private class TUnit(val text: String, val line: Int, val x: Float, val w: Float, val blank: Boolean, val emph: Boolean)
private class TLayout(val units: List<TUnit>, val lineH: Float, val lineW: FloatArray, val lines: List<String>, val blockW: Float, val blockH: Float,
                      val whole: Boolean, val pad: Float, val basePaint: Paint)

private val RAINBOW = intArrayOf(0xFFFF4D4D.toInt(), 0xFFFFA94D.toInt(), 0xFFFFE14D.toInt(), 0xFF4DFF88.toInt(), 0xFF4DB8FF.toInt(), 0xFFB04DFF.toInt())

/**
 * Builds every text / sticker sprite visible at a given time. Static parts are rendered once into small bitmaps
 * (per glyph, per word, or one block for plain text); animation only changes position/scale/rotation/alpha of the quads,
 * which the GPU does per frame, so animated text does not upload a new texture per frame.
 */
class OverlayScene(
    private val ctx: Context, private val texts: List<TextItem>, private val stickers: List<StickerItem>,
    val outW: Int, val outH: Int, private val beat: BeatMap?,
) {
    private val short = min(outW, outH).toFloat()
    private val scale = short / 1080f
    private val layouts = HashMap<String, TLayout>()
    private val bitmaps = object : LruCache<String, Bitmap>(24 * 1024 * 1024) { override fun sizeOf(k: String, v: Bitmap) = v.byteCount }
    private var cacheT = Long.MIN_VALUE
    private var cache: List<Sprite> = emptyList()

    val slotCount: Int = computeSlots()

    private fun animsOf(t: TextItem) = t.anims.mapNotNull { r -> TextAnims.get(r.presetId)?.let { r to it } }
    private fun unitMode(t: TextItem): Gran {
        val a = animsOf(t)
        return when {
            a.any { it.second.gran == Gran.CHAR } -> Gran.CHAR
            a.any { it.second.gran == Gran.WORD || it.second.kind == TKind.KARAOKE } || (t.subtitle && t.emphasis) -> Gran.WORD
            else -> Gran.WHOLE
        }
    }

    private fun computeSlots(): Int {
        class Ev(val t: Long, val d: Int)
        val ev = ArrayList<Ev>()
        for (t in texts) {
            val a = animsOf(t)
            val units = when (unitMode(t)) { Gran.WHOLE -> 1; Gran.WORD -> max(1, t.text.split(Regex("\\s+")).size * 2); Gran.CHAR -> max(1, t.text.length) }
            val mult = 1 + (if (a.any { it.second.kind == TKind.RGB || it.second.kind == TKind.GLITCH }) 2 else 0) + (if (a.any { it.second.kind == TKind.KARAOKE }) 1 else 0)
            val n = units * mult + (if (t.bgColor != 0) 1 else 0)
            ev.add(Ev(t.startMs, n)); ev.add(Ev(t.startMs + t.durMs, -n))
        }
        for (s in stickers) { ev.add(Ev(s.startMs, 1)); ev.add(Ev(s.startMs + s.durMs, -1)) }
        var cur = 0; var best = 0
        ev.sortedWith(compareBy({ it.t }, { it.d })).forEach { cur += it.d; best = max(best, cur) }
        return best.coerceIn(0, 160)
    }

    // ------------------------------------------------------------------ per-frame
    fun sprites(tMs: Long): List<Sprite> {
        if (tMs == cacheT) return cache
        val out = ArrayList<Sprite>()
        for (t in texts) if (tMs >= t.startMs && tMs < t.startMs + t.durMs) textSprites(t, tMs, out)
        for (s in stickers) if (tMs >= s.startMs && tMs < s.startMs + s.durMs) stickerSprite(s, tMs, out)
        cacheT = tMs; cache = out
        return out
    }

    private fun stickerSprite(s: StickerItem, tMs: Long, out: MutableList<Sprite>) {
        val l = tMs - s.startMs; val k = s.keyframes
        val x = (s.x + k.value(Prop.X, l, 0f)) * outW; val y = (s.y - k.value(Prop.Y, l, 0f)) * outH
        val sc = s.scale * k.value(Prop.SCALE, l, 1f); val rot = s.rot + k.value(Prop.ROT, l, 0f)
        val a = s.opacity * k.value(Prop.OPACITY, l, 1f)
        val key = "st|${s.emoji}|${s.imageUri}|$outH"
        out.add(Sprite(key, { stickerBitmap(s) }, x, y, sc, sc, rot, a))
    }

    private fun stickerBitmap(s: StickerItem): Bitmap {
        val size = (short * 0.22f).toInt().coerceAtLeast(32)
        if (s.imageUri != null) {
            val b = Thumbs.decodeImage(ctx, Uri.parse(s.imageUri), size) ?: return Bitmap.createBitmap(2, 2, Bitmap.Config.ARGB_8888)
            return b
        }
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = size * 0.8f }
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val fm = p.fontMetrics
        Canvas(bmp).drawText(s.emoji ?: "⭐", (size - p.measureText(s.emoji ?: "⭐")) / 2f, size / 2f - (fm.ascent + fm.descent) / 2f, p)
        return bmp
    }

    private fun styleKey(t: TextItem): Int =
        t.copy(id = "", trackId = "", startMs = 0, durMs = 0, x = 0f, y = 0f, rot = 0f, scale = 1f, opacity = 1f, anims = emptyList(), words = emptyList(), keyframes = emptyList()).hashCode() * 31 + outH

    private fun layoutOf(t: TextItem): TLayout = layouts.getOrPut(t.id + "|" + styleKey(t) + "|" + unitMode(t)) { buildLayout(t) }

    private fun makePaint(t: TextItem): Paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.SUBPIXEL_TEXT_FLAG).apply {
        typeface = FontManager.typeface(ctx, t.fontId)
        textSize = t.size * scale
        isFakeBoldText = t.bold; if (t.italic) textSkewX = -0.2f
        letterSpacing = t.letterSpacing
    }

    private fun buildLayout(t: TextItem): TLayout {
        val paint = makePaint(t)
        val lines = t.text.split("\n")
        val fm = paint.fontMetrics
        val lineH = (fm.descent - fm.ascent) * 1.12f
        val lineW = FloatArray(lines.size) { paint.measureText(lines[it]) }
        val bw = (lineW.maxOrNull() ?: 1f).coerceAtLeast(1f)
        val pad = (t.strokeW * scale + t.glow * 6f * scale + t.shadow * 4f * scale + t.size * scale * 0.18f + 4f)
        val mode = unitMode(t)
        val units = ArrayList<TUnit>()
        if (mode == Gran.WHOLE) units.add(TUnit(t.text, 0, 0f, bw, false, false))
        else {
            val longest = if (t.emphasis) t.text.split(Regex("\\s+")).maxByOrNull { it.length } else null
            lines.forEachIndexed { li, line ->
                val bi = if (mode == Gran.CHAR) BreakIterator.getCharacterInstance(Locale("th")) else BreakIterator.getWordInstance(Locale("th"))
                bi.setText(line)
                var s = bi.first(); var e = bi.next()
                while (e != BreakIterator.DONE) {
                    val seg = line.substring(s, e)
                    val x = paint.measureText(line, 0, s); val w = paint.measureText(line, s, e)
                    units.add(TUnit(seg, li, x, w, seg.isBlank(), longest != null && seg == longest))
                    s = e; e = bi.next()
                }
            }
        }
        return TLayout(units, lineH, lineW, lines, bw, lineH * lines.size, mode == Gran.WHOLE, pad, paint)
    }

    private fun alignOffset(t: TextItem, l: TLayout, line: Int): Float = when (t.align) { 0 -> 0f; 2 -> l.blockW - l.lineW[line]; else -> (l.blockW - l.lineW[line]) / 2f }

    private fun textSprites(t: TextItem, tMs: Long, out: MutableList<Sprite>) {
        val lay = layoutOf(t)
        val local = tMs - t.startMs; val kf = t.keyframes
        val bx = (t.x + kf.value(Prop.X, local, 0f)) * outW; val by = (t.y - kf.value(Prop.Y, local, 0f)) * outH
        val S = t.scale * kf.value(Prop.SCALE, local, 1f); val R = t.rot + kf.value(Prop.ROT, local, 0f)
        val A = t.opacity * kf.value(Prop.OPACITY, local, 1f)
        val rad = Math.toRadians(R.toDouble()); val cs = cos(rad).toFloat(); val sn = sin(rad).toFloat()
        val sk = styleKey(t)
        val anims = animsOf(t)
        val ctxA = AnimCtx(t.size * scale, local, t.durMs, { tt -> beat?.pulse(tt + t.startMs) ?: 0f }, 0f)
        val g = GlyphState()
        val words = t.words
        val activeUnits = lay.units.withIndex().filter { !it.value.blank }
        val nUnits = activeUnits.size

        fun place(ux: Float, uy: Float): Pair<Float, Float> {
            val x = ux * S; val y = uy * S
            return (bx + x * cs + y * sn) to (by - x * sn + y * cs)
        }

        if (t.bgColor != 0) {
            val w = lay.blockW + lay.pad; val h = lay.blockH + lay.pad * 0.5f
            val (px, py) = place(0f, 0f)
            out.add(Sprite("bg|$sk", { bgBitmap(t, w, h) }, px, py, S, S, R, A))
        }

        for ((ordinal, iv) in activeUnits.withIndex()) {
            val idx = iv.index; val u = iv.value
            g.reset()
            val ux = alignOffset(t, lay, u.line) + u.x + u.w / 2f - lay.blockW / 2f
            val uy = u.line * lay.lineH + lay.lineH / 2f - lay.blockH / 2f
            val nx = if (lay.blockW > 0) (u.x + u.w / 2f) / lay.blockW else 0.5f
            val ny = if (lay.lines.size > 1) (u.line + 0.5f) / lay.lines.size else 0.5f
            for ((ref, a) in anims) {
                var kara = 0f
                if (a.kind == TKind.KARAOKE) {
                    val w = if (words.size == nUnits) words[ordinal] else null
                    kara = if (w != null) ((local + t.startMs - w.startMs).toFloat() / max(1L, w.endMs - w.startMs)).coerceIn(0f, 1f)
                    else ((local - ordinal * t.durMs / max(1, nUnits)).toFloat() / max(1L, t.durMs / max(1, nUnits))).coerceIn(0f, 1f)
                }
                TextAnims.apply(ref, a, ordinal, nUnits, nx, ny, AnimCtx(ctxA.u, local, t.durMs, ctxA.pulse, kara), g)
            }
            val alpha = (g.alpha * A).coerceIn(0f, 1f)
            if (alpha <= 0.004f) continue
            val (px, py) = place(ux + g.dx, uy + g.dy)
            val sx = S * g.sx; val sy = S * g.sy; val rot = R + g.rot
            val variantMain = when { g.hue >= 0 -> "h${g.hue}"; u.emph -> "e"; else -> "n" }
            if (g.rgb > 0.5f) {
                val d = g.rgb * S
                out.add(Sprite("u|$sk|$idx|r", { unitBitmap(t, lay, u, 0xFFFF2D55.toInt(), true) }, px - d, py, sx, sy, rot, alpha * 0.6f))
                out.add(Sprite("u|$sk|$idx|c", { unitBitmap(t, lay, u, 0xFF2DE1FF.toInt(), true) }, px + d, py, sx, sy, rot, alpha * 0.6f))
            }
            val main = when { g.hue >= 0 -> RAINBOW[g.hue % 6]; u.emph -> t.highlightColor; else -> null }
            out.add(Sprite("u|$sk|$idx|$variantMain", { unitBitmap(t, lay, u, main, false) }, px, py, sx, sy, rot, alpha))
            if (g.hl > 0.01f) out.add(Sprite("u|$sk|$idx|hl", { unitBitmap(t, lay, u, t.highlightColor, false) }, px, py, sx, sy, rot, alpha * g.hl.coerceIn(0f, 1f)))
        }
    }

    // ------------------------------------------------------------------ bitmaps
    private fun bgBitmap(t: TextItem, w: Float, h: Float): Bitmap {
        val bmp = Bitmap.createBitmap(ceil(w).toInt().coerceAtLeast(2), ceil(h).toInt().coerceAtLeast(2), Bitmap.Config.ARGB_8888)
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = t.bgColor }
        Canvas(bmp).drawRoundRect(RectF(0f, 0f, w, h), t.size * scale * 0.25f, t.size * scale * 0.25f, p)
        return bmp
    }

    fun bitmapFor(sp: Sprite): Bitmap = bitmaps.get(sp.key) ?: sp.make().also { bitmaps.put(sp.key, it) }

    private fun unitBitmap(t: TextItem, lay: TLayout, u: TUnit, colorOverride: Int?, plain: Boolean): Bitmap {
        val pad = lay.pad
        val w = if (lay.whole) lay.blockW else u.w
        val h = if (lay.whole) lay.blockH else lay.lineH
        val bmp = Bitmap.createBitmap(ceil(w + pad * 2).toInt().coerceAtLeast(2), ceil(h + pad * 2).toInt().coerceAtLeast(2), Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val base = makePaint(t)
        val fm = base.fontMetrics
        val pieces: List<Triple<String, Float, Float>> =   // text, x, baseline
            if (lay.whole) lay.lines.mapIndexed { i, s -> Triple(s, pad + alignOffset(t, lay, i), pad + i * lay.lineH + (lay.lineH - (fm.descent - fm.ascent)) / 2f - fm.ascent) }
            else listOf(Triple(u.text, pad, pad + (lay.lineH - (fm.descent - fm.ascent)) / 2f - fm.ascent))
        for ((s, x, y) in pieces) {
            if (!plain && t.glow > 0f) {
                val p = makePaint(t).apply { color = t.glowColor; setShadowLayer(t.glow * 14f * scale, 0f, 0f, t.glowColor) }
                c.drawText(s, x, y, p); c.drawText(s, x, y, p)
            }
            if (!plain && t.shadow > 0f) {
                val p = makePaint(t).apply { color = t.shadowColor; setShadowLayer(t.shadow * 6f * scale, t.shadow * 4f * scale, t.shadow * 4f * scale, t.shadowColor) }
                c.drawText(s, x, y, p)
            }
            if (!plain && t.strokeW > 0f) {
                val p = makePaint(t).apply { style = Paint.Style.STROKE; strokeWidth = t.strokeW * scale * 2f; color = t.strokeColor; strokeJoin = Paint.Join.ROUND }
                c.drawText(s, x, y, p)
            }
            val fill = makePaint(t)
            if (colorOverride != null) fill.color = colorOverride
            else if (t.gradA != 0 && t.gradB != 0) {
                fill.shader = LinearGradient(0f, y + fm.ascent, 0f, y + fm.descent, t.gradA, t.gradB, Shader.TileMode.CLAMP)
            } else fill.color = t.color
            c.drawText(s, x, y, fill)
        }
        return bmp
    }

    // ------------------------------------------------------------------ GL textures (used on the GL thread only)
    class Tex(val id: Int, val w: Int, val h: Int, var lastUseMs: Long)
    private val texs = HashMap<String, Tex>()
    private var blank: Tex? = null

    fun blankTex(): Tex = blank ?: Tex(GlUtil.createTexture(Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888)), 1, 1, 0).also { blank = it }

    fun texFor(sp: Sprite, tMs: Long): Tex {
        val e = texs[sp.key]
        if (e != null) { e.lastUseMs = tMs; return e }
        if (texs.size > 320) {
            val it = texs.entries.iterator()
            while (it.hasNext()) { val en = it.next(); if (abs(tMs - en.value.lastUseMs) > 1500) { runCatching { GlUtil.deleteTexture(en.value.id) }; it.remove() } }
        }
        val bmp = bitmapFor(sp)
        val t = Tex(GlUtil.createTexture(bmp), bmp.width, bmp.height, tMs)
        texs[sp.key] = t
        return t
    }

    fun releaseTextures() {
        texs.values.forEach { runCatching { GlUtil.deleteTexture(it.id) } }; texs.clear()
        blank?.let { runCatching { GlUtil.deleteTexture(it.id) } }; blank = null
    }

    @UnstableApi fun overlays(): List<TextureOverlay> = List(slotCount) { SlotOverlay(this, it) }

    fun texSize(t: Tex): Size = Size(t.w, t.h)
    fun texId(t: Tex): Int = t.id
}

@UnstableApi
class SlotOverlay(private val scene: OverlayScene, private val index: Int) : TextureOverlay() {
    private val hidden: OverlaySettings = OverlaySettings.Builder().setAlphaScale(0f).build()

    override fun getTextureId(presentationTimeUs: Long): Int {
        val t = presentationTimeUs / 1000
        val sp = scene.sprites(t).getOrNull(index) ?: return scene.texId(scene.blankTex())
        return scene.texId(scene.texFor(sp, t))
    }

    override fun getTextureSize(presentationTimeUs: Long): Size {
        val t = presentationTimeUs / 1000
        val sp = scene.sprites(t).getOrNull(index) ?: return Size(1, 1)
        return scene.texSize(scene.texFor(sp, t))
    }

    override fun getOverlaySettings(presentationTimeUs: Long): OverlaySettings {
        val t = presentationTimeUs / 1000
        val sp = scene.sprites(t).getOrNull(index) ?: return hidden
        val nx = sp.cx / scene.outW * 2f - 1f
        val ny = 1f - sp.cy / scene.outH * 2f
        return OverlaySettings.Builder()
            .setOverlayFrameAnchor(0f, 0f).setBackgroundFrameAnchor(nx, ny)
            .setScale(sp.sx, sp.sy).setRotationDegrees(sp.rot).setAlphaScale(sp.alpha.coerceIn(0f, 1f)).build()
    }

    override fun release() { scene.releaseTextures() }
}
