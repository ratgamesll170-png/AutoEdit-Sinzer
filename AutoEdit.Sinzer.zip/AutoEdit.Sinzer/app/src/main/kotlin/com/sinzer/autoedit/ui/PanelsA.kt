@file:OptIn(ExperimentalLayoutApi::class)

package com.sinzer.autoedit.ui

import android.Manifest
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sinzer.autoedit.ai.AutoStyles
import com.sinzer.autoedit.audio.AudioAnalysis
import com.sinzer.autoedit.audio.BeatMap
import com.sinzer.autoedit.media.MediaProbe
import com.sinzer.autoedit.model.*
import com.sinzer.autoedit.vm.AutoConfig
import com.sinzer.autoedit.vm.MainVM

fun Project.clipOf(sel: Sel?): Clip? = sel?.takeIf { it.kind == ItemKind.CLIP }?.let { s -> clips.firstOrNull { it.id == s.id } }

@Composable
fun PanelScroll(content: @Composable ColumnScope.() -> Unit) =
    Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 6.dp), content = content)

// ------------------------------------------------------------------ AI AUTO EDIT
@Composable
fun AutoPanel(vm: MainVM, p: Project, an: Map<String, AudioAnalysis>) {
    var styleId by remember { mutableStateOf(p.styleId ?: "beatsync") }
    val style = AutoStyles.get(styleId)
    val audios = p.assets.filter { it.type == MediaType.AUDIO }
    var musicMode by remember { mutableIntStateOf(if (audios.isNotEmpty()) 0 else 2) }   // 0 = imported track, 1 = audio inside video, 2 = none
    var musicIdx by remember { mutableIntStateOf(0) }
    var target by remember { mutableIntStateOf(30) }
    var subs by remember { mutableStateOf(false) }
    var applyAspect by remember { mutableStateOf(true) }
    val visual = p.assets.count { it.type != MediaType.AUDIO }
    PanelScroll {
        Row(verticalAlignment = Alignment.CenterVertically) { SectionTitle("1) เลือกสไตล์ (${AutoStyles.all.size} แบบ)", "style") }
        Row(Modifier.horizontalScroll(rememberScrollState())) {
            AutoStyles.all.forEach { s ->
                val sel = s.id == styleId
                Column(Modifier.padding(end = 8.dp).width(92.dp).clip(RoundedCornerShape(14.dp)).background(if (sel) NeonBlue else Surface2)
                    .clickable { styleId = s.id; if (s.subtitleDefault) subs = true }.padding(8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(s.emoji, fontSize = 24.sp)
                    Text(s.nameTh, fontSize = 11.sp, color = if (sel) Color.Black else Color.White, maxLines = 2, lineHeight = 13.sp)
                }
            }
        }
        Text(style.descTh, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))
        val beats = if (style.beatPattern.size == 1) "ทุก ${style.beatPattern[0]} บีต" else "สลับ ${style.beatPattern.joinToString("-")} บีต"
        Text("การตั้งค่าจริงของสไตล์นี้: ตัด$beats · ความยาวคลิป ${style.minCutMs / 1000f}-${style.maxCutMs / 1000f} วิ · " +
            "ความเร็ว ${when (style.speed.name) { "NONE" -> "ปกติ"; "SLOWMO" -> "ช้า ×${style.slow}"; "FAST" -> "เร็ว ×${style.fast}"; else -> "ช้า-เร็ว (velocity)" }} · " +
            "ทรานซิชัน ${style.transitions.size} แบบ · เอฟเฟกต์ ${style.fx.size} · เสียงต้นฉบับ ${(style.origVol * 100).toInt()}%", fontSize = 11.sp, color = TextDim)

        SectionTitle("2) เพลง", "beat")
        ChipRow(listOf("เพลงที่นำเข้า", "เสียงจากวิดีโอ", "ไม่ใช้เพลง"), musicMode) { musicMode = it }
        if (musicMode == 0) {
            if (audios.isEmpty()) Text("ยังไม่มีไฟล์เพลง: ไปที่แท็บ “เพลง/เสียง” เพื่อเพิ่มเพลง", fontSize = 12.sp, color = Danger)
            else ChipRow(audios.map { it.name.take(18) }, musicIdx.coerceAtMost(audios.size - 1)) { musicIdx = it }
        }
        if (musicMode == 1) Text("ใช้เสียงเพลงที่อยู่ในวิดีโอ (คลิปแรกที่มีเสียง) เป็นจังหวะ", fontSize = 12.sp, color = TextDim)
        if (musicMode == 2) Text("ไม่มีเพลง: แอปจะตัดตามความยาวคงที่ของสไตล์", fontSize = 12.sp, color = TextDim)

        SectionTitle("3) ความยาวผลงาน")
        ChipRow(listOf("15 วิ", "30 วิ", "60 วิ", "ตามเพลง/ทั้งหมด"), listOf(15, 30, 60, 0).indexOf(target)) { target = listOf(15, 30, 60, 0)[it] }
        SwitchRow("สร้างคำบรรยายอัตโนมัติหลังตัดต่อ (ใช้บริการภายนอก มีค่าใช้จ่าย)", subs) { subs = it }
        if (style.aspect != null) SwitchRow("ปรับอัตราส่วนเป็น ${style.aspect.label} ตามสไตล์", applyAspect) { applyAspect = it }
        Spacer(Modifier.height(8.dp))
        NeonButton("✨ เริ่ม AI ตัดต่ออัตโนมัติ ($visual คลิป)", Modifier.fillMaxWidth(), enabled = visual > 0 && (musicMode != 0 || audios.isNotEmpty())) {
            vm.runAutoEdit(AutoConfig(styleId, if (musicMode == 0) audios.getOrNull(musicIdx)?.id else null, musicMode == 1, target, subs, applyAspect))
        }
        if (visual == 0) Text("นำเข้าวิดีโอ/รูปภาพก่อนในแท็บ “นำเข้า”", fontSize = 12.sp, color = Danger, modifier = Modifier.padding(top = 4.dp))
        Text("ทำงานบนเครื่องทั้งหมด (ยกเว้นคำบรรยาย) · ผลลัพธ์แก้ไขได้ทุกคลิป และกด Undo เพื่อย้อนกลับได้", fontSize = 11.sp, color = TextDim, modifier = Modifier.padding(top = 6.dp))
    }
}

// ------------------------------------------------------------------ MEDIA
@Composable
fun MediaPanel(vm: MainVM, p: Project, missing: Set<String>) {
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { vm.importMedia(it) }
    var relinkId by remember { mutableStateOf<String?>(null) }
    val relinkPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u -> relinkId?.let { id -> if (u != null) vm.relink(id, u) }; relinkId = null }
    PanelScroll {
        SectionTitle("สื่อในโปรเจกต์", "import")
        NeonButton("＋ นำเข้าวิดีโอ รูปภาพ เพลง", Modifier.fillMaxWidth()) { picker.launch(MediaProbe.PICK_TYPES) }
        Text("ไฟล์ต้นฉบับจะไม่ถูกแก้ไขหรือคัดลอก", fontSize = 11.sp, color = TextDim)
        SectionTitle("อัตราส่วนภาพ", "aspect")
        ChipRow(Aspect.values().map { it.label }, p.aspect.ordinal) { vm.setAspect(Aspect.values()[it]) }
        p.assets.forEach { a ->
            val gone = a.id in missing
            Row(Modifier.fillMaxWidth().padding(vertical = 4.dp).clip(RoundedCornerShape(10.dp)).background(Surface2).padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text((if (a.type == MediaType.VIDEO) "🎞 " else if (a.type == MediaType.AUDIO) "♪ " else "🖼 ") + a.name, fontSize = 13.sp, maxLines = 1)
                    Text(buildString {
                        if (a.type != MediaType.IMAGE) append("${a.durationMs / 1000}.${a.durationMs / 100 % 10} วิ  ")
                        if (a.width > 0) append("${a.width}×${a.height}  ")
                        if (a.type == MediaType.VIDEO) append("${a.fps.toInt()}fps")
                    }, fontSize = 11.sp, color = TextDim)
                    if (gone) Text("⚠ ไม่พบไฟล์ต้นฉบับ (ถูกย้ายหรือลบ)", fontSize = 11.sp, color = Danger)
                }
                if (gone) TextButton(onClick = { relinkId = a.id; relinkPicker.launch(MediaProbe.PICK_TYPES) }) { Text("เลือกไฟล์ใหม่") }
                else if (a.type == MediaType.AUDIO) TextButton(onClick = { vm.addAudioAsset(a) }) { Text("วางเพลง") }
                else TextButton(onClick = { vm.edit { Ops.appendToMain(it, a) } }) { Text("เพิ่ม") }
            }
        }
    }
}

// ------------------------------------------------------------------ AUDIO
@Composable
fun AudioPanel(vm: MainVM, p: Project, sel: Sel?) {
    val clip = p.clipOf(sel)
    val rec by vm.recording.collectAsState()
    val audioPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) vm.viewModelScope_launchProbe(u)
    }
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok -> if (ok) vm.startRecording() else vm.toast("ต้องอนุญาตไมโครโฟนเพื่ออัดเสียงพากย์") }
    PanelScroll {
        SectionTitle("เสียงและเพลง", "volume")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { audioPicker.launch(arrayOf("audio/*")) }) { Text("＋ เพิ่มเพลง/เสียง") }
            OutlinedButton(onClick = { if (rec) vm.stopRecording() else perm.launch(Manifest.permission.RECORD_AUDIO) }) { Text(if (rec) "⏹ หยุดอัด" else "🎙 อัดเสียงพากย์") }
            HelpIcon("record")
        }
        SwitchRow("Audio Ducking: ลดเสียงเพลงเมื่อมีเสียงพูด", p.ducking) { v -> vm.edit { it.copy(ducking = v) } }
        if (p.ducking) LabeledSlider("ระดับเสียงเพลงขณะมีเสียงพูด", p.duckLevel, 0f..1f, "${(p.duckLevel * 100).toInt()}%", { v -> vm.edit(false) { it.copy(duckLevel = v) } })
        HelpIcon("ducking")
        if (clip == null) { Text("เลือกคลิปบนไทม์ไลน์เพื่อปรับเสียงของคลิปนั้น", fontSize = 12.sp, color = TextDim); return@PanelScroll }
        val a = p.asset(clip.assetId)
        SectionTitle("คลิปที่เลือก: ${a?.name ?: ""}")
        SwitchRow("ปิดเสียงคลิปนี้", clip.muted) { v -> vm.updateClip(clip.id) { it.copy(muted = v) } }
        LabeledSlider("ระดับเสียง", clip.volume, 0f..2f, "${(clip.volume * 100).toInt()}%", { v -> vm.beginGestureOnce(); vm.updateClip(clip.id) { it.copy(volume = v) } }, { vm.endGesture() })
        LabeledSlider("Fade In", clip.fadeInMs / 1000f, 0f..5f, "%.1f วิ".format(clip.fadeInMs / 1000f), { v -> vm.beginGestureOnce(); vm.updateClip(clip.id) { it.copy(fadeInMs = (v * 1000).toLong()) } }, { vm.endGesture() })
        LabeledSlider("Fade Out", clip.fadeOutMs / 1000f, 0f..5f, "%.1f วิ".format(clip.fadeOutMs / 1000f), { v -> vm.beginGestureOnce(); vm.updateClip(clip.id) { it.copy(fadeOutMs = (v * 1000).toLong()) } }, { vm.endGesture() })
        if (a?.type == MediaType.VIDEO && a.hasAudio && !clip.audioOnly) {
            Row(verticalAlignment = Alignment.CenterVertically) { OutlinedButton(onClick = { vm.extractAudio(clip.id) }) { Text("แยกเสียงออกจากวิดีโอ") }; HelpIcon("extract_audio") }
        }
        Text("เลื่อนเสียงให้ตรงภาพ: ลากคลิปเสียงบนไทม์ไลน์ / ตัดช่วงเพลง: ลากจุดจับปลายคลิป", fontSize = 11.sp, color = TextDim)
    }
}

// ------------------------------------------------------------------ BEAT
@Composable
fun BeatPanel(vm: MainVM, p: Project, an: Map<String, AudioAnalysis>, beats: BeatMap, sel: Sel?, playhead: Long) {
    val sources = p.assets.filter { it.type == MediaType.AUDIO || it.hasAudio }
    val src = p.beatAssetId
    val a = src?.let { an[it] }
    val edit = src?.let { p.beatEdits[it] } ?: BeatEdit()
    PanelScroll {
        SectionTitle("Beat Sync: จังหวะเพลง", "beat")
        if (sources.isEmpty()) { Text("เพิ่มเพลงหรือวิดีโอที่มีเสียงก่อน", color = Danger, fontSize = 12.sp); return@PanelScroll }
        Text("แหล่งจังหวะ (เพลงแยก หรือเสียงเพลงในวิดีโอ)", fontSize = 12.sp, color = TextDim)
        ChipRow(sources.map { (if (it.type == MediaType.AUDIO) "♪ " else "🎞 ") + it.name.take(16) }, sources.indexOfFirst { it.id == src }) { i ->
            val s = sources[i]; vm.setBeatSource(s.id); vm.analyzeAudio(s)
        }
        if (src != null && a == null) {
            val s = sources.first { it.id == src }
            NeonButton("วิเคราะห์จังหวะ", Modifier.padding(top = 6.dp)) { vm.analyzeAudio(s) }
            return@PanelScroll
        }
        if (a == null) return@PanelScroll
        Text(if (a.beatsMs.isEmpty()) "ไม่พบจังหวะที่ชัดเจนในเสียงนี้ (เพิ่มบีตเองได้ด้านล่าง)" else "BPM ≈ ${"%.1f".format(beats.bpm)} · ${a.beatsMs.size} บีตที่ตรวจพบ · ${beats.beatsMs.size} บีตบนไทม์ไลน์",
            fontSize = 13.sp, fontWeight = FontWeight.Bold)
        Text("เส้นม่วงบนไทม์ไลน์ = ตำแหน่งบีต (เข้มกว่า = บีตแรงกว่า)", fontSize = 11.sp, color = TextDim)
        val id = src!!
        SectionTitle("แก้บีตที่ตรวจผิด", "beat_edit")
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            OutlinedButton(onClick = { vm.editBeats(id) { it.copy(doubleTempo = !it.doubleTempo, halfTempo = false) } }) { Text(if (edit.doubleTempo) "✓ ×2" else "×2 (เร็วขึ้น)") }
            OutlinedButton(onClick = { vm.editBeats(id) { it.copy(halfTempo = !it.halfTempo, doubleTempo = false) } }) { Text(if (edit.halfTempo) "✓ ÷2" else "÷2 (ช้าลง)") }
        }
        LabeledSlider("เลื่อนบีตทั้งหมด", edit.shiftMs.toFloat(), -300f..300f, "${edit.shiftMs} ms", { v -> vm.beginGestureOnce(); vm.editBeats(id) { it.copy(shiftMs = v.toLong()) } }, { vm.endGesture() })
        ChipRow(listOf("เริ่มบีตที่ 1", "เริ่มบีตที่ 2", "เริ่มบีตที่ 3", "เริ่มบีตที่ 4"), edit.phase.coerceIn(0, 3)) { i -> vm.editBeats(id) { it.copy(phase = i) } }
        Text("ใช้กำหนดว่า “ทุก 2 / 4 บีต” เริ่มนับจากบีตไหน", fontSize = 11.sp, color = TextDim)
        val clip = p.clips.firstOrNull { it.assetId == id && p.track(it.trackId)?.kind == TrackKind.AUDIO } ?: p.clips.firstOrNull { it.assetId == id }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            OutlinedButton(onClick = { clip?.let { c -> vm.editBeats(id) { it.copy(added = it.added + (c.inMs + ((playhead - c.startMs) * c.speed).toLong())) } } }) { Text("＋ เพิ่มบีตที่เพลย์เฮด") }
            OutlinedButton(onClick = { clip?.let { c -> val srcT = c.inMs + ((playhead - c.startMs) * c.speed).toLong()
                val near = com.sinzer.autoedit.audio.BeatMap.build(a, edit).beatsMs.minByOrNull { kotlin.math.abs(it - srcT) }
                if (near != null) vm.editBeats(id) { it.copy(removed = it.removed + near, added = it.added.filter { x -> kotlin.math.abs(x - near) > 60 }) } } }) { Text("－ ลบบีตใกล้เพลย์เฮด") }
        }
        TextButton(onClick = { vm.editBeats(id) { BeatEdit() } }) { Text("รีเซ็ตการแก้บีต") }
        SwitchRow("แม่เหล็ก: ให้คลิปเกาะบีต/ขอบคลิป", p.snap) { vm.setSnap(it) }

        SectionTitle("โหมดแก้จังหวะเอง: ตัดคลิปตามบีต")
        val c = p.clipOf(sel)
        if (c == null || c.trackId != p.mainTrackId) Text("เลือกคลิปบนแทร็กวิดีโอหลักก่อน", fontSize = 12.sp, color = TextDim)
        else FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("ทุกครึ่งบีต" to 0.5f, "ทุก 1 บีต" to 1f, "ทุก 2 บีต" to 2f, "ทุก 4 บีต" to 4f).forEach { (l, n) -> OutlinedButton(onClick = { vm.splitAtBeats(c.id, n) }) { Text(l, fontSize = 12.sp) } }
        }
        Text("ซิงก์ Flash / Zoom / Shake / Transition กับบีต: เปิดสวิตช์ “ซิงก์บีต” ของเอฟเฟกต์ในแท็บเอฟเฟกต์ ความแรงจะตามความแรงของบีต", fontSize = 11.sp, color = TextDim)
    }
}

// ------------------------------------------------------------------ TRACKS
@Composable
fun TracksPanel(vm: MainVM, p: Project) {
    PanelScroll {
        SectionTitle("แทร็ก", "tracks")
        p.tracks.forEach { t ->
            Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(t.name, Modifier.weight(1f), fontSize = 13.sp)
                FilterChip(t.locked, { vm.updateTrack(t.id) { it.copy(locked = !it.locked) } }, { Text("ล็อก", fontSize = 11.sp) })
                Spacer(Modifier.width(4.dp))
                FilterChip(t.hidden, { vm.updateTrack(t.id) { it.copy(hidden = !it.hidden) } }, { Text("ซ่อน", fontSize = 11.sp) })
                if (t.kind == TrackKind.AUDIO || t.kind == TrackKind.VIDEO) { Spacer(Modifier.width(4.dp)); FilterChip(t.muted, { vm.updateTrack(t.id) { it.copy(muted = !it.muted) } }, { Text("เงียบ", fontSize = 11.sp) }) }
            }
        }
        SectionTitle("เพิ่มแทร็ก")
        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("เสียง" to TrackKind.AUDIO, "ข้อความ" to TrackKind.TEXT, "สติ๊กเกอร์" to TrackKind.STICKER, "โอเวอร์เลย์" to TrackKind.OVERLAY, "เอฟเฟกต์" to TrackKind.EFFECT)
                .forEach { (l, k) -> OutlinedButton(onClick = { vm.addTrack(k) }) { Text("＋ $l", fontSize = 12.sp) } }
        }
        Text("หมายเหตุ: เวอร์ชันนี้เรนเดอร์วิดีโอซ้อนหลายชั้น (PiP) ยังไม่ได้ โอเวอร์เลย์รองรับภาพและสติ๊กเกอร์", fontSize = 11.sp, color = TextDim)
    }
}
