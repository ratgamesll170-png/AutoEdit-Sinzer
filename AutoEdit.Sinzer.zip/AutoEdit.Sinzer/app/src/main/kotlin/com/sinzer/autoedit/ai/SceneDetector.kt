package com.sinzer.autoedit.ai

import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import com.sinzer.autoedit.model.MediaAsset
import com.sinzer.autoedit.model.MediaType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

const val BIN_MS = 250L

/** Result of visual analysis of one video: scene cuts and a motion/activity value per 250 ms bin (0..1). */
class SceneInfo(val durationMs: Long, val cutsMs: List<Long>, val motion: FloatArray)

object SceneDetector {
    /** Samples small frames and compares luma histogram + pixels between neighbours. Runs on-device. */
    suspend fun analyze(ctx: Context, a: MediaAsset, onProgress: (Float) -> Unit): SceneInfo = withContext(Dispatchers.Default) {
        if (a.type != MediaType.VIDEO) return@withContext SceneInfo(a.durationMs, emptyList(), FloatArray((a.durationMs / BIN_MS).toInt() + 1) { 0.5f })
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(ctx, Uri.parse(a.uri))
            val step = (a.durationMs / 300).coerceIn(250L, 2000L)
            val times = ArrayList<Long>(); var t = 0L
            while (t < a.durationMs) { times.add(t); t += step }
            val dpix = ArrayList<Float>(); val dhist = ArrayList<Float>()
            var prevPix: IntArray? = null; var prevHist: FloatArray? = null
            for ((i, tm) in times.withIndex()) {
                if (!currentCoroutineContext().isActive) break
                val bmp = r.getScaledFrameAtTime(tm * 1000, MediaMetadataRetriever.OPTION_CLOSEST, 64, 36)
                if (bmp != null) {
                    val (pix, hist) = features(bmp)
                    if (prevPix != null && prevHist != null) {
                        var sd = 0L; for (k in pix.indices) sd += abs(pix[k] - prevPix[k])
                        dpix.add(sd / (pix.size * 255f))
                        var hd = 0f; for (k in hist.indices) hd += abs(hist[k] - prevHist[k])
                        dhist.add(hd / 2f)
                    } else { dpix.add(0f); dhist.add(0f) }
                    prevPix = pix; prevHist = hist
                    bmp.recycle()
                } else { dpix.add(0f); dhist.add(0f) }
                if (i % 5 == 0) onProgress(i / times.size.toFloat())
            }
            val score = FloatArray(dpix.size) { 0.5f * dpix[it] + 0.5f * dhist[it] }
            val mean = score.average().toFloat()
            val sd = sqrt(score.map { (it - mean) * (it - mean) }.average()).toFloat()
            val thr = max(0.22f, mean + 3f * sd)
            val cuts = ArrayList<Long>()
            for (i in 1 until score.size) if (score[i] > thr) {
                val c = times[i] - step / 2
                if (cuts.isEmpty() || c - cuts.last() >= 400) cuts.add(c.coerceAtLeast(0))
            }
            // motion per bin (cut spikes excluded)
            val nb = (a.durationMs / BIN_MS).toInt() + 1
            val motion = FloatArray(nb); val cnt = IntArray(nb)
            for (i in score.indices) { val v = if (score[i] > thr) mean else score[i]; val b = min(nb - 1, (times[i] / BIN_MS).toInt()); motion[b] += v; cnt[b]++ }
            var last = 0f
            for (b in 0 until nb) { if (cnt[b] > 0) { motion[b] /= cnt[b]; last = motion[b] } else motion[b] = last }
            val sorted = motion.sortedArray(); val p95 = max(0.02f, sorted[(sorted.size * 0.95f).toInt().coerceAtMost(sorted.size - 1)])
            for (b in 0 until nb) motion[b] = (motion[b] / p95).coerceIn(0f, 1f)
            onProgress(1f)
            SceneInfo(a.durationMs, cuts, motion)
        } finally { runCatching { r.release() } }
    }

    private fun features(b: Bitmap): Pair<IntArray, FloatArray> {
        val w = b.width; val h = b.height
        val px = IntArray(w * h); b.getPixels(px, 0, w, 0, 0, w, h)
        val luma = IntArray(px.size); val hist = FloatArray(16)
        for (i in px.indices) {
            val c = px[i]
            val l = ((c shr 16 and 255) * 299 + (c shr 8 and 255) * 587 + (c and 255) * 114) / 1000
            luma[i] = l; hist[l shr 4] += 1f
        }
        for (i in hist.indices) hist[i] /= px.size
        return luma to hist
    }
}
