package com.sinzer.autoedit.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sinzer.autoedit.catalog.Help

val Bg = Color(0xFF070B16)
val Surface1 = Color(0xFF0F1630)
val Surface2 = Color(0xFF172046)
val NeonBlue = Color(0xFF35D0FF)
val NeonPurple = Color(0xFF9B6BFF)
val TextDim = Color(0xFF9AA6C7)
val Danger = Color(0xFFFF5470)

private val scheme = darkColorScheme(
    primary = NeonBlue, onPrimary = Color(0xFF00121A), secondary = NeonPurple, background = Bg, surface = Surface1,
    onBackground = Color.White, onSurface = Color.White, surfaceVariant = Surface2, onSurfaceVariant = TextDim, error = Danger,
    primaryContainer = Color(0xFF0E3A52), onPrimaryContainer = Color.White,
)

@Composable
fun AppTheme(content: @Composable () -> Unit) = MaterialTheme(colorScheme = scheme, content = content)

val NeonBrush = Brush.horizontalGradient(listOf(NeonBlue, NeonPurple))

@Composable
fun NeonButton(text: String, modifier: Modifier = Modifier, enabled: Boolean = true, onClick: () -> Unit) {
    Box(
        modifier.height(48.dp).clip(RoundedCornerShape(24.dp))
            .background(if (enabled) NeonBrush else Brush.horizontalGradient(listOf(Surface2, Surface2)))
            .clickable(enabled = enabled, onClick = onClick).padding(horizontal = 22.dp),
        contentAlignment = Alignment.Center,
    ) { Text(text, color = if (enabled) Color.Black else TextDim, fontWeight = FontWeight.Bold, maxLines = 1) }
}

@Composable
fun SmallChip(text: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.padding(end = 6.dp).clip(RoundedCornerShape(16.dp))
            .background(if (selected) NeonBlue else Surface2).clickable(onClick = onClick).padding(horizontal = 12.dp, vertical = 7.dp),
        contentAlignment = Alignment.Center,
    ) { Text(text, color = if (selected) Color.Black else Color.White, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis) }
}

@Composable
fun ChipRow(items: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 4.dp)) {
        items.forEachIndexed { i, s -> SmallChip(s, i == selected) { onSelect(i) } }
    }
}

@Composable
fun LabeledSlider(label: String, value: Float, range: ClosedFloatingPointRange<Float>, valueText: String = "%.2f".format(value), onChange: (Float) -> Unit, onDone: () -> Unit = {}) {
    Column(Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, fontSize = 13.sp, color = TextDim); Text(valueText, fontSize = 13.sp, color = Color.White)
        }
        Slider(value = value.coerceIn(range), onValueChange = onChange, valueRange = range, onValueChangeFinished = onDone,
            modifier = Modifier.height(30.dp), colors = SliderDefaults.colors(thumbColor = NeonBlue, activeTrackColor = NeonBlue))
    }
}

@Composable
fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f), fontSize = 14.sp)
        Switch(checked, onChange, colors = SwitchDefaults.colors(checkedTrackColor = NeonBlue, checkedThumbColor = Color.White))
    }
}

@Composable
fun SectionTitle(text: String, helpKey: String? = null) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 8.dp, bottom = 2.dp)) {
        Text(text, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = NeonBlue)
        if (helpKey != null) HelpIcon(helpKey)
    }
}

/** "?" button: opens the Thai explanation for [key]. */
@Composable
fun HelpIcon(key: String) {
    var show by remember { mutableStateOf(false) }
    IconButton(onClick = { show = true }, modifier = Modifier.size(32.dp)) { Icon(Icons.Filled.HelpOutline, "ช่วยเหลือ", tint = TextDim, modifier = Modifier.size(18.dp)) }
    if (show) HelpDialog(key) { show = false }
}

@Composable
fun HelpDialog(key: String, onClose: () -> Unit) {
    val h = Help.get(key)
    AlertDialog(onDismissRequest = onClose, containerColor = Surface1,
        title = { Text(h?.title ?: "ช่วยเหลือ") }, text = { Text(h?.text ?: "ยังไม่มีคำอธิบายสำหรับเมนูนี้") },
        confirmButton = { TextButton(onClick = onClose) { Text("เข้าใจแล้ว") } })
}

/** First-use tip with a Skip button. Shown once per tool; remembered in settings. */
@Composable
fun FirstUseTip(key: String, seen: Set<String>, onSeen: (String) -> Unit) {
    val h = Help.get(key) ?: return
    if (key in seen) return
    AlertDialog(onDismissRequest = { onSeen(key) }, containerColor = Surface1,
        title = { Text("💡 ${h.title}") }, text = { Text(h.text) },
        confirmButton = { TextButton(onClick = { onSeen(key) }) { Text("เข้าใจแล้ว") } },
        dismissButton = { TextButton(onClick = { onSeen(key) }) { Text("ข้าม", color = TextDim) } })
}

val Palette = listOf(0xFFFFFFFF, 0xFF000000, 0xFFFF4D4D, 0xFFFFA94D, 0xFFFFE14D, 0xFF4DFF88, 0xFF35D0FF, 0xFF4D7BFF, 0xFF9B6BFF, 0xFFFF6BD6, 0xFF8A8A8A).map { it.toInt() }

@Composable
fun ColorRow(label: String, selected: Int, allowNone: Boolean = false, onPick: (Int) -> Unit) {
    Column {
        Text(label, fontSize = 13.sp, color = TextDim)
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 4.dp)) {
            if (allowNone) Box(Modifier.padding(end = 8.dp).size(28.dp).clip(CircleShape).background(Surface2)
                .border(if (selected == 0) 2.dp else 0.dp, Color.White, CircleShape).clickable { onPick(0) }, contentAlignment = Alignment.Center) { Text("✕", fontSize = 12.sp) }
            Palette.forEach { c ->
                Box(Modifier.padding(end = 8.dp).size(28.dp).clip(CircleShape).background(Color(c))
                    .border(if (selected == c) 2.dp else 0.dp, if (c == 0xFFFFFFFF.toInt()) NeonBlue else Color.White, CircleShape).clickable { onPick(c) })
            }
        }
    }
}

fun fmtTime(ms: Long): String {
    val t = ms.coerceAtLeast(0); val m = t / 60000; val s = t / 1000 % 60; val cs = t % 1000 / 10
    return "%02d:%02d.%02d".format(m, s, cs)
}
