package com.sinzer.autoedit.catalog

import kotlin.math.pow

/**
 * A transition is rendered as two matching halves on the cut:
 *  - OUT half: last [durMs] of the outgoing clip, progress p goes 0 -> 1
 *  - IN  half: first [durMs] of the next clip,    progress p goes 1 -> 0
 * [f] returns the shader parameters for progress p; [s] is +1 for OUT and -1 for IN so that directional
 * moves (slide, whip, spin, wipe) continue in the same direction across the cut.
 * (True cross-dissolve of two overlapping clips is not part of this version.)
 */
class TransPreset(val id: String, val nameTh: String, val cat: String, val f: (p: Float, s: Float) -> Map<String, Float>) {
    val keys: Set<String> = f(1f, 1f).keys + f(.5f, 1f).keys + f(.5f, -1f).keys
}

object TransitionCatalog {
    const val C_DIP = "เฟด/แฟลช"; const val C_ZOOM = "ซูม"; const val C_MOVE = "สไลด์/วิป/ปัด"
    const val C_SPIN = "หมุน"; const val C_GLITCH = "กลิตช์/สัญญาณ"; const val C_BLUR = "เบลอ/สั่น"
    const val C_FUN = "พิเศษ"; const val C_LIGHT = "แสง/ฟิล์ม"
    val categories = listOf(C_DIP, C_ZOOM, C_MOVE, C_SPIN, C_GLITCH, C_BLUR, C_LIGHT, C_FUN)

    private val list = ArrayList<TransPreset>()
    private fun t(id: String, name: String, cat: String, f: (Float, Float) -> Map<String, Float>) { list.add(TransPreset("t_$id", name, cat, f)) }
    private fun dip(p: Float, r: Float, g: Float, b: Float, pow: Float = 1f) =
        arrayOf("dip" to p.pow(pow), "fr" to r, "fg" to g, "fb" to b)

    init {
        // --- เฟด/แฟลช (10)
        t("flash_white", "แฟลชขาว", C_DIP) { p, _ -> mapOf(*dip(p, 1f, 1f, 1f, 2f)) }
        t("flash_black", "แฟลชดำ", C_DIP) { p, _ -> mapOf(*dip(p, 0f, 0f, 0f, 2.5f)) }
        t("dip_black", "เฟดดำ", C_DIP) { p, _ -> mapOf(*dip(p, 0f, 0f, 0f)) }
        t("fade_white", "เฟดขาว", C_DIP) { p, _ -> mapOf(*dip(p, 1f, 1f, 1f)) }
        t("fade_gray", "เฟดเทา", C_DIP) { p, _ -> mapOf(*dip(p, .5f, .5f, .5f)) }
        t("dip_red", "เฟดแดง", C_DIP) { p, _ -> mapOf(*dip(p, 1f, .1f, .1f, 1.5f)) }
        t("dip_blue", "เฟดน้ำเงิน", C_DIP) { p, _ -> mapOf(*dip(p, .1f, .3f, 1f, 1.5f)) }
        t("dip_pink", "เฟดชมพู", C_DIP) { p, _ -> mapOf(*dip(p, 1f, .3f, .8f, 1.5f)) }
        t("dip_cyan", "เฟดฟ้า", C_DIP) { p, _ -> mapOf(*dip(p, .1f, 1f, 1f, 1.5f)) }
        t("dip_gold", "เฟดทอง", C_DIP) { p, _ -> mapOf(*dip(p, 1f, .8f, .2f, 1.5f)) }
        // --- ซูม (6)
        t("zoom_in", "ซูมเข้า", C_ZOOM) { p, _ -> mapOf("zoom" to 2.5f * p, "radial" to 1.2f * p, *dip(p, 1f, 1f, 1f, 3f)) }
        t("zoom_out", "ซูมออก", C_ZOOM) { p, _ -> mapOf("zoom" to -.75f * p, "border" to 1f, "blur" to p, *dip(p, 0f, 0f, 0f, 3f)) }
        t("zoom_in_blur", "ซูมเข้าเบลอ", C_ZOOM) { p, _ -> mapOf("zoom" to 1.5f * p, "blur" to 3f * p) }
        t("zoom_punch", "ซูมกระแทก", C_ZOOM) { p, _ -> mapOf("zoom" to 1.2f * p, "rgb" to .03f * p, "shake" to .02f * p, "shakeHz" to 30f) }
        t("zoom_in_white", "ซูมเข้าแสงขาว", C_ZOOM) { p, _ -> mapOf("zoom" to 2f * p, *dip(p, 1f, 1f, 1f, 1.2f)) }
        t("zoom_out_black", "ซูมออกดำ", C_ZOOM) { p, _ -> mapOf("zoom" to -.6f * p, "border" to 1f, *dip(p, 0f, 0f, 0f, 2f)) }
        // --- สไลด์/วิป/ปัด (17)
        t("whip_left", "วิปแพนซ้าย", C_MOVE) { p, s -> mapOf("slideX" to -1.2f * p * s, "motion" to 1.6f * p, "motionAng" to 0f) }
        t("whip_right", "วิปแพนขวา", C_MOVE) { p, s -> mapOf("slideX" to 1.2f * p * s, "motion" to 1.6f * p, "motionAng" to 0f) }
        t("whip_up", "วิปแพนขึ้น", C_MOVE) { p, s -> mapOf("slideY" to 1.2f * p * s, "motion" to 1.6f * p, "motionAng" to 90f) }
        t("whip_down", "วิปแพนลง", C_MOVE) { p, s -> mapOf("slideY" to -1.2f * p * s, "motion" to 1.6f * p, "motionAng" to 90f) }
        t("slide_left", "สไลด์ซ้าย", C_MOVE) { p, s -> mapOf("slideX" to -p * s, "border" to 1f) }
        t("slide_right", "สไลด์ขวา", C_MOVE) { p, s -> mapOf("slideX" to p * s, "border" to 1f) }
        t("slide_up", "สไลด์ขึ้น", C_MOVE) { p, s -> mapOf("slideY" to p * s, "border" to 1f) }
        t("slide_down", "สไลด์ลง", C_MOVE) { p, s -> mapOf("slideY" to -p * s, "border" to 1f) }
        t("wipe_left", "ปัดซ้าย", C_MOVE) { p, s -> mapOf("wipeP" to p, "wipeAng" to if (s > 0) 180f else 0f) }
        t("wipe_right", "ปัดขวา", C_MOVE) { p, s -> mapOf("wipeP" to p, "wipeAng" to if (s > 0) 0f else 180f) }
        t("wipe_up", "ปัดขึ้น", C_MOVE) { p, s -> mapOf("wipeP" to p, "wipeAng" to if (s > 0) 90f else 270f) }
        t("wipe_down", "ปัดลง", C_MOVE) { p, s -> mapOf("wipeP" to p, "wipeAng" to if (s > 0) 270f else 90f) }
        t("wipe_diag", "ปัดเฉียง", C_MOVE) { p, s -> mapOf("wipeP" to p, "wipeAng" to if (s > 0) 45f else 225f) }
        t("iris_close", "วงกลมปิด", C_MOVE) { p, _ -> mapOf("iris" to p) }
        t("iris_blur", "วงกลมปิดเบลอ", C_MOVE) { p, _ -> mapOf("iris" to p, "blur" to 2f * p) }
        t("roll", "ม้วน", C_MOVE) { p, s -> mapOf("slideX" to -p * s, "rot" to -90f * p * s, "border" to 1f) }
        t("drop", "ตกลง", C_MOVE) { p, s -> mapOf("slideY" to -p * s, "shake" to .02f * p, "shakeHz" to 24f, "border" to 1f) }
        // --- หมุน (4)
        t("spin_cw", "หมุนตามเข็ม", C_SPIN) { p, s -> mapOf("rot" to -360f * p * s, "zoom" to p, "radial" to .8f * p, *dip(p, 1f, 1f, 1f, 3f)) }
        t("spin_ccw", "หมุนทวนเข็ม", C_SPIN) { p, s -> mapOf("rot" to 360f * p * s, "zoom" to p, "radial" to .8f * p, *dip(p, 1f, 1f, 1f, 3f)) }
        t("spin_zoom", "หมุนซูม", C_SPIN) { p, s -> mapOf("rot" to -180f * p * s, "zoom" to 2f * p) }
        t("spin_flash", "หมุนแฟลช", C_SPIN) { p, s -> mapOf("rot" to -270f * p * s, *dip(p, 1f, 1f, 1f, 2f)) }
        // --- กลิตช์/สัญญาณ (5)
        t("glitch", "กลิตช์", C_GLITCH) { p, _ -> mapOf("glitch" to 2.2f * p, "rgb" to .03f * p, "shake" to .01f * p, "shakeHz" to 25f) }
        t("glitch_heavy", "กลิตช์หนัก", C_GLITCH) { p, _ -> mapOf("glitch" to 4f * p, "rgb" to .06f * p, "shake" to .04f * p, "shakeHz" to 28f, "grain" to .3f * p) }
        t("digital", "ดิจิทัลพิกเซล", C_GLITCH) { p, _ -> mapOf("glitch" to 2f * p, "pix" to if (p > .1f) 400f - 380f * p else 0f, "scan" to .5f * p) }
        t("vhs_tape", "ม้วนเทป VHS", C_GLITCH) { p, _ -> mapOf("vhs" to 4f * p, "scan" to .8f * p, "rgb" to .02f * p, "grain" to .3f * p, "blur" to .5f * p) }
        t("signal", "สัญญาณขาด", C_GLITCH) { p, _ -> mapOf("glitch" to 3f * p, "grain" to .5f * p, "mono" to p, "scan" to .6f * p) }
        // --- เบลอ/สั่น (9)
        t("rgb_split", "แยกสี RGB", C_BLUR) { p, _ -> mapOf("rgb" to .08f * p, "rgbAng" to 0f, "shake" to .01f * p, "shakeHz" to 26f) }
        t("rgb_spin", "แยกสีหมุน", C_BLUR) { p, s -> mapOf("rgb" to .06f * p, "rgbAng" to 90f, "rot" to 90f * p * s) }
        t("chroma", "โครมาติกซูม", C_BLUR) { p, _ -> mapOf("rgb" to .05f * p, "radial" to .6f * p, "zoom" to .3f * p) }
        t("shake", "สั่น", C_BLUR) { p, _ -> mapOf("shake" to .08f * p, "shakeHz" to 28f) }
        t("shake_zoom", "สั่นซูม", C_BLUR) { p, _ -> mapOf("shake" to .06f * p, "shakeHz" to 28f, "zoom" to .6f * p, "radial" to .5f * p) }
        t("earthquake", "แผ่นดินไหว", C_BLUR) { p, _ -> mapOf("shake" to .15f * p, "shakeHz" to 14f, "blur" to p) }
        t("blur", "เบลอ", C_BLUR) { p, _ -> mapOf("blur" to 5f * p) }
        t("blur_zoom", "เบลอซูม", C_BLUR) { p, _ -> mapOf("radial" to 2f * p, "zoom" to .5f * p) }
        t("blur_dip", "เบลอขาว", C_BLUR) { p, _ -> mapOf("blur" to 3f * p, *dip(p, 1f, 1f, 1f, 2f)) }
        // --- แสง/ฟิล์ม (4)
        t("light_leak", "แสงรั่ว", C_LIGHT) { p, _ -> mapOf("leak" to 2.5f * p, "blur" to .6f * p, *dip(p, 1f, .7f, .3f, 2.5f)) }
        t("film_burn", "ฟิล์มไหม้", C_LIGHT) { p, _ -> mapOf("leak" to 3f * p, "grain" to .4f * p, "temp" to .6f * p, *dip(p, 1f, .45f, .1f, 2f)) }
        t("beat_flash", "แฟลชบีต", C_LIGHT) { p, _ -> mapOf("zoom" to .15f * p, *dip(p, 1f, 1f, 1f, 4f)) }
        t("flicker", "กะพริบ", C_LIGHT) { p, _ -> mapOf("strobe" to 18f, "strobeAmt" to p, "fr" to 0f, "fg" to 0f, "fb" to 0f) }
        // --- พิเศษ (7)
        t("pixel", "โมเสก", C_FUN) { p, _ -> mapOf("pix" to if (p > .08f) 600f - 590f * p else 0f) }
        t("pixel_flash", "โมเสกแฟลช", C_FUN) { p, _ -> mapOf("pix" to if (p > .08f) 600f - 590f * p else 0f, *dip(p, 1f, 1f, 1f, 3f)) }
        t("mirror", "กระจก", C_FUN) { p, _ -> mapOf("mirror" to if (p > .35f) 3f else 0f, "zoom" to .3f * p) }
        t("kaleido", "คาไลโดสโคป", C_FUN) { p, _ -> mapOf("kal" to if (p > .2f) 6f else 0f, "rot" to 60f * p, "zoom" to .5f * p) }
        t("tile", "ตาราง", C_FUN) { p, _ -> mapOf("tile" to if (p > .2f) 1f + (p * 3f).toInt() else 1f) }
        t("wave", "คลื่น", C_FUN) { p, _ -> mapOf("wave" to .05f * p, "waveF" to 14f, "blur" to .8f * p) }
        t("swirl", "หมุนวน", C_FUN) { p, _ -> mapOf("swirl" to 8f * p, "zoom" to .6f * p) }
        t("swirl_flash", "หมุนวนแฟลช", C_FUN) { p, _ -> mapOf("swirl" to 5f * p, *dip(p, 1f, 1f, 1f, 3f)) }
        t("fisheye", "ฟิชอายเข้า", C_FUN) { p, _ -> mapOf("bulge" to 1.8f * p, "radial" to .8f * p) }
        t("shrink", "หดเล็ก", C_FUN) { p, _ -> mapOf("scl" to 1f - .95f * p, "border" to 1f) }
    }

    val all: List<TransPreset> get() = list
    private val byId by lazy { list.associateBy { it.id } }
    fun get(id: String): TransPreset? = byId[id]
}
