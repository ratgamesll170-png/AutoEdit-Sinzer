package com.sinzer.autoedit.ui

import android.graphics.Paint
import android.graphics.Typeface
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalViewConfiguration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import com.sinzer.autoedit.audio.AudioAnalysis
import com.sinzer.autoedit.audio.BeatMap
import com.sinzer.autoedit.audio.PEAK_MS
import com.sinzer.autoedit.catalog.FxCatalog
import com.sinzer.autoedit.media.Thumbs
import com.sinzer.autoedit.model.*
import com.sinzer.autoedit.vm.MainVM
import kotlinx.coroutines.delay
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

private class Hit(val span: Span, val zone: Int)   // zone 0 body, 1 left handle, 2 right handle

private fun trackColor(k: TrackKind) = when (k) {
    TrackKind.VIDEO -> Color(0xFF1F5FA8); TrackKind.OVERLAY -> Color(0xFF6A4CC0); TrackKind.AUDIO -> Color(0xFF14806E)
    TrackKind.TEXT -> Color(0xFFB8741A); TrackKind.STICKER -> Color(0xFFB0408C); TrackKind.EFFECT -> Color(0xFF7A3FD0)
}

private fun trackIcon(k: TrackKind) = when (k) {
    TrackKind.VIDEO -> "🎞"; TrackKind.OVERLAY -> "🖼"; TrackKind.AUDIO -> "♪"; TrackKind.TEXT -> "T"; TrackKind.STICKER -> "☺"; TrackKind.EFFECT -> "✨"
}

/**
 * Timeline with a fixed centre playhead (the content scrolls under it).
 * Gestures: drag empty area / ruler = scrub, tap = select, drag a SELECTED item = move, drag its white handles = trim,
 * two fingers = zoom, long drag on unselected item scrubs (select first, then move).
 */
@Composable
fun TimelineView(vm: MainVM, project: Project, analyses: Map<String, AudioAnalysis>, beats: BeatMap, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    val density = LocalDensity.current
    val slop = LocalViewConfiguration.current.touchSlop
    val playhead by vm.playhead.collectAsState()
    val selection by vm.selection.collectAsState()
    var pxPerSec by remember { mutableFloatStateOf(90f) }
    var thumbTick by remember { mutableIntStateOf(0) }

    val rulerH = with(density) { 26.dp.toPx() }
    val mainH = with(density) { 62.dp.toPx() }
    val rowH = with(density) { 40.dp.toPx() }
    val gap = with(density) { 3.dp.toPx() }
    val handleW = with(density) { 14.dp.toPx() }
    val tracks = project.tracks
    val rowTops = remember(tracks) { var y = rulerH; tracks.map { t -> val top = y; y += (if (t.kind == TrackKind.VIDEO) mainH else rowH) + gap; top } }
    val rowHeights = tracks.map { if (it.kind == TrackKind.VIDEO) mainH else rowH }
    val totalH = (rowTops.lastOrNull() ?: rulerH) + (rowHeights.lastOrNull() ?: rowH) + gap

    val projectS by rememberUpdatedState(project)
    val playS by rememberUpdatedState(playhead)
    val selS by rememberUpdatedState(selection)
    val pxS by rememberUpdatedState(pxPerSec)
    val beatsS by rememberUpdatedState(beats)

    // thumbnails for what is visible (loaded in background; never blocks drawing)
    LaunchedEffect(project.clips, project.assets, pxPerSec, playhead / 800) {
        val win = 60_000f / pxPerSec * 1000f * 0.5f + 4000f
        val from = playhead - win; val to = playhead + win
        var n = 0
        for (c in project.clips) {
            val a = project.asset(c.assetId) ?: continue
            if (a.type == MediaType.AUDIO || c.audioOnly || c.startMs > to || c.endMs() < from) continue
            val tileMs = (mainH / (pxPerSec / 1000f) * (if (a.height > 0) a.width.toFloat() / a.height else 1.7f)).toLong().coerceAtLeast(300)
            var t = c.startMs
            while (t < c.endMs() && n < 60) {
                if (t + tileMs >= from && t <= to) {
                    val src = sourceAtLocal(c, t - c.startMs + tileMs / 2)
                    if (Thumbs.peek(a, src, 96) == null) { Thumbs.load(ctx, a, src, 96); thumbTick++; n++ }
                }
                t += tileMs
            }
        }
    }

    val paintText = remember { Paint(Paint.ANTI_ALIAS_FLAG).apply { color = android.graphics.Color.WHITE; typeface = Typeface.DEFAULT_BOLD } }
    var menuTrack by remember { mutableStateOf<String?>(null) }

    Row(modifier.background(Color(0xFF0B1128)).verticalScroll(rememberScrollState())) {
        // track labels / switches
        Column(Modifier.width(38.dp)) {
            Spacer(Modifier.height(with(density) { rulerH.toDp() }))
            tracks.forEachIndexed { i, t ->
                Box(Modifier.height(with(density) { (rowHeights[i] + gap).toDp() }).fillMaxWidth().clickable { menuTrack = t.id }, contentAlignment = Alignment.Center) {
                    Text(trackIcon(t.kind) + (if (t.locked) "🔒" else "") + (if (t.hidden) "🚫" else "") + (if (t.muted) "🔇" else ""), fontSize = 11.sp, color = Color.White)
                    DropdownMenu(expanded = menuTrack == t.id, onDismissRequest = { menuTrack = null }) {
                        DropdownMenuItem(text = { Text(t.name, color = NeonBlue) }, onClick = {})
                        DropdownMenuItem(text = { Text(if (t.locked) "ปลดล็อกแทร็ก" else "ล็อกแทร็ก") }, onClick = { vm.updateTrack(t.id) { it.copy(locked = !it.locked) }; menuTrack = null })
                        DropdownMenuItem(text = { Text(if (t.hidden) "แสดงแทร็ก" else "ซ่อนแทร็ก") }, onClick = { vm.updateTrack(t.id) { it.copy(hidden = !it.hidden) }; menuTrack = null })
                        if (t.kind == TrackKind.AUDIO || t.kind == TrackKind.VIDEO)
                            DropdownMenuItem(text = { Text(if (t.muted) "เปิดเสียงแทร็ก" else "ปิดเสียงแทร็ก") }, onClick = { vm.updateTrack(t.id) { it.copy(muted = !it.muted) }; menuTrack = null })
                    }
                }
            }
        }

        Box(Modifier.weight(1f).height(with(density) { totalH.toDp() })) {
            Canvas(
                Modifier.fillMaxSize().pointerInput(Unit) {
                    awaitEachGesture {
                        val down = awaitFirstDown(requireUnconsumed = false)
                        val w = size.width.toFloat(); val cx = w / 2f
                        fun pxMs() = pxS / 1000f
                        fun timeAt(x: Float) = (playS + ((x - cx) / pxMs()).toLong())
                        fun xOf(t: Long) = cx + (t - playS) * pxMs()
                        fun hit(pos: Offset): Hit? {
                            val p = projectS
                            for ((i, tr) in p.tracks.withIndex()) {
                                val top = rowTops[i]
                                if (pos.y < top || pos.y > top + rowHeights[i]) continue
                                val spans = Ops.spans(p).filter { it.trackId == tr.id }
                                for (s in spans) {
                                    val x0 = xOf(s.start); val x1 = xOf(s.end)
                                    if (pos.x in x0..x1) {
                                        val sel = selS == s.sel
                                        val zone = if (sel && pos.x - x0 < handleW) 1 else if (sel && x1 - pos.x < handleW) 2 else 0
                                        return Hit(s, zone)
                                    }
                                }
                            }
                            return null
                        }
                        val startPos = down.position
                        val h = hit(startPos)
                        var mode = 0; var last = startPos
                        var origStart = h?.span?.start ?: 0L
                        val selected = h != null && selS == h.span.sel
                        val locked = h != null && projectS.track(h.span.trackId)?.locked == true
                        var moved = false
                        var gestureOpen = false
                        while (true) {
                            val ev = awaitPointerEvent()
                            val pressed = ev.changes.filter { it.pressed }
                            if (pressed.size >= 2) {
                                if (gestureOpen) { vm.endGesture(); gestureOpen = false }
                                mode = 5; moved = true
                                val z = ev.calculateZoom()
                                if (z != 1f) pxPerSec = (pxPerSec * z).coerceIn(15f, 800f)
                                ev.changes.forEach { it.consume() }
                                continue
                            }
                            val c = ev.changes.firstOrNull() ?: break
                            if (mode == 5) { if (!c.pressed) break else { last = c.position; continue } }
                            val dx = c.position.x - last.x
                            if (mode == 0 && !moved && (c.position - startPos).getDistance() > slop) {
                                moved = true
                                mode = when {
                                    h != null && selected && !locked && h.zone == 1 -> 3
                                    h != null && selected && !locked && h.zone == 2 -> 4
                                    h != null && selected && !locked -> 2
                                    else -> 1
                                }
                                if (mode == 1) vm.pause()
                                if (mode in 2..4) { vm.beginGesture(); gestureOpen = true }
                                last = c.position
                                c.consume(); if (!c.pressed) break; continue
                            }
                            if (mode != 0) {
                                val p = projectS
                                when (mode) {
                                    1 -> vm.seek(((playS - (c.position.x - last.x) / pxMs()).toLong()).coerceIn(0L, p.endMs() + 5000))
                                    2 -> {
                                        val s = h!!.span; val len = s.end - s.start
                                        val raw = origStart + ((c.position.x - startPos.x) / pxMs()).toLong()
                                        val snapped = if (p.snap) Ops.snapAll(p, raw, len, playS, beatsS.beatsMs, (14f / pxMs()).toLong(), s.sel) else raw
                                        val row = rowTops.indexOfLast { c.position.y >= it }
                                        val target = p.tracks.getOrNull(row)?.takeIf { it.kind == p.track(s.trackId)?.kind && !it.locked && it.kind != TrackKind.VIDEO }?.id
                                        vm.move(s.sel, snapped.coerceAtLeast(0), target)
                                    }
                                    3, 4 -> {
                                        val s = Ops.span(p, h!!.span.sel)
                                        if (s != null) {
                                            var d = (dx / pxMs()).toLong()
                                            if (p.snap && d != 0L) {
                                                val edge = if (mode == 3) s.start else s.end
                                                val snapped = Ops.snap(p, edge + d, playS, beatsS.beatsMs, (12f / pxMs()).toLong(), s.sel)
                                                d = snapped - edge
                                            }
                                            if (d != 0L) vm.trim(s.sel, if (mode == 3) 0 else 1, d)
                                        }
                                    }
                                }
                                last = c.position
                                c.consume()
                            }
                            if (!c.pressed) break
                        }
                        if (gestureOpen) vm.endGesture()
                        if (!moved) {
                            if (startPos.y < rulerH) vm.seek(timeAt(startPos.x).coerceAtLeast(0))
                            else vm.selection.value = h?.span?.sel
                        }
                    }
                },
            ) {
                val w = size.width; val cx = w / 2f
                val pxMs = pxPerSec / 1000f
                fun xOf(t: Long) = cx + (t - playhead) * pxMs
                val tickRead = thumbTick   // reading the state makes the canvas redraw when new thumbnails arrive
                val tFrom = playhead - (cx / pxMs).toLong() - 500; val tTo = playhead + (cx / pxMs).toLong() + 500

                // ruler
                val steps = listOf(500L, 1000L, 2000L, 5000L, 10000L, 30000L, 60000L)
                val step = steps.firstOrNull { it * pxMs >= 70f } ?: 60000L
                var t = (max(0L, tFrom) / step) * step
                drawIntoCanvas { cv ->
                    paintText.textSize = 9.sp.toPx(); paintText.color = android.graphics.Color.GRAY
                    while (t < tTo) {
                        val x = xOf(t)
                        cv.nativeCanvas.drawText("%d:%02d".format(t / 60000, t / 1000 % 60) + if (step < 1000) ".5" else "", x + 3f, rulerH - 9f, paintText)
                        drawLine(Color(0xFF55608A), Offset(x, rulerH - 8f), Offset(x, rulerH), 1.5f)
                        t += step
                    }
                }

                // rows
                tracks.forEachIndexed { i, tr ->
                    val top = rowTops[i]; val rh = rowHeights[i]
                    drawRect(Color(0xFF0F1735), Offset(0f, top), Size(w, rh))
                }
                // beat lines
                if (beats.beatsMs.isNotEmpty()) {
                    val i0 = max(0, beats.lastIndex(tFrom))
                    var i = i0
                    while (i < beats.beatsMs.size && beats.beatsMs[i] <= tTo) {
                        val x = xOf(beats.beatsMs[i]); val a = 0.18f + 0.4f * beats.strength.getOrElse(i) { 0.5f }
                        drawLine(NeonPurple.copy(alpha = a), Offset(x, rulerH), Offset(x, totalH), 1.2f)
                        i++
                    }
                }
                val peaksFor = { c: Clip -> analyses[c.assetId]?.peaks }
                for (s in Ops.spans(project)) {
                    if (s.end < tFrom || s.start > tTo) continue
                    val ti = tracks.indexOfFirst { it.id == s.trackId }; if (ti < 0) continue
                    val tr = tracks[ti]; val top = rowTops[ti] + 2f; val rh = rowHeights[ti] - 4f
                    val x0 = xOf(s.start); val x1 = xOf(s.end)
                    val dim = if (tr.hidden) 0.35f else 1f
                    val base = trackColor(tr.kind).copy(alpha = dim)
                    drawRoundRect(base, Offset(x0, top), Size(max(2f, x1 - x0), rh), CornerRadius(8f))
                    drawIntoCanvas { cv ->
                        val nc = cv.nativeCanvas
                        nc.save(); nc.clipRect(max(0f, x0), top, min(w, x1), top + rh)
                        when (s.sel.kind) {
                            ItemKind.CLIP -> {
                                val c = project.clips.first { it.id == s.sel.id }; val a = project.asset(c.assetId)
                                if (a != null && !c.audioOnly && a.type != MediaType.AUDIO) {
                                    val tileW = (rh * (if (a.height > 0) a.width.toFloat() / a.height else 1.7f)).coerceIn(40f, 400f)
                                    var x = x0
                                    while (x < x1 && x < w) {
                                        if (x + tileW > 0) {
                                            val srcMs = sourceAtLocal(c, ((x + tileW / 2 - x0) / pxMs).toLong())
                                            val bmp = Thumbs.peek(a, srcMs, 96)
                                            if (bmp != null) nc.drawBitmap(bmp, android.graphics.Rect(0, 0, bmp.width, bmp.height), android.graphics.RectF(x, top, x + tileW, top + rh), null)
                                        }
                                        x += tileW
                                    }
                                } else {
                                    val pk = peaksFor(c)
                                    if (pk != null) {
                                        val lp = Paint().apply { color = android.graphics.Color.argb(230, 150, 255, 220); strokeWidth = 2f }
                                        var x = max(0f, x0); val mid = top + rh / 2
                                        while (x < min(w, x1)) {
                                            val localMs = ((x - x0) / pxMs).toLong()
                                            val idx = (sourceAtLocal(c, localMs) / PEAK_MS).toInt()
                                            val v = pk.getOrElse(idx) { 0 } / 100f
                                            nc.drawLine(x, mid - v * rh * 0.46f, x, mid + v * rh * 0.46f, lp)
                                            x += 3f
                                        }
                                    }
                                }
                            }
                            else -> {}
                        }
                        // label
                        val label = when (s.sel.kind) {
                            ItemKind.CLIP -> project.clips.first { it.id == s.sel.id }.let { c -> (project.asset(c.assetId)?.name ?: "?") + (if (c.speedCurve.isNotEmpty()) "  ⚡ramp" else if (c.speed != 1f) "  ×%.2f".format(c.speed) else "") + (if (c.audioOnly) " (เสียง)" else "") }
                            ItemKind.TEXT -> "T  " + project.texts.first { it.id == s.sel.id }.text.replace("\n", " ")
                            ItemKind.STICKER -> project.stickers.first { it.id == s.sel.id }.let { it.emoji ?: "🖼" }
                            ItemKind.FX -> "✨ " + (FxCatalog.get(project.fxItems.first { it.id == s.sel.id }.fx.presetId)?.nameTh ?: "")
                        }
                        paintText.textSize = 10.sp.toPx(); paintText.color = android.graphics.Color.WHITE
                        paintText.setShadowLayer(4f, 0f, 0f, android.graphics.Color.BLACK)
                        nc.drawText(label, max(x0, 0f) + 8f, top + 14.sp.toPx(), paintText)
                        paintText.clearShadowLayer()
                        nc.restore()
                    }
                    // transition marker
                    if (s.sel.kind == ItemKind.CLIP) project.clips.firstOrNull { it.id == s.sel.id }?.transition?.let {
                        val cxm = x1; val cy = top + rh / 2
                        val path = Path().apply { moveTo(cxm, cy - 9f); lineTo(cxm + 9f, cy); lineTo(cxm, cy + 9f); lineTo(cxm - 9f, cy); close() }
                        drawPath(path, Color.White); drawPath(path, NeonBlue, style = Stroke(2f))
                    }
                    if (selection == s.sel) {
                        drawRoundRect(Color.White, Offset(x0, top), Size(max(2f, x1 - x0), rh), CornerRadius(8f), style = Stroke(3f))
                        if (!tr.locked) {
                            drawRoundRect(Color.White, Offset(x0, top + rh * 0.2f), Size(7f, rh * 0.6f), CornerRadius(4f))
                            drawRoundRect(Color.White, Offset(x1 - 7f, top + rh * 0.2f), Size(7f, rh * 0.6f), CornerRadius(4f))
                        }
                    }
                }
                // playhead
                drawLine(Color.White, Offset(cx, 0f), Offset(cx, totalH), 2.5f)
                val tri = Path().apply { moveTo(cx - 8f, 0f); lineTo(cx + 8f, 0f); lineTo(cx, 12f); close() }
                drawPath(tri, Color.White)
            }
        }
    }
}
