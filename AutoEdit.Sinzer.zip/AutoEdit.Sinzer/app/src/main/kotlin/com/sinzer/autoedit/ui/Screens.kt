package com.sinzer.autoedit.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.util.UnstableApi
import com.sinzer.autoedit.catalog.Help
import com.sinzer.autoedit.data.ProjectEntity
import com.sinzer.autoedit.media.MediaProbe
import com.sinzer.autoedit.model.Aspect
import com.sinzer.autoedit.vm.MainVM
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ScreenScaffold(title: String, onBack: () -> Unit, actions: @Composable RowScope.() -> Unit = {}, content: @Composable ColumnScope.() -> Unit) {
    Scaffold(containerColor = Bg, topBar = {
        TopAppBar(title = { Text(title, fontWeight = FontWeight.Bold) }, navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, "กลับ") } },
            actions = actions, colors = TopAppBarDefaults.topAppBarColors(containerColor = Bg, titleContentColor = Color.White, navigationIconContentColor = Color.White, actionIconContentColor = Color.White))
    }) { pad -> Column(Modifier.padding(pad).fillMaxSize().padding(horizontal = 16.dp), content = content) }
}

private fun fmtDate(t: Long) = SimpleDateFormat("d MMM yy HH:mm", Locale("th")).format(Date(t))

// ------------------------------------------------------------------ HOME
@Composable
fun HomeScreen(vm: MainVM, projects: List<ProjectEntity>, onNew: (Boolean) -> Unit, onOpen: (String) -> Unit, onLibrary: () -> Unit, onSettings: () -> Unit, onHelp: () -> Unit) {
    Column(Modifier.fillMaxSize().background(Bg).verticalScroll(rememberScrollState()).padding(20.dp)) {
        Spacer(Modifier.height(24.dp))
        Text("⚡ FlashCut AI", style = TextStyle(brush = NeonBrush, fontSize = 34.sp, fontWeight = FontWeight.ExtraBold))
        Text("ตัดต่อวิดีโอด้วย AI ตัดตามจังหวะเพลง บนมือถือ", color = TextDim, fontSize = 14.sp)
        Spacer(Modifier.height(24.dp))
        NeonButton("＋ โปรเจกต์ใหม่", Modifier.fillMaxWidth()) { onNew(false) }
        Spacer(Modifier.height(10.dp))
        OutlinedButton(onClick = { onNew(true) }, Modifier.fillMaxWidth().height(48.dp)) { Text("✨ AI Auto Edit ด่วน: เลือกคลิป + เพลง แล้วกดปุ่มเดียว") }
        Spacer(Modifier.height(24.dp))
        Row(verticalAlignment = Alignment.CenterVertically) { Text("โปรเจกต์ล่าสุด", fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f)); TextButton(onClick = onLibrary) { Text("ดูทั้งหมด") } }
        if (projects.isEmpty()) Text("ยังไม่มีโปรเจกต์ เริ่มสร้างอันแรกได้เลย", color = TextDim, fontSize = 13.sp)
        projects.take(4).forEach { e -> ProjectRow(e) { onOpen(e.id) } }
        Spacer(Modifier.height(20.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlinedButton(onClick = onHelp, Modifier.weight(1f)) { Text("❓ ศูนย์ช่วยเหลือ") }
            OutlinedButton(onClick = onSettings, Modifier.weight(1f)) { Text("⚙ ตั้งค่า") }
        }
        Spacer(Modifier.height(16.dp))
        HelpIcon("home")
    }
}

@Composable
private fun ProjectRow(e: ProjectEntity, trailing: @Composable () -> Unit = {}, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp).clip(RoundedCornerShape(14.dp)).background(Surface1).clickable(onClick = onClick).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(e.name, fontWeight = FontWeight.Bold, maxLines = 1)
            Text("${fmtDate(e.updatedAt)} · ${e.clipCount} คลิป · ${e.durationMs / 1000} วินาที", fontSize = 12.sp, color = TextDim)
        }
        trailing()
    }
}

// ------------------------------------------------------------------ NEW PROJECT / IMPORT
@Composable
fun NewProjectScreen(vm: MainVM, auto: Boolean, onBack: () -> Unit, onCreated: (String?) -> Unit) {
    var name by remember { mutableStateOf("โปรเจกต์ ${SimpleDateFormat("d MMM HH:mm", Locale("th")).format(Date())}") }
    var aspect by remember { mutableStateOf(Aspect.R9_16) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        vm.newProject(name, aspect)
        if (uris.isNotEmpty()) vm.importMedia(uris)
        onCreated(if (auto) "AUTO" else if (uris.isEmpty()) "MEDIA" else null)
    }
    ScreenScaffold(if (auto) "AI Auto Edit ด่วน" else "โปรเจกต์ใหม่", onBack) {
        OutlinedTextField(name, { name = it }, Modifier.fillMaxWidth(), label = { Text("ชื่อโปรเจกต์") }, singleLine = true)
        Spacer(Modifier.height(12.dp))
        Row(verticalAlignment = Alignment.CenterVertically) { Text("อัตราส่วนภาพ", color = TextDim); HelpIcon("aspect") }
        ChipRow(Aspect.values().map { it.label }, aspect.ordinal) { aspect = Aspect.values()[it] }
        Spacer(Modifier.height(16.dp))
        Text(if (auto) "เลือกวิดีโอ รูปภาพ และไฟล์เพลง (เลือกพร้อมกันได้หลายไฟล์) แล้วระบบจะพาไปเลือกสไตล์ AI" else "เลือกวิดีโอ รูปภาพ หรือเพลงจากเครื่อง (ไม่เลือกก็ได้ เพิ่มทีหลังได้)", color = TextDim, fontSize = 13.sp)
        Spacer(Modifier.height(8.dp))
        NeonButton("📁 เลือกไฟล์จากเครื่อง", Modifier.fillMaxWidth()) { picker.launch(MediaProbe.PICK_TYPES) }
        if (!auto) { Spacer(Modifier.height(8.dp)); OutlinedButton(onClick = { vm.newProject(name, aspect); onCreated(null) }, Modifier.fillMaxWidth()) { Text("สร้างโปรเจกต์เปล่า") } }
        Spacer(Modifier.height(12.dp))
        Text("ใช้ตัวเลือกไฟล์ของ Android (ไม่ต้องขอสิทธิ์เข้าถึงที่เก็บข้อมูลทั้งหมด) · ไฟล์ต้นฉบับไม่ถูกแก้ไข · ถ้าไฟล์เล่นไม่ได้ จะแจ้งสาเหตุให้ทราบ", fontSize = 12.sp, color = TextDim)
    }
}

// ------------------------------------------------------------------ LIBRARY
@Composable
fun LibraryScreen(vm: MainVM, projects: List<ProjectEntity>, onBack: () -> Unit, onOpen: (String) -> Unit) {
    var menu by remember { mutableStateOf<ProjectEntity?>(null) }
    var rename by remember { mutableStateOf<ProjectEntity?>(null) }
    var confirmDelete by remember { mutableStateOf<ProjectEntity?>(null) }
    ScreenScaffold("โปรเจกต์ของฉัน", onBack, actions = { HelpIcon("project") }) {
        if (projects.isEmpty()) Text("ยังไม่มีโปรเจกต์", color = TextDim, modifier = Modifier.padding(top = 20.dp))
        LazyColumn { items(projects, key = { it.id }) { e ->
            Box { ProjectRow(e, { IconButton(onClick = { menu = e }) { Icon(Icons.Filled.MoreVert, "เมนู") } }) { onOpen(e.id) }
                DropdownMenu(menu?.id == e.id, { menu = null }) {
                    DropdownMenuItem(text = { Text("เปิด") }, onClick = { menu = null; onOpen(e.id) })
                    DropdownMenuItem(text = { Text("เปลี่ยนชื่อ") }, onClick = { menu = null; rename = e })
                    DropdownMenuItem(text = { Text("ทำสำเนา") }, onClick = { menu = null; vm.duplicateProject(e.id, e.name + " (สำเนา)") })
                    DropdownMenuItem(text = { Text("ลบ", color = Danger) }, onClick = { menu = null; confirmDelete = e })
                } }
        } }
    }
    rename?.let { e ->
        var t by remember(e.id) { mutableStateOf(e.name) }
        AlertDialog(onDismissRequest = { rename = null }, containerColor = Surface1, title = { Text("เปลี่ยนชื่อโปรเจกต์") }, text = { OutlinedTextField(t, { t = it }, singleLine = true) },
            confirmButton = { TextButton(onClick = { if (t.isNotBlank()) vm.renameProject(e.id, t.trim()); rename = null }) { Text("บันทึก") } },
            dismissButton = { TextButton(onClick = { rename = null }) { Text("ยกเลิก") } })
    }
    confirmDelete?.let { e ->
        AlertDialog(onDismissRequest = { confirmDelete = null }, containerColor = Surface1, title = { Text("ลบโปรเจกต์?") },
            text = { Text("ลบ “${e.name}” ถาวร (ไฟล์วิดีโอ/เพลงต้นฉบับในเครื่องไม่ถูกลบ)") },
            confirmButton = { TextButton(onClick = { vm.deleteProject(e.id); confirmDelete = null }) { Text("ลบ", color = Danger) } },
            dismissButton = { TextButton(onClick = { confirmDelete = null }) { Text("ยกเลิก") } })
    }
}

// ------------------------------------------------------------------ SETTINGS
@OptIn(UnstableApi::class)
@Composable
fun SettingsScreen(vm: MainVM, onBack: () -> Unit) {
    val s by vm.settings.collectAsState()
    val scope = rememberCoroutineScope()
    var key by remember(s.openAiKey) { mutableStateOf(s.openAiKey) }
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val folder = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { u ->
        if (u != null) { runCatching { ctx.contentResolver.takePersistableUriPermission(u, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION or android.content.Intent.FLAG_GRANT_WRITE_URI_PERMISSION) }
            scope.launchSet { vm.settingsStore.setSaveFolder(u.toString()) } }
    }
    ScreenScaffold("ตั้งค่า", onBack, actions = { HelpIcon("settings") }) {
        Column(Modifier.verticalScroll(rememberScrollState())) {
            SectionTitle("คุณภาพ Preview", "preview_quality")
            ChipRow(listOf("ต่ำ 360p (ลื่นสุด)", "กลาง 540p", "สูง 720p"), listOf(360, 540, 720).indexOf(s.previewHeight)) { i -> scope.launchSet { vm.settingsStore.setPreviewHeight(listOf(360, 540, 720)[i]) } }
            Text("ถ้าพรีวิวกระตุก ให้ลดคุณภาพ Preview ไม่กระทบคุณภาพตอน Export", fontSize = 12.sp, color = TextDim)
            SwitchRow("บันทึกอัตโนมัติ", s.autoSave) { v -> scope.launchSet { vm.settingsStore.setAutoSave(v) } }
            SwitchRow("เปิดหน้าจอค้างไว้ระหว่าง Export", s.keepScreenOnExport) { v -> scope.launchSet { vm.settingsStore.setKeepOn(v) } }
            SectionTitle("โฟลเดอร์บันทึกวิดีโอ")
            Text(if (s.saveFolderUri.isBlank()) "ค่าเริ่มต้น: Movies/FlashCutAI ในแกลเลอรี" else "เลือกแล้ว: ${android.net.Uri.parse(s.saveFolderUri).lastPathSegment}", fontSize = 13.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { folder.launch(null) }) { Text("เลือกโฟลเดอร์") }
                if (s.saveFolderUri.isNotBlank()) TextButton(onClick = { scope.launchSet { vm.settingsStore.setSaveFolder("") } }) { Text("ใช้ค่าเริ่มต้น") }
            }
            SectionTitle("คำบรรยายอัตโนมัติ (บริการภายนอก)")
            Text(com.sinzer.autoedit.ai.WhisperClient.PRICE_NOTE, fontSize = 12.sp, color = TextDim)
            OutlinedTextField(key, { key = it }, Modifier.fillMaxWidth(), label = { Text("OpenAI API Key") }, singleLine = true, visualTransformation = PasswordVisualTransformation())
            Row { Button(onClick = { scope.launchSet { vm.settingsStore.setOpenAiKey(key) }; vm.toast("บันทึก API Key แล้ว") }) { Text("บันทึกคีย์") }
                Spacer(Modifier.width(8.dp)); TextButton(onClick = { key = ""; scope.launchSet { vm.settingsStore.setOpenAiKey("") } }) { Text("ลบคีย์") } }
            Text("คีย์เก็บในเครื่องนี้เท่านั้น ไม่มีการส่งไปที่อื่นนอกจาก OpenAI เมื่อกดสร้างคำบรรยาย", fontSize = 11.sp, color = TextDim)
            SectionTitle("คำแนะนำ")
            OutlinedButton(onClick = { scope.launchSet { vm.settingsStore.resetTips() }; vm.toast("จะแสดงคำแนะนำการใช้งานครั้งแรกอีกครั้ง") }) { Text("แสดงคำแนะนำครั้งแรกอีกรอบ") }
            SectionTitle("เกี่ยวกับ")
            Text("FlashCut AI 0.1.0 (เวอร์ชันแรก — ดูรายการฟีเจอร์ที่ใช้ได้/ยังไม่มีใน README_TH.md)", fontSize = 12.sp, color = TextDim)
            Spacer(Modifier.height(24.dp))
        }
    }
}

private fun kotlinx.coroutines.CoroutineScope.launchSet(block: suspend () -> Unit) { launch { block() } }

// ------------------------------------------------------------------ HELP CENTER
@Composable
fun HelpScreen(onBack: () -> Unit) {
    var q by remember { mutableStateOf("") }
    var open by remember { mutableStateOf<String?>(null) }
    ScreenScaffold("ศูนย์ช่วยเหลือ", onBack) {
        OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth(), label = { Text("ค้นหาเมนู") }, singleLine = true)
        LazyColumn {
            items(Help.all.filter { q.isBlank() || it.title.contains(q, true) || it.text.contains(q, true) }, key = { it.key }) { h ->
                Column(Modifier.fillMaxWidth().padding(vertical = 3.dp).clip(RoundedCornerShape(12.dp)).background(Surface1).clickable { open = if (open == h.key) null else h.key }.padding(12.dp)) {
                    Text(h.title, fontWeight = FontWeight.Bold)
                    if (open == h.key) Text(h.text, Modifier.padding(top = 4.dp), fontSize = 13.sp, color = Color(0xFFCBD3EE))
                }
            }
        }
    }
}
