package com.sinzer.autoedit.catalog

import android.content.Context
import android.graphics.Typeface
import android.net.Uri
import com.sinzer.autoedit.media.MediaProbe
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * Font catalog. Every entry is a real family from Google Fonts (SIL Open Font License, free for commercial use).
 * The font FILES are not bundled in the APK: they are downloaded on demand (over HTTPS, free) from Google Fonts
 * and stored in the app's private storage. A font that is not downloaded is shown as "not installed" and can never be
 * picked silently. Users can also import their own .ttf/.otf files.
 */
data class FontDef(val id: String, val family: String, val cat: String, val thai: Boolean = false)

object FontCatalog {
    const val CAT_BOLD = "เท่าและดุดัน"; const val CAT_GAMING = "Gaming"; const val CAT_ANIME = "Anime"
    const val CAT_CUTE = "Cute"; const val CAT_MIN = "Minimal"; const val CAT_CINE = "Cinematic"
    const val CAT_HAND = "Handwriting"; const val CAT_NEON = "Neon"; const val CAT_FUTURE = "Futuristic"
    const val CAT_HORROR = "Horror"; const val CAT_RETRO = "Retro"; const val CAT_ELEGANT = "Elegant"
    const val CAT_THAI = "Thai Fonts"
    val categories = listOf(CAT_THAI, CAT_BOLD, CAT_GAMING, CAT_ANIME, CAT_CUTE, CAT_MIN, CAT_CINE, CAT_HAND, CAT_NEON, CAT_FUTURE, CAT_HORROR, CAT_RETRO, CAT_ELEGANT)

    private val list = ArrayList<FontDef>()
    private fun f(cat: String, thai: Boolean, vararg fam: String) = fam.forEach { list.add(FontDef("g:$it", it, cat, thai)) }

    val system = listOf(
        FontDef("sys:sans", "ฟอนต์ระบบ (Sans)", "System"), FontDef("sys:serif", "ฟอนต์ระบบ (Serif)", "System"),
        FontDef("sys:mono", "ฟอนต์ระบบ (Mono)", "System"), FontDef("sys:condensed", "ฟอนต์ระบบ (Condensed)", "System"),
        FontDef("sys:casual", "ฟอนต์ระบบ (Casual)", "System"), FontDef("sys:cursive", "ฟอนต์ระบบ (Cursive)", "System"),
    )

    init {
        f(CAT_THAI, true, "Kanit", "Prompt", "Sarabun", "Mitr", "Pridi", "Chakra Petch", "Noto Sans Thai", "Noto Serif Thai", "Itim", "Pattaya",
            "Krub", "Bai Jamjuree", "K2D", "KoHo", "Niramit", "Mali", "Sriracha", "Thasadith", "Trirong", "Taviraj", "Maitree", "Athiti",
            "Charm", "Charmonman", "Fahkwang", "Kodchasan", "Srisakdi", "Chonburi", "IBM Plex Sans Thai", "Anuphan", "Playpen Sans Thai")
        f(CAT_BOLD, false, "Bebas Neue", "Anton", "Oswald", "Black Ops One", "Russo One", "Teko", "Staatliches", "Fjalla One", "Archivo Black",
            "Alfa Slab One", "Bungee", "Passion One", "Squada One", "Big Shoulders Display")
        f(CAT_GAMING, false, "Orbitron", "Press Start 2P", "Audiowide", "Rajdhani", "Share Tech Mono", "VT323", "Bungee Inline", "Saira Stencil One",
            "Michroma", "Aldrich", "Exo 2", "Silkscreen")
        f(CAT_ANIME, false, "Dela Gothic One", "Rampart One", "Yusei Magic", "Potta One", "Reggae One", "Stick", "RocknRoll One", "Hachi Maru Pop",
            "Zen Maru Gothic", "M PLUS Rounded 1c", "Mochiy Pop One", "DotGothic16")
        f(CAT_CUTE, false, "Fredoka", "Baloo 2", "Pacifico", "Chewy", "Sniglet", "Lilita One", "Grand Hotel", "Gochi Hand", "Pangolin", "Kalam",
            "Patrick Hand", "Cherry Bomb One", "Gamja Flower")
        f(CAT_MIN, false, "Inter", "Poppins", "Montserrat", "Work Sans", "DM Sans", "Raleway", "Lato", "Roboto", "Open Sans", "Nunito", "Quicksand",
            "Josefin Sans", "Manrope", "Space Grotesk")
        f(CAT_CINE, false, "Cinzel", "Playfair Display", "Cormorant Garamond", "Marcellus", "Forum", "Bodoni Moda", "Abril Fatface", "Italiana",
            "Josefin Slab", "Tenor Sans", "Philosopher")
        f(CAT_HAND, false, "Caveat", "Dancing Script", "Satisfy", "Shadows Into Light", "Permanent Marker", "Reenie Beanie", "Homemade Apple",
            "Indie Flower", "Covered By Your Grace", "Rock Salt", "Sacramento", "Yellowtail", "Kaushan Script", "Marck Script")
        f(CAT_NEON, false, "Monoton", "Tilt Neon", "Neonderthaw", "Rubik Glitch", "Bungee Shade", "Gruppo", "Megrim", "Tourney")
        f(CAT_FUTURE, false, "Syncopate", "Zen Dots", "Iceland", "Electrolize", "Quantico", "Jura", "Nova Square", "Oxanium", "Ruslan Display",
            "Turret Road", "Tomorrow", "Chakra Petch")
        f(CAT_HORROR, false, "Creepster", "Nosifer", "Eater", "Butcherman", "Metal Mania", "Frijole", "Special Elite", "Griffy", "New Rocker",
            "Pirata One", "UnifrakturCook")
        f(CAT_RETRO, false, "Shrikhand", "Righteous", "Lobster", "Londrina Solid", "Rammetto One", "Bowlby One", "Chango", "Fascinate", "Limelight",
            "Poiret One", "Vast Shadow")
        f(CAT_ELEGANT, false, "Great Vibes", "Allura", "Parisienne", "Tangerine", "Alex Brush", "Libre Baskerville", "EB Garamond", "Lora",
            "Merriweather", "Crimson Text", "Spectral")
    }

    val all: List<FontDef> = list.distinctBy { it.id }
    fun find(id: String): FontDef? = all.firstOrNull { it.id == id } ?: system.firstOrNull { it.id == id }
}

object FontManager {
    private val cache = HashMap<String, Typeface>()
    private const val UA = "Mozilla/5.0 (Linux; U; Android 2.2; en-us; Nexus One Build/FRF91) AppleWebKit/533.1 (KHTML, like Gecko) Version/4.0 Mobile Safari/533.1"

    private fun dir(ctx: Context) = File(ctx.filesDir, "fonts").apply { mkdirs() }
    private fun fileFor(ctx: Context, id: String) = File(dir(ctx), id.replace(Regex("[^A-Za-z0-9]"), "_") + ".ttf")

    fun isInstalled(ctx: Context, id: String) = id.startsWith("sys:") || fileFor(ctx, id).exists()

    fun installedUserFonts(ctx: Context): List<FontDef> =
        dir(ctx).listFiles { f -> f.name.startsWith("u_") }?.map { FontDef("u:${it.nameWithoutExtension}", it.nameWithoutExtension.removePrefix("u_"), "My fonts") } ?: emptyList()

    /** Typeface for [id]; falls back to the system font when the file is missing so rendering never fails. */
    fun typeface(ctx: Context, id: String): Typeface = synchronized(cache) {
        cache.getOrPut(id) {
            when {
                id == "sys:serif" -> Typeface.SERIF
                id == "sys:mono" -> Typeface.MONOSPACE
                id == "sys:condensed" -> Typeface.create("sans-serif-condensed", Typeface.NORMAL)
                id == "sys:casual" -> Typeface.create("casual", Typeface.NORMAL)
                id == "sys:cursive" -> Typeface.create("cursive", Typeface.NORMAL)
                id.startsWith("sys:") -> Typeface.SANS_SERIF
                else -> {
                    val f = if (id.startsWith("u:")) File(dir(ctx), id.removePrefix("u:") + ".ttf") else fileFor(ctx, id)
                    if (f.exists()) runCatching { Typeface.createFromFile(f) }.getOrNull() ?: Typeface.SANS_SERIF else Typeface.SANS_SERIF
                }
            }
        }
    }

    /** Downloads the regular style of a Google Fonts family. Returns null on success or a Thai error message. */
    suspend fun download(ctx: Context, def: FontDef): String? = withContext(Dispatchers.IO) {
        try {
            val css = URL("https://fonts.googleapis.com/css?family=" + URLEncoder.encode(def.family, "UTF-8").replace("+", "+") + ":400").let { u ->
                (u.openConnection() as HttpURLConnection).run {
                    setRequestProperty("User-Agent", UA); connectTimeout = 15000; readTimeout = 20000
                    if (responseCode != 200) return@withContext "เซิร์ฟเวอร์ฟอนต์ตอบกลับผิดพลาด ($responseCode) สำหรับ ${def.family}"
                    inputStream.bufferedReader().readText()
                }
            }
            val url = Regex("url\\((https://[^)]+)\\)").find(css)?.groupValues?.get(1) ?: return@withContext "ไม่พบไฟล์ฟอนต์ ${def.family}"
            val tmp = File(dir(ctx), "tmp_${System.nanoTime()}")
            (URL(url).openConnection() as HttpURLConnection).run {
                connectTimeout = 15000; readTimeout = 30000
                if (responseCode != 200) return@withContext "ดาวน์โหลดไฟล์ฟอนต์ไม่สำเร็จ ($responseCode)"
                inputStream.use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
            }
            Typeface.createFromFile(tmp)       // throws if the file is not a valid font
            val dst = fileFor(ctx, def.id)
            if (dst.exists()) dst.delete()
            tmp.renameTo(dst)
            synchronized(cache) { cache.remove(def.id) }
            null
        } catch (e: java.net.UnknownHostException) { "ไม่มีอินเทอร์เน็ต ดาวน์โหลดฟอนต์ไม่ได้" }
        catch (e: Exception) { "ดาวน์โหลดฟอนต์ไม่สำเร็จ: ${e.message ?: "ข้อผิดพลาดไม่ทราบสาเหตุ"}" }
    }

    /** Imports a user supplied font file (the user is responsible for having the licence to use it). */
    suspend fun importFile(ctx: Context, uri: Uri): String? = withContext(Dispatchers.IO) {
        try {
            val name = MediaProbe.displayName(ctx, uri).substringBeforeLast('.').replace(Regex("[^A-Za-z0-9ก-๙_-]"), "_")
            val dst = File(dir(ctx), "u_$name.ttf")
            ctx.contentResolver.openInputStream(uri)?.use { i -> dst.outputStream().use { o -> i.copyTo(o) } } ?: return@withContext "เปิดไฟล์ฟอนต์ไม่ได้"
            runCatching { Typeface.createFromFile(dst) }.getOrElse { dst.delete(); return@withContext "ไฟล์นี้ไม่ใช่ฟอนต์ที่ใช้ได้ (.ttf/.otf)" }
            synchronized(cache) { cache.remove("u:u_$name") }
            null
        } catch (e: Exception) { "นำเข้าฟอนต์ไม่สำเร็จ: ${e.message}" }
    }
}
