package com.sinzer.autoedit

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.media3.common.util.UnstableApi
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.sinzer.autoedit.ui.*
import com.sinzer.autoedit.vm.MainVM

@UnstableApi
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { AppTheme { AppNav() } }
    }
}

@UnstableApi
@Composable
fun AppNav(vm: MainVM = viewModel()) {
    val nav = rememberNavController()
    val projects by vm.projects.collectAsState(initial = emptyList())
    NavHost(nav, startDestination = "home") {
        composable("home") {
            HomeScreen(vm, projects,
                onNew = { auto -> nav.navigate("new/$auto") },
                onOpen = { id -> vm.openById(id) { ok -> if (ok) nav.navigate("editor") } },
                onLibrary = { nav.navigate("projects") }, onSettings = { nav.navigate("settings") }, onHelp = { nav.navigate("help") })
        }
        composable("new/{auto}", arguments = listOf(navArgument("auto") { type = NavType.BoolType })) { e ->
            NewProjectScreen(vm, e.arguments?.getBoolean("auto") == true, { nav.popBackStack() }) { tool ->
                nav.navigate(if (tool == null) "editor" else "editor?tool=$tool") { popUpTo("home") }
            }
        }
        composable("projects") { LibraryScreen(vm, projects, { nav.popBackStack() }) { id -> vm.openById(id) { ok -> if (ok) nav.navigate("editor") } } }
        composable("settings") { SettingsScreen(vm) { nav.popBackStack() } }
        composable("help") { HelpScreen { nav.popBackStack() } }
        composable("editor?tool={tool}", arguments = listOf(navArgument("tool") { type = NavType.StringType; nullable = true; defaultValue = null })) { e ->
            EditorScreen(vm, e.arguments?.getString("tool"), onBack = { vm.closeProject(); nav.popBackStack("home", false) }, onExport = { nav.navigate("export") })
        }
        composable("export") { ExportScreen(vm) { nav.popBackStack() } }
    }
}
