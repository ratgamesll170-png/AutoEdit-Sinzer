package com.sinzer.autoedit.data

import android.content.Context
import androidx.room.*
import com.sinzer.autoedit.model.Project
import com.sinzer.autoedit.model.endMs
import kotlinx.coroutines.flow.Flow
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

@Entity(tableName = "projects")
data class ProjectEntity(
    @PrimaryKey val id: String,
    val name: String,
    val updatedAt: Long,
    val durationMs: Long,
    val clipCount: Int,
    val json: String,
)

@Dao
interface ProjectDao {
    @Query("SELECT id, name, updatedAt, durationMs, clipCount, '' AS json FROM projects ORDER BY updatedAt DESC")
    fun observeAll(): Flow<List<ProjectEntity>>

    @Query("SELECT * FROM projects WHERE id = :id")
    suspend fun get(id: String): ProjectEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(e: ProjectEntity)

    @Query("DELETE FROM projects WHERE id = :id")
    suspend fun delete(id: String)
}

@Database(entities = [ProjectEntity::class], version = 1, exportSchema = false)
abstract class AppDb : RoomDatabase() {
    abstract fun projects(): ProjectDao

    companion object {
        @Volatile private var inst: AppDb? = null
        fun get(ctx: Context): AppDb = inst ?: synchronized(this) {
            inst ?: Room.databaseBuilder(ctx.applicationContext, AppDb::class.java, "flashcut.db")
                .fallbackToDestructiveMigration().build().also { inst = it }
        }
    }
}

val AppJson = Json { ignoreUnknownKeys = true; encodeDefaults = true; isLenient = true }

class ProjectRepository(private val dao: ProjectDao) {
    fun observe() = dao.observeAll()

    suspend fun load(id: String): Project? = dao.get(id)?.let {
        runCatching { AppJson.decodeFromString<Project>(it.json) }.getOrNull()
    }

    suspend fun save(p: Project) {
        val saved = p.copy(updatedAt = System.currentTimeMillis())
        dao.upsert(ProjectEntity(saved.id, saved.name, saved.updatedAt, saved.endMsSafe(), saved.clips.size, AppJson.encodeToString(saved)))
    }

    suspend fun delete(id: String) = dao.delete(id)

    suspend fun duplicate(id: String, newName: String): Project? {
        val p = load(id) ?: return null
        val copy = p.copy(id = com.sinzer.autoedit.model.newId(), name = newName, createdAt = System.currentTimeMillis())
        save(copy); return copy
    }

    suspend fun rename(id: String, name: String) { load(id)?.let { save(it.copy(name = name)) } }

    private fun Project.endMsSafe(): Long = endMs()
}
