package com.sinzer.autoedit.render

import android.content.Context
import android.opengl.GLES20
import androidx.media3.common.GlEffect
import androidx.media3.common.GlShaderProgram
import androidx.media3.common.VideoFrameProcessingException
import androidx.media3.common.util.GlProgram
import androidx.media3.common.util.GlUtil
import androidx.media3.common.util.Size
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.BaseGlShaderProgram
import kotlin.math.min

/** Values for one rendered frame. [k] = overall strength (intensity x beat pulse x active); [params] override the static ones. */
class FxFrame(val k: Float, val params: Map<String, Float>)
fun interface FxDriver { fun frame(tUs: Long): FxFrame }

/**
 * One GPU shader that is *generated* per effect: only the code for the parameters an effect really uses is compiled in.
 * Parameter keys (all floats, 0 = off unless noted):
 *  geometry : zoom rot spin breath shake shakeHz bulge swirl wave waveF mirror(1-3) kal tile pix flipX flipY glitch vhs slideX slideY border
 *             tx ty scl(1) trot (clip transform)
 *  sampling : rgb rgbAng blur radial motion motionAng
 *  colour   : exposure bright contrast sat temp tint hi sh wh bl hue fade sepia mono invert poster duo car cag cab cbr cbg cbb
 *             glow glowThr edge edgeOnly vig grain scan sharpen leak
 *  overlays : flash strobe strobeAmt dip fr fg fb (flash colour, default white) bars wipeP wipeAng iris opac(1)
 */
object ShaderGen {
    val DEFAULTS = mapOf("scl" to 1f, "opac" to 1f, "fr" to 1f, "fg" to 1f, "fb" to 1f, "glowThr" to .55f, "waveF" to 20f, "shakeHz" to 20f)

    const val VERT = """
attribute vec4 aFramePosition;
varying vec2 vUv;
void main() {
  gl_Position = aFramePosition;
  vUv = aFramePosition.xy * 0.5 + 0.5;
}
"""

    fun withDeps(keys: Set<String>): List<String> {
        val k = keys.toMutableSet()
        if ("flash" in k || "strobe" in k || "dip" in k) { k.add("fr"); k.add("fg"); k.add("fb") }
        if ("duo" in k) k.addAll(listOf("car", "cag", "cab", "cbr", "cbg", "cbb"))
        if ("strobe" in k) k.add("strobeAmt")
        return k.sorted()
    }

    fun fragment(keysIn: Set<String>): String {
        val keys = withDeps(keysIn).toSet()
        fun has(k: String) = k in keys
        val sb = StringBuilder()
        sb.append("precision highp float;\nvarying vec2 vUv;\nuniform sampler2D uTexSampler;\nuniform float uTime;\nuniform float uAspect;\nuniform float uK;\nuniform float uCK;\n")
        keys.forEach { sb.append("uniform float u_").append(it).append(";\n") }
        sb.append("""
float hash(float n){return fract(sin(n*127.1)*43758.5453);}
float hash2(vec2 p){return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453);}
float n1(float x){float i=floor(x);float f=fract(x);f=f*f*(3.0-2.0*f);return mix(hash(i),hash(i+1.0),f);}
float luma(vec3 c){return dot(c,vec3(0.299,0.587,0.114));}
vec2 rot2(vec2 p,float a){float c=cos(a);float s=sin(a);return vec2(c*p.x-s*p.y,s*p.x+c*p.y);}
vec4 S(vec2 p){
  vec4 c=texture2D(uTexSampler,p);
""")
        if (has("rgb")) {
            val ang = if (has("rgbAng")) "radians(u_rgbAng)" else "0.0"
            sb.append("  vec2 d=vec2(cos($ang),sin($ang))*u_rgb*uK;\n  c.r=texture2D(uTexSampler,p+d).r;\n  c.b=texture2D(uTexSampler,p-d).b;\n")
        }
        sb.append("  return c;\n}\nvoid main(){\n  vec2 uv0=vUv;\n  vec2 uv=vUv;\n  float K=uK;\n")
        if (has("flash") || has("strobe") || has("dip")) sb.append("  vec3 FC=vec3(u_fr,u_fg,u_fb);\n")

        // ---------- geometry ----------
        if (has("flipX")) sb.append("  if(u_flipX>0.5) uv.x=1.0-uv.x;\n")
        if (has("flipY")) sb.append("  if(u_flipY>0.5) uv.y=1.0-uv.y;\n")
        if (has("mirror")) sb.append("  if(u_mirror>0.5){ if(u_mirror<1.5){ if(uv.x>0.5) uv.x=1.0-uv.x; } else if(u_mirror<2.5){ if(uv.y>0.5) uv.y=1.0-uv.y; } else { if(uv.x>0.5) uv.x=1.0-uv.x; if(uv.y>0.5) uv.y=1.0-uv.y; } }\n")
        if (has("kal")) sb.append("  if(u_kal>1.5){ vec2 q=uv-0.5; q.x*=uAspect; float a=atan(q.y,q.x); float r=length(q); float seg=6.2831853/u_kal; a=abs(mod(a,seg)-seg*0.5); q=r*vec2(cos(a),sin(a)); q.x/=uAspect; uv=q+0.5; }\n")
        if (has("tile")) sb.append("  if(u_tile>1.01){ uv=fract(uv*u_tile); }\n")
        if (has("pix")) sb.append("  if(u_pix>1.0){ vec2 g=vec2(u_pix,u_pix/uAspect); uv=(floor(uv*g)+0.5)/g; }\n")
        if (has("bulge")) sb.append("  { vec2 q=uv-0.5; q.x*=uAspect; float r=length(q); float f=1.0-u_bulge*K*(1.0-smoothstep(0.0,0.75,r)); q*=f; q.x/=uAspect; uv=q+0.5; }\n")
        if (has("swirl")) sb.append("  { vec2 q=uv-0.5; q.x*=uAspect; float r=length(q); float a=u_swirl*K*(1.0-smoothstep(0.0,0.8,r)); q=rot2(q,a); q.x/=uAspect; uv=q+0.5; }\n")
        if (has("wave")) { val f = if (has("waveF")) "u_waveF" else "20.0"
            sb.append("  uv.x+=sin(uv.y*$f+uTime*6.0)*u_wave*K;\n  uv.y+=cos(uv.x*$f*0.7+uTime*5.0)*u_wave*0.5*K;\n") }
        if (has("glitch")) sb.append("  { float bt=floor(uTime*18.0); float row=floor(uv.y*14.0+hash(bt)*10.0); float on=step(0.55,hash(row+bt*3.7)); uv.x+=(hash(row*1.3+bt)-0.5)*u_glitch*0.25*on*K; }\n")
        if (has("vhs")) sb.append("  uv.x+=sin(uv.y*80.0+uTime*8.0)*0.0015*u_vhs*K+(hash(floor(uTime*30.0))-0.5)*0.004*u_vhs*K*step(0.97,hash(floor(uv.y*60.0)+floor(uTime*20.0)));\n")
        if (has("shake")) { val hz = if (has("shakeHz")) "u_shakeHz" else "20.0"
            sb.append("  { float tt=uTime*$hz; vec2 o=vec2(n1(tt),n1(tt+17.3))-0.5; uv+=o*2.0*u_shake*K; }\n") }
        if (has("rot") || has("spin")) {
            val ang = listOfNotNull(if (has("rot")) "u_rot*K" else null, if (has("spin")) "u_spin*uTime*K" else null).joinToString("+")
            sb.append("  { vec2 q=uv-0.5; q.x*=uAspect; q=rot2(q,radians($ang)); q.x/=uAspect; uv=q+0.5; }\n")
        }
        if (has("zoom") || has("breath")) {
            val z = listOfNotNull("1.0", if (has("zoom")) "u_zoom*K" else null, if (has("breath")) "u_breath*K*sin(uTime*2.0)" else null).joinToString("+")
            sb.append("  { float z=max($z,0.05); uv=(uv-0.5)/z+0.5; }\n")
        }
        if (has("scl") || has("tx") || has("ty") || has("trot")) {
            val tx = if (has("tx")) "u_tx" else "0.0"; val ty = if (has("ty")) "u_ty" else "0.0"
            val tr = if (has("trot")) "u_trot" else "0.0"; val sc = if (has("scl")) "max(u_scl,0.01)" else "1.0"
            sb.append("  { vec2 q=uv-0.5-vec2($tx,$ty); q.x*=uAspect; q=rot2(q,-radians($tr)); q.x/=uAspect; uv=q/$sc+0.5; }\n")
        }
        if (has("slideX") || has("slideY")) sb.append("  uv-=vec2(${if (has("slideX")) "u_slideX" else "0.0"},${if (has("slideY")) "u_slideY" else "0.0"});\n")
        if (has("border")) sb.append("  bool outside=(u_border>0.5)&&(uv.x<0.0||uv.x>1.0||uv.y<0.0||uv.y>1.0);\n")

        // ---------- sampling ----------
        when {
            has("radial") -> sb.append("  vec3 acc=vec3(0.0);\n  for(int i=0;i<10;i++){ float s=1.0-u_radial*K*0.06*float(i); acc+=S((uv-0.5)*s+0.5).rgb; }\n  vec4 c=vec4(acc/10.0,1.0);\n")
            has("motion") -> { val ang = if (has("motionAng")) "radians(u_motionAng)" else "0.0"
                sb.append("  vec2 dir=vec2(cos($ang),sin($ang))*vec2(1.0,uAspect);\n  vec3 acc=vec3(0.0);\n  for(int i=0;i<12;i++){ float t=(float(i)/11.0-0.5)*u_motion*K*0.06; acc+=S(uv+dir*t).rgb; }\n  vec4 c=vec4(acc/12.0,1.0);\n") }
            has("blur") -> sb.append("  vec3 acc=S(uv).rgb;\n  for(int i=0;i<12;i++){ float a=float(i)*2.39996; float r=sqrt((float(i)+0.5)/12.0)*u_blur*K*0.006; acc+=S(uv+vec2(cos(a),sin(a))*r*vec2(1.0,uAspect)).rgb; }\n  vec4 c=vec4(acc/13.0,1.0);\n")
            else -> sb.append("  vec4 c=S(uv);\n")
        }
        sb.append("  vec3 base=c.rgb;\n  vec3 col=base;\n  vec2 px=vec2(1.0/(720.0*uAspect),1.0/720.0);\n")

        // ---------- colour ----------
        if (has("sharpen")) sb.append("  { vec3 n=(S(uv+vec2(px.x,0.0)).rgb+S(uv-vec2(px.x,0.0)).rgb+S(uv+vec2(0.0,px.y)).rgb+S(uv-vec2(0.0,px.y)).rgb)*0.25; col+=(col-n)*u_sharpen*1.5; }\n")
        if (has("exposure")) sb.append("  col*=pow(2.0,u_exposure);\n")
        if (has("bright")) sb.append("  col+=u_bright;\n")
        if (has("contrast")) sb.append("  col=(col-0.5)*(1.0+u_contrast)+0.5;\n")
        if (has("sh") || has("hi") || has("wh") || has("bl")) {
            sb.append("  { float l=luma(col);\n")
            if (has("sh")) sb.append("    col+=u_sh*0.25*(1.0-smoothstep(0.0,0.5,l));\n")
            if (has("hi")) sb.append("    col+=u_hi*0.25*smoothstep(0.5,1.0,l);\n")
            if (has("wh")) sb.append("    col+=u_wh*0.2*smoothstep(0.75,1.0,l);\n")
            if (has("bl")) sb.append("    col+=u_bl*0.2*(1.0-smoothstep(0.0,0.25,l));\n")
            sb.append("  }\n")
        }
        if (has("temp")) sb.append("  col.r+=u_temp*0.1; col.b-=u_temp*0.1;\n")
        if (has("tint")) sb.append("  col.g-=u_tint*0.08; col.r+=u_tint*0.03; col.b+=u_tint*0.03;\n")
        if (has("hue")) sb.append("  { float a=radians(u_hue); float cs=cos(a); float sn=sin(a); mat3 toYiq=mat3(0.299,0.596,0.211,0.587,-0.274,-0.523,0.114,-0.322,0.312); mat3 toRgb=mat3(1.0,1.0,1.0,0.956,-0.272,-1.106,0.621,-0.647,1.703); vec3 y=toYiq*col; y.yz=mat2(cs,sn,-sn,cs)*y.yz; col=toRgb*y; }\n")
        if (has("sat")) sb.append("  col=mix(vec3(luma(col)),col,1.0+u_sat);\n")
        if (has("fade")) sb.append("  col=col*(1.0-u_fade*0.6)+u_fade*0.6*0.35;\n")
        if (has("sepia")) sb.append("  col=mix(col,vec3(dot(col,vec3(0.393,0.769,0.189)),dot(col,vec3(0.349,0.686,0.168)),dot(col,vec3(0.272,0.534,0.131))),u_sepia);\n")
        if (has("mono")) sb.append("  col=mix(col,vec3(luma(col)),u_mono);\n")
        if (has("invert")) sb.append("  col=mix(col,1.0-col,u_invert);\n")
        if (has("poster")) sb.append("  col=floor(clamp(col,0.0,1.0)*u_poster+0.5)/u_poster;\n")
        if (has("duo")) sb.append("  { vec3 d=mix(vec3(u_car,u_cag,u_cab),vec3(u_cbr,u_cbg,u_cbb),clamp(luma(col),0.0,1.0)); col=mix(col,d,u_duo); }\n")
        if (has("glow")) { val thr = if (has("glowThr")) "u_glowThr" else "0.55"
            sb.append("  { vec3 g=vec3(0.0); for(int i=0;i<12;i++){ float a=float(i)*0.5236; float r=(mod(float(i),2.0)<0.5)?0.012:0.032; vec3 s=S(uv+vec2(cos(a),sin(a))*r*vec2(1.0,uAspect)).rgb; g+=max(s-vec3($thr),0.0); } col+=g/12.0*u_glow*2.5; }\n") }
        if (has("edge")) sb.append("""
  { float tl=luma(S(uv+px*vec2(-1.0,1.0)).rgb); float t=luma(S(uv+px*vec2(0.0,1.0)).rgb); float tr=luma(S(uv+px*vec2(1.0,1.0)).rgb);
    float l=luma(S(uv+px*vec2(-1.0,0.0)).rgb); float r=luma(S(uv+px*vec2(1.0,0.0)).rgb);
    float bl=luma(S(uv+px*vec2(-1.0,-1.0)).rgb); float b=luma(S(uv+px*vec2(0.0,-1.0)).rgb); float br=luma(S(uv+px*vec2(1.0,-1.0)).rgb);
    float gx=-tl-2.0*l-bl+tr+2.0*r+br; float gy=-tl-2.0*t-tr+bl+2.0*b+br;
    float e=smoothstep(0.12,0.5,sqrt(gx*gx+gy*gy));
""")
        if (has("edge")) { if (has("edgeOnly")) sb.append("    col=(u_edgeOnly>0.5)?vec3(e*u_edge):col*(1.0-e*u_edge);\n  }\n") else sb.append("    col=col*(1.0-e*u_edge);\n  }\n") }
        if (has("vig")) sb.append("  { float d=length((uv0-0.5)*vec2(uAspect*0.75,1.0)); col*=1.0-u_vig*smoothstep(0.35,0.95,d); }\n")
        if (has("grain")) sb.append("  col+=(hash2(uv0*vec2(uAspect,1.0)*500.0+fract(uTime)*37.0)-0.5)*u_grain;\n")
        if (has("scan")) sb.append("  col*=1.0-u_scan*0.4*step(0.5,fract(uv0.y*360.0));\n")
        if (has("leak")) sb.append("  { float x=uv0.x+sin(uTime*1.7)*0.3; vec3 lk=mix(vec3(1.0,0.35,0.1),vec3(1.0,0.8,0.3),uv0.y)*pow(max(0.0,1.0-abs(x-0.2)*1.8),2.0); col=1.0-(1.0-col)*(1.0-clamp(lk*u_leak,0.0,1.0)); }\n")
        sb.append("  vec3 rgb=mix(base,col,clamp(uCK,0.0,1.0));\n")

        // ---------- overlays / masks ----------
        if (has("flash")) sb.append("  rgb=mix(rgb,FC,clamp(u_flash*K,0.0,1.0));\n")
        if (has("strobe")) sb.append("  rgb=mix(rgb,FC,step(0.5,fract(uTime*u_strobe))*u_strobeAmt*K);\n")
        if (has("dip")) sb.append("  rgb=mix(rgb,FC,clamp(u_dip,0.0,1.0));\n")
        if (has("bars")) sb.append("  if(K>0.001 && (uv0.y<u_bars||uv0.y>1.0-u_bars)) rgb=vec3(0.0);\n")
        if (has("wipeP")) sb.append("  { vec2 d=vec2(cos(radians(${if (has("wipeAng")) "u_wipeAng" else "0.0"})),sin(radians(${if (has("wipeAng")) "u_wipeAng" else "0.0"}))); float tt=dot(uv0-0.5,d)/(abs(d.x)+abs(d.y))+0.5; if(u_wipeP>0.001&&tt>=1.0-u_wipeP) rgb=vec3(0.0); }\n")
        if (has("iris")) sb.append("  { float r=length((uv0-0.5)*vec2(uAspect,1.0)); if(u_iris>0.001&&r>(1.0-u_iris)*0.5*sqrt(uAspect*uAspect+1.0)) rgb=vec3(0.0); }\n")
        if (has("opac")) sb.append("  rgb*=u_opac;\n")
        if (has("border")) sb.append("  if(outside) rgb=vec3(0.0);\n")
        sb.append("  gl_FragColor=vec4(rgb,1.0);\n}\n")
        return sb.toString()
    }
}

@UnstableApi
class UberProgram(private val keys: List<String>, private val driver: FxDriver, fragment: String) : BaseGlShaderProgram(false, 1) {
    private val program: GlProgram = try { GlProgram(ShaderGen.VERT, fragment) } catch (e: GlUtil.GlException) { throw VideoFrameProcessingException(e) }
    private var w = 1
    private var h = 1

    init {
        try { program.setBufferAttribute("aFramePosition", GlUtil.getNormalizedCoordinateBounds(), GlUtil.HOMOGENEOUS_COORDINATE_VECTOR_SIZE) }
        catch (e: GlUtil.GlException) { throw VideoFrameProcessingException(e) }
    }

    override fun configure(inputWidth: Int, inputHeight: Int): Size { w = inputWidth; h = inputHeight; return Size(inputWidth, inputHeight) }

    private fun setF(name: String, v: Float) { try { program.setFloatUniform(name, v) } catch (e: Exception) { /* uniform optimised away by the compiler */ } }

    override fun drawFrame(inputTexId: Int, presentationTimeUs: Long) {
        try {
            val f = driver.frame(presentationTimeUs)
            program.use()
            program.setSamplerTexIdUniform("uTexSampler", inputTexId, 0)
            setF("uTime", (presentationTimeUs % 3_600_000_000L) / 1_000_000f)
            setF("uAspect", w.toFloat() / h.coerceAtLeast(1))
            setF("uK", f.k); setF("uCK", min(1f, f.k))
            for (k in keys) setF("u_$k", f.params[k] ?: ShaderGen.DEFAULTS[k] ?: 0f)
            program.bindAttributesAndUniforms()
            GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
        } catch (e: GlUtil.GlException) { throw VideoFrameProcessingException(e, presentationTimeUs) }
    }

    override fun release() {
        super.release()
        try { program.delete() } catch (e: GlUtil.GlException) { throw VideoFrameProcessingException(e) }
    }
}

@UnstableApi
class UberEffect(keysIn: Set<String>, private val driver: FxDriver) : GlEffect {
    private val keys = ShaderGen.withDeps(keysIn)
    private val fragment = ShaderGen.fragment(keysIn)
    override fun toGlShaderProgram(context: Context, useHdr: Boolean): GlShaderProgram = UberProgram(keys, driver, fragment)
}
