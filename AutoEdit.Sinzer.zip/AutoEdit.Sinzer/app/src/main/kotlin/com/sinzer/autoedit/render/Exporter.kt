package com.sinzer.autoedit.render

import android.content.ContentValues
import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.StatFs
import android.provider.MediaStore
import androidx.documentfile.provider.DocumentFile
import androidx.media3.common.MimeTypes
import androidx.media3.common.util.UnstableApi
import androidx.media3.transformer.*
import com.sinzer.autoedit.audio.BeatMap
import com.sinzer.autoedit.model.Project
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.withContext
import java.io.File
import java.io.IOException

data class ExportSettings(
    val shortSide: Int = 1080, val fps: Int = 30, val bitrateMbps: Float? = null, val hevc: Boolean = false,
    val name: String = "FlashCut", val folderUri: String = "",
)

sealed class ExportState {
    object Idle : ExportState()
    data class Running(val progress: Int, val stage: String) : ExportState()
    data class Done(val uri: Uri, val message: String) : ExportState()
    data class Failed(val message: String) : ExportState()
    object Cancelled : ExportState()
}

object Saver {
    /** Copies [file] to Movies/FlashCutAI (MediaStore) or into the user-chosen folder (SAF). Returns the saved Uri. */
    suspend fun saveVideo(ctx: Context, file: File, name: String, folderUri: String): Uri = withContext(Dispatchers.IO) {
        val fileName = if (name.endsWith(".mp4")) name else "$name.mp4"
        if (folderUri.isNotBlank()) {
            val dir = DocumentFile.fromTreeUri(ctx, Uri.parse(folderUri)) ?: throw IOException("เปิดโฟลเดอร์ที่เลือกไม่ได้")
            val df = dir.createFile("video/mp4", fileName.removeSuffix(".mp4")) ?: throw IOException("สร้างไฟล์ในโฟลเดอร์ที่เลือกไม่ได้ (ตรวจสอบสิทธิ์)")
            ctx.contentResolver.openOutputStream(df.uri)?.use { o -> file.inputStream().use { it.copyTo(o) } } ?: throw IOException("เขียนไฟล์ไม่ได้")
            return@withContext df.uri
        }
        if (Build.VERSION.SDK_INT >= 29) {
            val cv = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, fileName); put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/FlashCutAI"); put(MediaStore.Video.Media.IS_PENDING, 1)
            }
            val uri = ctx.contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, cv) ?: throw IOException("บันทึกลงแกลเลอรีไม่ได้")
            ctx.contentResolver.openOutputStream(uri)?.use { o -> file.inputStream().use { it.copyTo(o) } } ?: throw IOException("เขียนไฟล์ไม่ได้")
            cv.clear(); cv.put(MediaStore.Video.Media.IS_PENDING, 0); ctx.contentResolver.update(uri, cv, null, null)
            uri
        } else {
            val dir = File(ctx.getExternalFilesDir(android.os.Environment.DIRECTORY_MOVIES), "FlashCutAI").apply { mkdirs() }
            val dst = File(dir, fileName); file.copyTo(dst, overwrite = true); Uri.fromFile(dst)
        }
    }

    suspend fun saveText(ctx: Context, text: String, name: String, mime: String, folderUri: String): String = withContext(Dispatchers.IO) {
        if (folderUri.isNotBlank()) {
            val dir = DocumentFile.fromTreeUri(ctx, Uri.parse(folderUri)) ?: throw IOException("เปิดโฟลเดอร์ไม่ได้")
            val df = dir.createFile(mime, name.substringBeforeLast('.')) ?: throw IOException("สร้างไฟล์ไม่ได้")
            ctx.contentResolver.openOutputStream(df.uri)?.use { it.write(text.toByteArray()) }
            return@withContext "บันทึกในโฟลเดอร์ที่เลือกแล้ว"
        }
        if (Build.VERSION.SDK_INT >= 29) {
            val cv = ContentValues().apply { put(MediaStore.Downloads.DISPLAY_NAME, name); put(MediaStore.Downloads.MIME_TYPE, mime); put(MediaStore.Downloads.RELATIVE_PATH, "Download/FlashCutAI") }
            val uri = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv) ?: throw IOException("บันทึกไม่ได้")
            ctx.contentResolver.openOutputStream(uri)?.use { it.write(text.toByteArray()) }
            "บันทึกใน Download/FlashCutAI แล้ว"
        } else {
            val f = File(ctx.getExternalFilesDir(android.os.Environment.DIRECTORY_DOWNLOADS), name); f.writeText(text); "บันทึกที่ ${f.absolutePath}"
        }
    }
}

/** Runs one export at a time. Must be created and used on the main thread (Media3 Transformer requirement). */
@UnstableApi
class Exporter(private val ctx: Context, private val scope: CoroutineScope) {
    private val _state = MutableStateFlow<ExportState>(ExportState.Idle)
    val state: StateFlow<ExportState> = _state
    private var transformer: Transformer? = null
    private val handler = Handler(Looper.getMainLooper())
    private var polling = false

    val isRunning get() = _state.value is ExportState.Running

    fun reset() { if (!isRunning) _state.value = ExportState.Idle }

    fun start(p: Project, beat: BeatMap?, duck: DuckEnvelope?, s: ExportSettings, finishUi: suspend (File, ExportSettings, Long) -> Unit) {
        if (isRunning) return                        // ignore accidental double taps
        val dir = File(ctx.cacheDir, "exports").apply { mkdirs() }
        dir.listFiles()?.forEach { if (System.currentTimeMillis() - it.lastModified() > 3600_000) it.delete() }
        val free = StatFs(dir.absolutePath).availableBytes
        val built = try { CompositionBuilder.build(ctx, p, beat, duck, s.shortSide, if (s.fps < 60) s.fps else null) }
        catch (e: Exception) { _state.value = ExportState.Failed("เตรียมโปรเจกต์ไม่สำเร็จ: ${e.message}"); return }
        if (built == null) { _state.value = ExportState.Failed("ยังไม่มีคลิปวิดีโอบนแทร็กหลัก"); return }
        val est = ((s.bitrateMbps ?: 8f) * 1_000_000L / 8 * (built.totalMs / 1000.0)).toLong()
        if (free < est * 1.5) { _state.value = ExportState.Failed("พื้นที่ว่างในเครื่องไม่พอ (ต้องการประมาณ ${est / 1_000_000 * 3 / 2} MB)"); return }

        val out = File(dir, "export_${System.currentTimeMillis()}.mp4")
        val enc = VideoEncoderSettings.Builder().apply { s.bitrateMbps?.let { setBitrate((it * 1_000_000).toInt()) } }.build()
        val t = Transformer.Builder(ctx)
            .setVideoMimeType(if (s.hevc) MimeTypes.VIDEO_H265 else MimeTypes.VIDEO_H264)
            .setAudioMimeType(MimeTypes.AUDIO_AAC)
            .setEncoderFactory(DefaultEncoderFactory.Builder(ctx).setRequestedVideoEncoderSettings(enc).setEnableFallback(true).build())
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    polling = false
                    _state.value = ExportState.Running(100, "กำลังตรวจสอบและบันทึกไฟล์")
                    transformer = null
                    scope.launch { try { finishUi(out, s, built.totalMs) } catch (e: Exception) { _state.value = ExportState.Failed("บันทึกไฟล์ไม่สำเร็จ: ${e.message}") } }
                }
                override fun onError(composition: Composition, exportResult: ExportResult, exportException: ExportException) {
                    polling = false; transformer = null; out.delete()
                    _state.value = ExportState.Failed(explain(exportException))
                }
            }).build()
        transformer = t
        _state.value = ExportState.Running(0, "กำลังเรนเดอร์วิดีโอ")
        try { t.start(built.composition, out.absolutePath) } catch (e: Exception) { transformer = null; _state.value = ExportState.Failed("เริ่มเรนเดอร์ไม่ได้: ${e.message}"); return }
        polling = true
        val holder = ProgressHolder()
        handler.post(object : Runnable {
            override fun run() {
                if (!polling) return
                val tr = transformer ?: return
                if (tr.getProgress(holder) == Transformer.PROGRESS_STATE_AVAILABLE) _state.value = ExportState.Running(holder.progress.coerceIn(0, 99), "กำลังเรนเดอร์วิดีโอ")
                handler.postDelayed(this, 250)
            }
        })
    }

    fun setDone(uri: Uri, msg: String) { _state.value = ExportState.Done(uri, msg) }
    fun setFailed(msg: String) { _state.value = ExportState.Failed(msg) }

    fun cancel() {
        polling = false
        transformer?.cancel(); transformer = null
        _state.value = ExportState.Cancelled
    }

    private fun explain(e: ExportException): String {
        val base = when (e.errorCode) {
            ExportException.ERROR_CODE_ENCODER_INIT_FAILED, ExportException.ERROR_CODE_ENCODING_FORMAT_UNSUPPORTED ->
                "เครื่องนี้เข้ารหัสวิดีโอตามที่เลือกไม่ได้ ลองลดความละเอียดหรือเปลี่ยนเป็น H.264"
            ExportException.ERROR_CODE_DECODER_INIT_FAILED, ExportException.ERROR_CODE_DECODING_FORMAT_UNSUPPORTED ->
                "เครื่องนี้ถอดรหัสคลิปบางไฟล์ไม่ได้"
            ExportException.ERROR_CODE_IO_FILE_NOT_FOUND, ExportException.ERROR_CODE_IO_NO_PERMISSION -> "ไม่พบไฟล์ต้นฉบับหรือไม่มีสิทธิ์อ่านไฟล์ (ไฟล์ถูกย้ายหรือลบ?)"
            ExportException.ERROR_CODE_IO_UNSPECIFIED -> "เขียนไฟล์ไม่ได้ (พื้นที่เต็ม?)"
            else -> "เรนเดอร์ไม่สำเร็จ"
        }
        return "$base [${e.errorCodeName}]"
    }

    /** Opens the file and makes sure it really plays: duration is close to the expected one and a frame can be decoded. */
    suspend fun verify(file: File, expectedMs: Long): String? = withContext(Dispatchers.IO) {
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(file.absolutePath)
            val d = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            if (d <= 0) return@withContext "ไฟล์ที่ได้ไม่มีความยาว"
            if (kotlin.math.abs(d - expectedMs) > 1500) return@withContext "ความยาวไฟล์ (${d}ms) ไม่ตรงกับที่คาด (${expectedMs}ms)"
            if (r.getFrameAtTime(d / 2 * 1000) == null) return@withContext "เปิดภาพจากไฟล์ที่ได้ไม่ได้"
            null
        } catch (e: Exception) { "เปิดไฟล์ที่ได้ไม่ได้: ${e.message}" } finally { runCatching { r.release() } }
    }
}

