package com.sinzer.autoedit.ui

import android.content.res.Configuration
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateRotation
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.util.UnstableApi
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.sinzer.autoedit.model.*
import com.sinzer.autoedit.vm.MainVM
import kotlinx.coroutines.delay
import kotlin.math.max
import kotlin.math.min

enum class Tool(val label: String, val icon: String, val helpKey: String) {
    AUTO("AI Auto", "✨", "autoedit"), MEDIA("นำเข้า", "📁", "import"), AUDIO("เสียง", "🎵", "volume"), BEAT("บีต", "🥁", "beat"),
    TEXT("ข้อความ", "🅣", "text"), STICKER("สติ๊กเกอร์", "☺", "sticker"), FX("เอฟเฟกต์", "🎆", "effects"), TRANS("ทรานซิชัน", "⇄", "transition"),
    SPEED("ความเร็ว", "⏱", "speed"), COLOR("สี", "🎨", "color"), KEYFRAME("คีย์เฟรม", "◆", "keyframe"), SUBTITLE("คำบรรยาย", "💬", "subtitle"), TRACKS("แทร็ก", "☰", "tracks"),
}

@OptIn(UnstableApi::class, ExperimentalMaterial3Api::class)
@Composable
fun EditorScreen(vm: MainVM, initialTool: String?, onBack: () -> Unit, onExport: () -> Unit) {
    val project by vm.project.collectAsState()
    val p = project ?: run { LaunchedEffect(Unit) { onBack() }; return }
    val analyses by vm.analyses.collectAsState()
    val selection by vm.selection.collectAsState()
    val playhead by vm.playhead.collectAsState()
    val playing by vm.playing.collectAsState()
    val busy by vm.busy.collectAsState()
    val missing by vm.missingAssets.collectAsState()
    val previewError by vm.previewError.collectAsState()
    val canUndo by vm.canUndo.collectAsState()
    val canRedo by vm.canRedo.collectAsState()
    val settings by vm.settings.collectAsState()
    var tool by remember { mutableStateOf(initialTool?.let { runCatching { Tool.valueOf(it) }.getOrNull() }) }
    val snack = remember { SnackbarHostState() }
    val landscape = LocalConfiguration.current.orientation == Configuration.ORIENTATION_LANDSCAPE
    val beats = remember(p, analyses) { vm.timelineBeats(p, analyses) }

    LaunchedEffect(Unit) { vm.ensurePlayer() }
    LaunchedEffect(p, analyses, settings.previewHeight) { vm.refreshPreview() }
    LaunchedEffect(playing) { while (playing) { vm.pollPlayhead(); delay(33) } }
    LaunchedEffect(Unit) { vm.messages.collect { snack.showSnackbar(it, duration = SnackbarDuration.Long) } }
    DisposableEffect(Unit) { onDispose { vm.pause(); vm.saveNow() } }

    Scaffold(containerColor = Bg, snackbarHost = { SnackbarHost(snack) }) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            // top bar
            Row(Modifier.fillMaxWidth().height(48.dp).padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { vm.saveNow(); onBack() }) { Icon(Icons.Filled.ArrowBack, "กลับ") }
                Text(p.name, Modifier.weight(1f), fontWeight = FontWeight.Bold, maxLines = 1, fontSize = 15.sp)
                IconButton(onClick = { vm.undo() }, enabled = canUndo) { Icon(Icons.Filled.Undo, "Undo", tint = if (canUndo) Color.White else TextDim) }
                IconButton(onClick = { vm.redo() }, enabled = canRedo) { Icon(Icons.Filled.Redo, "Redo", tint = if (canRedo) Color.White else TextDim) }
                HelpIcon("undo")
                NeonButton("ส่งออก", Modifier.height(38.dp), enabled = p.clips.any { it.trackId == p.mainTrackId }) { vm.pause(); vm.saveNow(); onExport() }
                Spacer(Modifier.width(6.dp))
            }
            if (missing.isNotEmpty()) Text("⚠ ไม่พบไฟล์ต้นฉบับ ${missing.size} ไฟล์ — เปิดแท็บ “นำเข้า” เพื่อเลือกไฟล์ใหม่", Modifier.fillMaxWidth().background(Color(0x33FF5470)).padding(6.dp), fontSize = 12.sp, color = Danger)

            val previewBlock: @Composable (Modifier) -> Unit = { m ->
                Column(m) {
                    PreviewArea(vm, p, selection, previewError, Modifier.weight(1f).fillMaxWidth())
                    Transport(vm, p, playhead, playing, Modifier.fillMaxWidth())
                }
            }
            val editBlock: @Composable (Modifier) -> Unit = { m ->
                Column(m) {
                    TimelineView(vm, p, analyses, beats, Modifier.fillMaxWidth().height(if (landscape) 150.dp else 170.dp))
                    val t = tool
                    if (t != null) {
                        Surface(color = Surface1, modifier = Modifier.fillMaxWidth().then(if (landscape) Modifier.weight(1f) else Modifier.heightIn(max = 250.dp))) {
                            Column {
                                Row(Modifier.fillMaxWidth().padding(start = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Text("${t.icon} ${t.label}", fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                                    HelpIcon(t.helpKey)
                                    IconButton(onClick = { tool = null }) { Icon(Icons.Filled.Close, "ปิด") }
                                }
                                Box(Modifier.weight(1f, fill = false)) { ToolPanel(t, vm, p, analyses, beats, selection, playhead, missing, settings.openAiKey.isNotBlank()) }
                            }
                        }
                        FirstUseTip(t.helpKey, settings.seenTips) { k -> vm.viewModelScope_markTip(k) }
                    }
                    Toolbar(vm, p, selection, tool, { tool = if (tool == it) null else it })
                }
            }
            if (landscape) Row(Modifier.fillMaxSize()) { previewBlock(Modifier.weight(0.9f).fillMaxHeight()); editBlock(Modifier.weight(1.2f).fillMaxHeight()) }
            else Column(Modifier.fillMaxSize()) { previewBlock(Modifier.weight(1f).fillMaxWidth()); editBlock(Modifier.fillMaxWidth().then(if (tool != null) Modifier.wrapContentHeight() else Modifier.wrapContentHeight())) }
        }
    }

    busy?.let { b ->
        BusyDialog(b, vm)
    }
}

@Composable
private fun BusyDialog(b: com.sinzer.autoedit.vm.Busy, vm: MainVM) {
    AlertDialog(onDismissRequest = {}, containerColor = Surface1,
        title = { Text("กำลังทำงาน") },
        text = { Column { Text(b.label); Spacer(Modifier.height(10.dp)); if (b.progress in 0f..1f) LinearProgressIndicator(progress = { b.progress }, Modifier.fillMaxWidth()) else LinearProgressIndicator(Modifier.fillMaxWidth()) } },
        confirmButton = { if (b.cancellable) TextButton(onClick = { vm.cancelJob() }) { Text("ยกเลิก", color = Danger) } })
}

@OptIn(UnstableApi::class)
@Composable
private fun PreviewArea(vm: MainVM, p: Project, sel: Sel?, err: String?, modifier: Modifier) {
    BoxWithConstraints(modifier.background(Color.Black), contentAlignment = Alignment.Center) {
        val ratio = p.aspect.w.toFloat() / p.aspect.h
        val w = min(maxWidth.value, maxHeight.value * ratio); val h = w / ratio
        Box(Modifier.size(w.dp, h.dp).background(Color(0xFF05070D))) {
            AndroidView(factory = { c -> PlayerView(c).apply { useController = false; resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT; setShutterBackgroundColor(android.graphics.Color.TRANSPARENT) } },
                update = { it.player = vm.previewPlayer }, modifier = Modifier.fillMaxSize())
            if (p.clips.none { it.trackId == p.mainTrackId }) Text("นำเข้าวิดีโอหรือรูปภาพเพื่อเริ่มตัดต่อ\n(แท็บ “นำเข้า” หรือ “AI Auto”)", Modifier.align(Alignment.Center).padding(16.dp), color = TextDim, fontSize = 13.sp)
            if (sel != null && sel.kind != ItemKind.FX) TransformOverlay(vm, p, sel, with(LocalDensity.current) { w.dp.toPx() }, with(LocalDensity.current) { h.dp.toPx() })
        }
        if (err != null) Text(err, Modifier.align(Alignment.BottomCenter).background(Color(0xCC000000)).padding(6.dp), color = Danger, fontSize = 12.sp)
    }
}

/** Drag = move, two fingers = scale / rotate the selected text, sticker or clip directly on the video. */
@Composable
private fun TransformOverlay(vm: MainVM, p: Project, sel: Sel, w: Float, h: Float) {
    if (sel.kind == ItemKind.CLIP && p.clipOf(sel)?.let { c -> p.asset(c.assetId)?.type == MediaType.AUDIO || c.audioOnly } != false) return
    Box(Modifier.fillMaxSize().pointerInput(sel) {
        awaitEachGesture {
            awaitFirstDown(requireUnconsumed = false)
            vm.beginGesture()
            while (true) {
                val ev = awaitPointerEvent()
                val pan = ev.calculatePan(); val zoom = ev.calculateZoom(); val rot = ev.calculateRotation()
                if (pan != Offset.Zero || zoom != 1f || rot != 0f) {
                    when (sel.kind) {
                        ItemKind.TEXT -> vm.updateText(sel.id) { it.copy(x = (it.x + pan.x / w).coerceIn(-0.2f, 1.2f), y = (it.y + pan.y / h).coerceIn(-0.2f, 1.2f), scale = (it.scale * zoom).coerceIn(0.1f, 8f), rot = it.rot - rot) }
                        ItemKind.STICKER -> vm.updateSticker(sel.id) { it.copy(x = (it.x + pan.x / w).coerceIn(-0.2f, 1.2f), y = (it.y + pan.y / h).coerceIn(-0.2f, 1.2f), scale = (it.scale * zoom).coerceIn(0.1f, 8f), rot = it.rot - rot) }
                        ItemKind.CLIP -> vm.updateClip(sel.id) { it.copy(tx = it.tx + pan.x / w, ty = it.ty - pan.y / h, scale = (it.scale * zoom).coerceIn(0.1f, 8f), rot = it.rot - rot) }
                        else -> {}
                    }
                }
                ev.changes.forEach { it.consume() }
                if (ev.changes.none { it.pressed }) break
            }
            vm.endGesture()
        }
    })
}

@Composable
private fun Transport(vm: MainVM, p: Project, playhead: Long, playing: Boolean, modifier: Modifier) {
    val end = p.videoEndMs()
    Row(modifier.height(44.dp).padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        IconButton(onClick = { vm.seek(0) }) { Icon(Icons.Filled.SkipPrevious, "ไปเริ่มต้น") }
        IconButton(onClick = { vm.seek((playhead - 1000L / p.fps.coerceAtLeast(1)).coerceAtLeast(0)) }) { Icon(Icons.Filled.FirstPage, "ย้อน 1 เฟรม") }
        FilledIconButton(onClick = { vm.togglePlay() }, colors = IconButtonDefaults.filledIconButtonColors(containerColor = NeonBlue, contentColor = Color.Black)) {
            Icon(if (playing) Icons.Filled.Pause else Icons.Filled.PlayArrow, if (playing) "หยุด" else "เล่น")
        }
        IconButton(onClick = { vm.seek(min(end, playhead + 1000L / p.fps.coerceAtLeast(1))) }) { Icon(Icons.Filled.LastPage, "ไปข้างหน้า 1 เฟรม") }
        IconButton(onClick = { vm.seek(end) }) { Icon(Icons.Filled.SkipNext, "ไปท้าย") }
        Spacer(Modifier.weight(1f))
        Text("${fmtTime(playhead)} / ${fmtTime(end)}", fontSize = 12.sp, color = TextDim)
        Spacer(Modifier.width(6.dp))
        FilterChip(p.snap, { vm.setSnap(!p.snap) }, { Text("🧲", fontSize = 13.sp) })
        HelpIcon("snap")
    }
}

@Composable
private fun Toolbar(vm: MainVM, p: Project, sel: Sel?, tool: Tool?, onTool: (Tool) -> Unit) {
    Row(Modifier.fillMaxWidth().background(Surface1).horizontalScroll(rememberScrollState()).padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        QuickBtn("✂", "ตัด", { vm.split() }); QuickBtn("🗑", "ลบ", { vm.deleteSel() }, sel != null); QuickBtn("⧉", "คัดลอก", { vm.duplicateSel() }, sel != null)
        Box(Modifier.width(1.dp).height(30.dp).background(Surface2))
        Tool.values().forEach { t ->
            Column(Modifier.clip(RoundedCornerShape(10.dp)).background(if (tool == t) Surface2 else Color.Transparent).clickable { onTool(t) }.padding(horizontal = 10.dp, vertical = 4.dp).widthIn(min = 52.dp),
                horizontalAlignment = Alignment.CenterHorizontally) {
                Text(t.icon, fontSize = 20.sp); Text(t.label, fontSize = 10.sp, color = if (tool == t) NeonBlue else TextDim, maxLines = 1)
            }
        }
    }
}

@Composable
private fun QuickBtn(icon: String, label: String, onClick: () -> Unit, enabled: Boolean = true) {
    Column(Modifier.clip(RoundedCornerShape(10.dp)).clickable(enabled = enabled, onClick = onClick).padding(horizontal = 10.dp, vertical = 4.dp).widthIn(min = 48.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(icon, fontSize = 20.sp, color = if (enabled) Color.White else TextDim); Text(label, fontSize = 10.sp, color = TextDim)
    }
}

@Composable
private fun ToolPanel(t: Tool, vm: MainVM, p: Project, an: Map<String, com.sinzer.autoedit.audio.AudioAnalysis>, beats: com.sinzer.autoedit.audio.BeatMap, sel: Sel?, playhead: Long, missing: Set<String>, hasKey: Boolean) {
    when (t) {
        Tool.AUTO -> AutoPanel(vm, p, an)
        Tool.MEDIA -> MediaPanel(vm, p, missing)
        Tool.AUDIO -> AudioPanel(vm, p, sel)
        Tool.BEAT -> BeatPanel(vm, p, an, beats, sel, playhead)
        Tool.TEXT -> TextPanel(vm, p, sel)
        Tool.STICKER -> StickerPanel(vm, p, sel)
        Tool.FX -> FxPanel(vm, p, sel)
        Tool.TRANS -> TransPanel(vm, p, sel)
        Tool.SPEED -> SpeedPanel(vm, p, sel)
        Tool.COLOR -> ColorPanel(vm, p, sel)
        Tool.KEYFRAME -> KeyframePanel(vm, p, sel, playhead)
        Tool.SUBTITLE -> SubtitlePanel(vm, p, hasKey)
        Tool.TRACKS -> TracksPanel(vm, p)
    }
}
